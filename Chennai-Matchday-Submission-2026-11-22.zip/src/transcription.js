const defaultEndpoint = 'https://api.groq.com/openai/v1/audio/transcriptions';
const supportedTypes = new Map([
  ['audio/webm', 'speech.webm'],
  ['audio/ogg', 'speech.ogg'],
  ['audio/mp4', 'speech.m4a'],
  ['audio/mpeg', 'speech.mp3'],
  ['audio/wav', 'speech.wav'],
  ['audio/x-wav', 'speech.wav'],
]);

function normalizedType(value = '') {
  return String(value).split(';', 1)[0].trim().toLowerCase();
}

export function audioFileName(mimeType) {
  return supportedTypes.get(normalizedType(mimeType)) || null;
}

export function createGroqTranscriber({
  apiKey,
  model = 'whisper-large-v3-turbo',
  endpoint = defaultEndpoint,
  fetchImpl = globalThis.fetch,
} = {}) {
  const configured = Boolean(apiKey && typeof apiKey === 'string');
  const status = {
    configured,
    provider:'groq',
    model,
    detail:configured
      ? 'Microphone audio is transcribed by Groq and is not stored by this app.'
      : 'Add GROQ_API_KEY to enable reliable browser microphone transcription.',
  };

  async function transcribe({audioBuffer, mimeType, signal}) {
    if (!configured) {
      const error = new Error(status.detail);
      error.status = 503;
      throw error;
    }
    if (typeof fetchImpl !== 'function') throw new Error('A Fetch implementation is required.');
    const fileName = audioFileName(mimeType);
    if (!fileName) {
      const error = new Error('Unsupported microphone recording format.');
      error.status = 415;
      throw error;
    }
    if (!Buffer.isBuffer(audioBuffer) || audioBuffer.length < 32) {
      const error = new Error('The microphone recording was empty.');
      error.status = 400;
      throw error;
    }

    const form = new FormData();
    form.append('file', new Blob([audioBuffer], {type:normalizedType(mimeType)}), fileName);
    form.append('model', model);
    form.append('language', 'en');
    form.append('response_format', 'json');
    form.append('temperature', '0');
    const response = await fetchImpl(endpoint, {
      method:'POST',
      headers:{Authorization:`Bearer ${apiKey}`},
      body:form,
      signal,
    });
    if (!response.ok) {
      const error = new Error(response.status === 429
        ? 'Speech transcription is temporarily rate limited. Please retry.'
        : 'Speech transcription failed. Please retry or type your message.');
      error.status = response.status === 429 ? 429 : 502;
      throw error;
    }
    const payload = await response.json();
    const text = payload?.text?.trim();
    if (!text) {
      const error = new Error('No speech was detected in the recording.');
      error.status = 422;
      throw error;
    }
    return {text, provider:'groq', model};
  }
  transcribe.status = status;
  return transcribe;
}
