import http from 'node:http';
import { randomUUID } from 'node:crypto';
import { readFile, writeFile, rename, mkdir } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { loadEnvFile } from 'node:process';
import { setTimeout as delay } from 'node:timers/promises';
import { replyTurn } from './src/conversation.js';
import { loadLeads, planOutreach, draftOutreach } from './src/outreach.js';
import { createProductionAgent } from './src/agent.js';
import { createTelecomProvider, createTelecomStore, normalizePhone, xmlEscape } from './src/telecom.js';
import { audioFileName, createGroqTranscriber } from './src/transcription.js';

const root = fileURLToPath(new URL('.', import.meta.url));
try { loadEnvFile(resolve(root, '.env')); } catch (error) { if (error.code !== 'ENOENT') throw error; }
const demoDate = '2027-04-01T11:00:00+05:30';
const assets = new Map([
  ['/', ['index.html', 'text/html; charset=utf-8']],
  ['/app.js', ['app.js', 'text/javascript; charset=utf-8']],
  ['/style.css', ['style.css', 'text/css; charset=utf-8']],
  ['/assets/chepauk.webp', ['assets/chepauk.webp', 'image/webp']],
  ['/assets/dhoni-archive.webp', ['assets/dhoni-archive.webp', 'image/webp']],
  ['/assets/dhoni-keeping.webp', ['assets/dhoni-keeping.webp', 'image/webp']],
  ...['dm-sans', 'barlow-condensed-bold', 'barlow-condensed-extrabold-italic'].map(name => [
    '/assets/' + name + '.ttf', ['assets/' + name + '.ttf', 'font/ttf'],
  ]),
]);
const limit = 16 * 1024;
function problem(status, message) { return Object.assign(new Error(message), { status }); }
function json(res, code, payload) {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options':'nosniff' });
  res.end(JSON.stringify(payload));
}
function xml(res, code, payload) {
  res.writeHead(code, {'Content-Type':'application/xml; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
  res.end(payload);
}
async function rawBodyOf(req, expectedType, maxBytes = limit) {
  if (!new RegExp(`^${expectedType.replace('/','\\/')}\\b`,'i').test(req.headers['content-type'] || '')) throw problem(415, 'Unsupported content type.');
  const buffers = [];
  let count = 0;
  for await (const chunk of req) {
    count += chunk.length;
    if (count > maxBytes) throw problem(413, 'Request body is too long.');
    buffers.push(chunk);
  }
  return Buffer.concat(buffers).toString();
}
async function bodyOf(req, maxBytes = limit) {
  let body;
  try { body = JSON.parse(await rawBodyOf(req,'application/json',maxBytes)); } catch (error) { if (error.status) throw error; throw problem(400, 'Invalid JSON.'); }
  if (!body || typeof body !== 'object' || Array.isArray(body)) throw problem(400, 'Expected a JSON object.');
  return body;
}
async function formOf(req) {
  const form = new URLSearchParams(await rawBodyOf(req,'application/x-www-form-urlencoded',64 * 1024));
  if ([...form].length > 200) throw problem(413,'Too many webhook fields.');
  return form;
}
const dayKey = date => new Intl.DateTimeFormat('en-CA', {timeZone:'Asia/Kolkata', year:'numeric', month:'2-digit', day:'2-digit'}).format(date);

export async function createApp(options = {}) {
  const catalog = options.catalog ?? JSON.parse(await readFile(resolve(root, 'data/catalog.json'), 'utf8'));
  const leads = options.leads ?? await loadLeads();
  const agent = options.model === undefined
    ? await createProductionAgent(catalog, {
      apiKey: options.apiKey,
      groqApiKey: options.groqApiKey,
      provider: options.provider,
      modelName: options.modelName,
      cloudTimeoutMs: options.cloudTimeoutMs,
      fetchImpl: options.fetchImpl,
      endpoint: options.geminiEndpoint,
      groqEndpoint: options.groqEndpoint,
      groqContextMode: options.groqContextMode,
      localModel: options.localModel,
      cloudModel: options.cloudModel,
    })
    : {
      model: options.model,
      mode: options.mode ?? 'auto',
      status: options.agentStatus ?? {
        configured: Boolean(options.model),
        provider: options.model ? 'injected' : 'rules',
        model: options.model ? 'test-adapter' : 'none',
        label: options.model ? 'Injected agent' : 'Rules only',
      },
    };
  const model = agent.model;
  const transcriber = options.transcriber ?? createGroqTranscriber({
    apiKey:options.transcriptionApiKey ?? options.groqApiKey ?? process.env.GROQ_API_KEY,
    model:options.transcriptionModel ?? process.env.GROQ_TRANSCRIPTION_MODEL,
    endpoint:options.transcriptionEndpoint,
    fetchImpl:options.transcriptionFetchImpl,
  });
  const speechInputStatus = options.speechInputStatus ?? transcriber.status ?? {
    configured:Boolean(options.transcriber), provider:'injected', model:'test-adapter',
    detail:'Browser microphone transcription is available.',
  };
  const turnTimeoutMs = options.timeoutMs ?? 8500;
  const storePath = options.storePath === undefined ? resolve(root, '.runtime/preferences.json') : options.storePath;
  let prefs = { optouts: [], contacts: {} };
  if (storePath) {
    try { prefs = JSON.parse(await readFile(storePath, 'utf8')); } catch (err) { if (err.code !== 'ENOENT') throw err; }
    if (!Array.isArray(prefs.optouts) || !prefs.contacts || typeof prefs.contacts !== 'object') throw Error('Invalid local preferences file.');
  }
  let pending = Promise.resolve();
  function changePrefs(update) {
    const work = pending.then(async () => {
      const next = structuredClone(prefs);
      await update(next);
      if (storePath) {
        await mkdir(dirname(storePath), { recursive:true });
        const tmp = storePath + '.tmp';
        await writeFile(tmp, JSON.stringify(next), {mode:0o600});
        await rename(tmp, storePath);
      }
      prefs = next;
    });
    pending = work.catch(() => {});
    return work;
  }
  const exotelConfigPath=options.exotelConfigPath ?? resolve(root,'.runtime/exotel-config.json');
  let savedExotel;
  if(!options.telecomProvider && !options.telecomProviderName){
    try{savedExotel=JSON.parse(await readFile(exotelConfigPath,'utf8'));}catch(error){if(error.code!=='ENOENT')throw error;}
  }
  let telecomProvider = options.telecomProvider ?? createTelecomProvider(savedExotel ? {name:'exotel',...savedExotel} : {
    name:options.telecomProviderName,
    accountSid:options.twilioAccountSid,
    authToken:options.twilioAuthToken,
    fromNumber:options.twilioFromNumber,
    messagingServiceSid:options.twilioMessagingServiceSid,
    contentSid:options.twilioContentSid,
    publicBaseUrl:options.publicBaseUrl,
    endpoint:options.twilioEndpoint,
    fetchImpl:options.telecomFetchImpl,
    timeoutMs:options.telecomTimeoutMs,
  });
  const telecomStorePath = options.telecomStorePath === undefined ? resolve(root,'.runtime/telecom.json') : options.telecomStorePath;
  const telecom = options.telecomStore ?? await createTelecomStore(telecomStorePath);
  const existingDemoProfiles=Object.values(telecom.snapshot().profiles);
  let ownDemoPhone=options.ownDemoPhone ?? savedExotel?.demoPhone ?? (savedExotel && existingDemoProfiles.length===1 ? existingDemoProfiles[0].phoneE164 : null);
  const voiceTurnTimeoutMs = options.voiceTurnTimeoutMs ?? 3000;
  let telecomPending = Promise.resolve();
  function queueTelecom(work) {
    const run = telecomPending.then(work);
    telecomPending = run.catch(() => {});
    return run;
  }
  const sessions = new Map();
  function sessionFor(key) {
    if (typeof key !== 'string' || !/^[a-z\d_.-]{1,100}$/i.test(key)) throw problem(400, 'Invalid session ID.');
    const now = Date.now();
    for (const [id, session] of sessions) if (!session.locked && now - session.lastSeen > 30 * 60_000) sessions.delete(id);
    if (!sessions.has(key)) {
      if (sessions.size >= (options.maxSessions ?? 5000)) throw problem(503, 'The ticket desk is at session capacity. Please retry shortly.');
      sessions.set(key, { state:{}, leadId:null, locked:false, lastSeen:now, requests:[] });
    }
    const session = sessions.get(key);
    session.lastSeen = now;
    return session;
  }
  function gateOptions(now, saved=prefs) {
    return {now, optedOutIds:saved.optouts, contactedTodayIds:Object.keys(saved.contacts).filter(id => saved.contacts[id] === dayKey(now))};
  }
  function clockFor(mode) { return mode === 'live' ? new Date() : new Date(demoDate); }
  const findLead = leadId => leads.find(lead => lead.lead_id === leadId);
  function publicDispatch(row, replayed = false) {
    if (!row) return null;
    return {
      id:row.id, leadId:row.leadId, channel:row.channel, provider:row.provider,
      status:row.status, providerStatus:row.providerStatus ?? null,
      createdAt:row.createdAt, updatedAt:row.updatedAt, replayed,
    };
  }
  function telecomOverview(leadId) {
    const saved = telecom.snapshot();
    const records = Object.values(saved.dispatches).filter(row => !leadId || row.leadId === leadId)
      .sort((a,b) => b.createdAt.localeCompare(a.createdAt)).slice(0,10).map(row => publicDispatch(row));
    return {
      provider:telecomProvider.status,
      ownDemoPhoneConfigured:Boolean(ownDemoPhone && telecomProvider.name==='exotel'),
      profile:{leadId, phoneConfigured:Boolean(leadId && saved.profiles[leadId]?.phoneE164)},
      eligibility:telecomProvider.real && leadId ? Object.fromEntries(['sms','voice'].map(channel=>{
        const draft=draftOutreach(leads,leadId,{...gateOptions(new Date()),channel});
        return [channel,{allowed:draft.ok,reason:draft.reason}];
      })) : null,
      dispatches:records,
    };
  }
  async function dispatchTelecom({leadId, channel, idempotencyKey, clock}) {
    if (!findLead(leadId)) throw problem(404,'Lead not found.');
    if (!['sms','voice'].includes(channel)) throw problem(400,'Choose SMS or voice.');
    if(telecomProvider.status.channels && !telecomProvider.status.channels.includes(channel))throw problem(409,'This connection supports telephone calls only. Live SMS is not configured.');
    if (typeof idempotencyKey !== 'string' || !/^[a-z\d_.:-]{8,100}$/i.test(idempotencyKey)) throw problem(400,'Provide a valid idempotency key.');
    return queueTelecom(async () => {
      const saved = telecom.snapshot();
      const previousId = saved.idempotency[idempotencyKey];
      if (previousId) return publicDispatch(saved.dispatches[previousId],true);
      const now = options.telecomNow ? new Date(options.telecomNow())
        : !telecomProvider.real && clock === 'campaign' ? new Date(demoDate) : new Date();
      if (Number.isNaN(now.getTime())) throw new Error('Invalid telecom clock.');
      const draft = draftOutreach(leads,leadId,{...gateOptions(now),channel});
      if (!draft.ok) throw problem(409,draft.reason || 'Outreach is unavailable.');
      const phoneE164 = saved.profiles[leadId]?.phoneE164;
      if (!phoneE164) throw problem(409,'Save the verified demo number for this lead first.');
      if (!telecomProvider.status.configured) throw problem(503,telecomProvider.status.detail);
      const dispatchId = randomUUID();
      const createdAt = now.toISOString();
      const record = {
        id:dispatchId, leadId, channel, provider:telecomProvider.name,
        status:'submitting', providerStatus:null, providerId:null,
        openingText:draft.row.first_message, createdAt, updatedAt:createdAt,
      };
      await telecom.change(next => {
        next.idempotency[idempotencyKey] = dispatchId;
        next.dispatches[dispatchId] = record;
      });
      try {
        const result = channel === 'sms'
          ? await telecomProvider.sendSms({to:phoneE164,text:record.openingText,dispatchId})
          : await telecomProvider.startCall({to:phoneE164,dispatchId});
        const updatedAt = new Date().toISOString();
        await telecom.change(next => Object.assign(next.dispatches[dispatchId],{
          providerId:result.providerId,
          providerStatus:result.status,
          status:telecomProvider.real ? 'provider_accepted' : 'dry_run_accepted',
          updatedAt,
        }));
        if (telecomProvider.real) await changePrefs(next => { next.contacts[leadId] = dayKey(now); });
        return publicDispatch(telecom.snapshot().dispatches[dispatchId]);
      } catch (error) {
        await telecom.change(next => Object.assign(next.dispatches[dispatchId],{
          status:'provider_rejected', providerStatus:error.providerCode ? String(error.providerCode) : null, updatedAt:new Date().toISOString(),
        }));
        throw problem(error.status || 502,error.message || 'The telecom provider rejected the request.');
      }
    });
  }
  function signedWebhookUrl(req) {
    if (telecomProvider.name !== 'twilio' || !telecomProvider.publicBaseUrl) throw problem(404,'Webhook is unavailable.');
    return telecomProvider.publicBaseUrl + req.url;
  }
  function verifyTwilioWebhook(req, form) {
    const valid = telecomProvider.verifyWebhook({
      url:signedWebhookUrl(req), parameters:form, signature:req.headers['x-twilio-signature'],
    });
    if (!valid) throw problem(403,'Invalid webhook signature.');
  }
  function twimlGather(dispatchId, spokenText) {
    const action = `${telecomProvider.publicBaseUrl}/webhooks/twilio/voice/gather?dispatchId=${encodeURIComponent(dispatchId)}`;
    return `<Response><Gather input="speech dtmf" action="${xmlEscape(action)}" method="POST" language="en-IN" speechTimeout="auto" timeout="5" actionOnEmptyResult="true"><Say language="en-IN">${xmlEscape(spokenText)}</Say></Gather><Say language="en-IN">I did not hear a response. Please contact the ticket desk when you are ready.</Say><Hangup/></Response>`;
  }
  async function rememberWebhook(key, update) {
    let duplicate = false;
    await telecom.change(next => {
      if (next.webhookEvents[key]) { duplicate = true; return; }
      next.webhookEvents[key] = {receivedAt:new Date().toISOString()};
      update?.(next);
    });
    return duplicate;
  }
  return http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, 'http://localhost');
      const twilioWebhook = req.method === 'POST' && url.pathname.startsWith('/webhooks/twilio/');
      if (twilioWebhook) {
        const form = await formOf(req);
        verifyTwilioWebhook(req,form);
        if (url.pathname === '/webhooks/twilio/message/inbound') {
          const messageSid = form.get('MessageSid') || form.get('SmsSid');
          if (!messageSid) throw problem(400,'Missing message identifier.');
          const body = (form.get('Body') || '').trim();
          const isStop = /^(?:stop|stopall|unsubscribe|cancel|end|quit)\b/i.test(body);
          let from = null;
          try { from = normalizePhone(form.get('From')); } catch { /* Unknown senders are acknowledged without storing them. */ }
          const saved = telecom.snapshot();
          const leadId = from ? Object.entries(saved.profiles).find(([,profile]) => profile.phoneE164 === from)?.[0] : null;
          const duplicate = await rememberWebhook(`message:inbound:${messageSid}`,next => {
            next.webhookEvents[`message:inbound:${messageSid}`].kind = isStop ? 'stop' : 'message_ignored';
            if (leadId) next.webhookEvents[`message:inbound:${messageSid}`].leadId = leadId;
          });
          if (!duplicate && isStop && leadId) {
            await changePrefs(next => { if (!next.optouts.includes(leadId)) next.optouts.push(leadId); });
          }
          return xml(res,200,'<?xml version="1.0" encoding="UTF-8"?><Response></Response>');
        }
        if (url.pathname === '/webhooks/twilio/message/status' || url.pathname === '/webhooks/twilio/voice/status') {
          const channel = url.pathname.includes('/message/') ? 'sms' : 'voice';
          const providerId = channel === 'sms' ? form.get('MessageSid') : form.get('CallSid');
          const providerStatus = channel === 'sms' ? form.get('MessageStatus') || form.get('SmsStatus') : form.get('CallStatus');
          const dispatchId = url.searchParams.get('dispatchId');
          if (!providerId || !providerStatus || !dispatchId) throw problem(400,'Incomplete status callback.');
          await rememberWebhook(`${channel}:status:${providerId}:${providerStatus}`,next => {
            const row = next.dispatches[dispatchId];
            if (!row || row.channel !== channel) return;
            if (row.providerId && row.providerId !== providerId) return;
            row.providerId = providerId;
            row.providerStatus = providerStatus;
            row.updatedAt = new Date().toISOString();
            if (channel === 'sms') {
              row.status = providerStatus === 'delivered' ? 'delivered'
                : ['failed','undelivered'].includes(providerStatus) ? 'provider_failed' : 'provider_accepted';
            } else {
              row.status = providerStatus === 'in-progress' ? 'answered'
                : providerStatus === 'completed' ? 'completed'
                : ['busy','failed','no-answer','canceled'].includes(providerStatus) ? 'provider_failed' : 'provider_accepted';
            }
          });
          res.writeHead(204,{'Cache-Control':'no-store'}); res.end(); return;
        }
        if (url.pathname === '/webhooks/twilio/voice/outbound') {
          const dispatchId = url.searchParams.get('dispatchId');
          const row = telecom.snapshot().dispatches[dispatchId];
          if (!row || row.channel !== 'voice') throw problem(404,'Call not found.');
          const callSid = form.get('CallSid');
          if (row.providerId && callSid && row.providerId !== callSid) throw problem(409,'Call identifier mismatch.');
          const session = sessionFor('voice_' + dispatchId);
          session.leadId = row.leadId;
          return xml(res,200,'<?xml version="1.0" encoding="UTF-8"?>' + twimlGather(dispatchId,row.openingText));
        }
        if (url.pathname === '/webhooks/twilio/voice/gather') {
          const dispatchId = url.searchParams.get('dispatchId');
          const row = telecom.snapshot().dispatches[dispatchId];
          if (!row || row.channel !== 'voice') throw problem(404,'Call not found.');
          const callSid = form.get('CallSid');
          if (row.providerId && callSid && row.providerId !== callSid) throw problem(409,'Call identifier mismatch.');
          const message = (form.get('SpeechResult') || form.get('Digits') || '').trim();
          if (!message) return xml(res,200,'<?xml version="1.0" encoding="UTF-8"?>' + twimlGather(dispatchId,'I did not catch that. Please say your ticket question, or say stop to opt out.'));
          const session = sessionFor('voice_' + dispatchId);
          session.leadId = row.leadId;
          let spoken = 'I am sorry, the ticket desk is taking too long. I can arrange a human follow-up instead.';
          let optedOut = false;
          try {
            const signal = AbortSignal.timeout(voiceTurnTimeoutMs);
            const result = await replyTurn({
              message, state:{...session.state,optedOut:prefs.optouts.includes(row.leadId)}, catalog, model, signal,
              mode:options.mode ?? agent.mode, timeoutMs:Math.max(50,voiceTurnTimeoutMs - 250),
            });
            session.state = result.state;
            spoken = result.text;
            optedOut = Boolean(result.state.optedOut);
            if (optedOut && !prefs.optouts.includes(row.leadId)) {
              await changePrefs(next => { if (!next.optouts.includes(row.leadId)) next.optouts.push(row.leadId); });
            }
          } catch { /* The spoken fallback above prevents dead air. */ }
          const response = optedOut
            ? `<Response><Say language="en-IN">${xmlEscape(spoken)}</Say><Hangup/></Response>`
            : twimlGather(dispatchId,spoken);
          return xml(res,200,'<?xml version="1.0" encoding="UTF-8"?>' + response);
        }
        throw problem(404,'Webhook not found.');
      }
      if (req.method === 'GET' && assets.has(url.pathname)) {
        const [file, type] = assets.get(url.pathname);
        const content = await readFile(resolve(root, 'public', file));
        res.writeHead(200, {'Content-Type': type, 'X-Content-Type-Options':'nosniff', 'Cache-Control':'no-cache'});
        res.end(content);
        return;
      }
      if (req.method === 'GET' && url.pathname === '/healthz') return json(res, 200, {ok:true});
      if (req.method === 'GET' && url.pathname === '/api/status') return json(res, 200, {
        ready: true,
        agent: agent.status,
        speechInput:speechInputStatus,
        telecom: telecomProvider.status,
        replyDeadlineMs: turnTimeoutMs,
        uptimeSeconds: Math.round(process.uptime()),
      });
      if (req.method === 'GET' && url.pathname === '/api/catalog') return json(res, 200, catalog);
      if (req.method === 'GET' && url.pathname === '/api/leads') {
        const now = clockFor(url.searchParams.get('clock'));
        return json(res, 200, {now, rows:planOutreach(leads, gateOptions(now))});
      }
      if (req.method === 'GET' && url.pathname === '/api/telecom') {
        const leadId = url.searchParams.get('leadId');
        if (leadId && !findLead(leadId)) throw problem(404,'Lead not found.');
        return json(res,200,telecomOverview(leadId));
      }
      if (req.method !== 'POST' || !['/api/chat','/api/transcribe','/api/outreach','/api/outreach/reset-rehearsal','/api/telecom/profile','/api/telecom/dispatch','/api/telecom/exotel-setup','/api/telecom/self-test'].includes(url.pathname)) throw problem(404, 'Page not found.');
      const origin = req.headers.origin;
      if (origin && new URL(origin).host !== req.headers.host) throw problem(403, 'Use the local app to send messages.');
      const body = await bodyOf(req,url.pathname === '/api/transcribe' ? 4 * 1024 * 1024 : limit);
      if(url.pathname==='/api/outreach/reset-rehearsal'){
        if(!origin || new URL(origin).host!==req.headers.host)throw problem(403,'Use the local rehearsal reset button.');
        if(body.clock!=='campaign')throw problem(409,'Rehearsal reset is available only with the Campaign example clock.');
        const campaignDay=dayKey(new Date(demoDate));
        let cleared=0;
        await changePrefs(async next=>{
          // Never reopen a recipient with a real provider dispatch. Consent,
          // opt-outs and the supplied lead file are not altered by a rehearsal reset.
          const realLeads=new Set(Object.values(telecom.snapshot().dispatches).filter(row=>row.provider!=='dry-run' && row.leadId).map(row=>row.leadId));
          const targets=Object.keys(next.contacts).filter(id=>next.contacts[id]===campaignDay && !realLeads.has(id));
          if(targets.length && storePath)await writeFile(storePath+'.before-rehearsal-reset-'+randomUUID()+'.json',JSON.stringify(next),{mode:0o600,flag:'wx'});
          for(const id of targets){delete next.contacts[id];cleared++;}
        });
        return json(res,200,{cleared,detail:'Rehearsal contacts reset. Opt-outs and real contact records preserved.'});
      }
      if(url.pathname==='/api/telecom/self-test'){
        if(!origin || new URL(origin).host!==req.headers.host)throw problem(403,'Use the local demo button.');
        if(body.confirmed!==true || telecomProvider.name!=='exotel' || !ownDemoPhone)throw problem(409,'Configure and confirm a test to your own verified phone first.');
        if(typeof body.idempotencyKey!=='string' || !/^[a-z\d_.:-]{8,100}$/i.test(body.idempotencyKey))throw problem(400,'Invalid test identifier.');
        const result=await queueTelecom(async()=>{
          const saved=telecom.snapshot(),key='self-test:'+body.idempotencyKey;
          if(saved.idempotency[key])return publicDispatch(saved.dispatches[saved.idempotency[key]],true);
          if(Object.values(saved.dispatches).some(row=>row.kind==='self_test' && Date.now()-Date.parse(row.createdAt)<60_000))throw problem(429,'Wait at least one minute before another demo call.');
          const id=randomUUID(),now=new Date().toISOString();
          await telecom.change(next=>{next.idempotency[key]=id;next.dispatches[id]={id,kind:'self_test',leadId:null,channel:'voice',provider:'exotel',status:'submitting',createdAt:now,updatedAt:now};});
          try{
            const accepted=await telecomProvider.startCall({to:ownDemoPhone,dispatchId:id});
            await telecom.change(next=>Object.assign(next.dispatches[id],{status:'provider_accepted',providerId:accepted.providerId,providerStatus:accepted.status,updatedAt:new Date().toISOString()}));
          }catch(error){await telecom.change(next=>Object.assign(next.dispatches[id],{status:'provider_rejected',updatedAt:new Date().toISOString()}));throw error;}
          return publicDispatch(telecom.snapshot().dispatches[id]);
        });
        return json(res,200,{dispatch:result});
      }
      if(url.pathname==='/api/telecom/exotel-setup'){
        if(!origin || new URL(origin).host!==req.headers.host)throw problem(403,'Use the local setup form.');
        if(!/^[a-z\d_-]{3,100}$/i.test(body.accountSid || '') || !/^\d{1,20}$/.test(body.flowId || ''))throw problem(400,'Enter a valid Exotel account SID and numeric flow ID.');
        for(const key of ['apiKey','apiToken'])if(typeof body[key]!=='string' || !/^[a-z\d_-]{8,200}$/i.test(body[key]))throw problem(400,'Enter the existing Exotel API key and token.');
        if(!/^\+?\d{8,15}$/.test(body.callerId || '') || !['singapore','mumbai'].includes(body.region))throw problem(400,'Check the caller ID and account region.');
        if(body.demoPhone && !findLead(body.leadId))throw problem(400,'Choose a demo lead first.');
        const demoPhone=body.demoPhone?normalizePhone(body.demoPhone):null;
        const config=Object.fromEntries(['accountSid','apiKey','apiToken','callerId','flowId','region'].map(key=>[key,body[key]]));
        config.demoPhone=demoPhone;
        await mkdir(dirname(exotelConfigPath),{recursive:true});
        await writeFile(exotelConfigPath+'.tmp',JSON.stringify(config),{mode:0o600});await rename(exotelConfigPath+'.tmp',exotelConfigPath);
        telecomProvider=createTelecomProvider({name:'exotel',...config});
        ownDemoPhone=demoPhone;
        if(demoPhone)await telecom.setPhone(body.leadId,demoPhone);
        return json(res,200,telecomOverview(body.leadId));
      }
      if (url.pathname === '/api/transcribe') {
        if (typeof body.audioBase64 !== 'string' || !body.audioBase64 || body.audioBase64.length > 3_750_000) {
          throw problem(400,'Provide a microphone recording under 2.5 MB.');
        }
        if (!audioFileName(body.mimeType)) throw problem(415,'Unsupported microphone recording format.');
        if (!/^[a-z\d+/]+={0,2}$/i.test(body.audioBase64)) throw problem(400,'Invalid microphone recording.');
        const audioBuffer = Buffer.from(body.audioBase64,'base64');
        if (audioBuffer.length < 32 || audioBuffer.length > 2_500_000) throw problem(400,'Provide a microphone recording under 2.5 MB.');
        const result = await transcriber({audioBuffer,mimeType:body.mimeType,signal:AbortSignal.timeout(options.transcriptionTimeoutMs ?? 15_000)});
        const text = result?.text?.trim();
        if (!text) throw problem(422,'No speech was detected in the recording.');
        if (text.length > 1800) throw problem(413,'The transcription is too long. Please record a shorter message.');
        return json(res,200,{text,provider:result.provider ?? speechInputStatus.provider,model:result.model ?? speechInputStatus.model});
      }
      if (url.pathname === '/api/telecom/profile') {
        if (!findLead(body.leadId)) throw problem(404,'Lead not found.');
        if (body.clear === true) await telecom.clearPhone(body.leadId);
        else await telecom.setPhone(body.leadId,body.phoneE164);
        return json(res,200,telecomOverview(body.leadId));
      }
      if (url.pathname === '/api/telecom/dispatch') {
        return json(res,200,{dispatch:await dispatchTelecom(body)});
      }
      if (url.pathname === '/api/outreach') {
        const now = clockFor(body.clock);
        let draft;
        await changePrefs(next => {
          draft = draftOutreach(leads, body.leadId, gateOptions(now,next));
          if (!draft.ok) throw problem(409, draft.reason || 'Outreach is unavailable.');
          next.contacts[body.leadId] = dayKey(now);
        });
        const sessionId = randomUUID();
        sessionFor(sessionId).leadId = body.leadId;
        return json(res,200,{sessionId,text:draft.row.first_message,leadId:body.leadId,channel:draft.row.channel});
      }
      if (typeof body.message !== 'string' || !body.message.trim() || body.message.length > 1800) throw problem(400,'Enter 1–1800 characters.');
      const sessionId = body.sessionId ?? randomUUID();
      const session = sessionFor(sessionId);
      if (session.locked) throw problem(409, 'The previous turn is still running.');
      const now = Date.now();
      session.requests = session.requests.filter(at => now - at < 60_000);
      if (session.requests.length >= (options.turnRateLimit ?? 30)) throw problem(429, 'Too many messages in this session. Please wait a minute.');
      session.requests.push(now);
      session.locked = true;
      try {
        const started = performance.now();
        const slow = body.scenario === 'slow';
        // The demo fault stays quick and repeatable without forcing the normal
        // cloud route to use the same short deadline.
        const deadlineMs = slow ? Math.min(turnTimeoutMs, 1600) : turnTimeoutMs;
        const signal = AbortSignal.timeout(deadlineMs);
        const turnModel = slow ? async () => { await delay(8000, null, {signal}); return {intent:'unknown'}; } : model;
        const state = {...session.state};
        if (session.leadId && prefs.optouts.includes(session.leadId)) state.optedOut = true;
        const result = await replyTurn({
          message: body.message.trim(), state, catalog, model: turnModel, signal,
          mode: slow ? 'model-first' : options.mode ?? agent.mode,
          timeoutMs: Math.max(50, deadlineMs - 250),
        });
        if (session.leadId && result.state.optedOut && !prefs.optouts.includes(session.leadId)) {
          await changePrefs(next => { if (!next.optouts.includes(session.leadId)) next.optouts.push(session.leadId); });
        }
        session.state = result.state;
        return json(res, 200, {text:result.text,...result,sessionId,elapsedMs:performance.now()-started,scenario:slow?'slow':'normal'});
      } finally { session.locked = false; }
    } catch (err) {
      if (!err.status) console.error(err);
      if (!res.headersSent) json(res, err.status || 500, {error:err.status ? err.message : 'The local desk could not finish this request.'});
      else res.end();
    }
  });
}
if (process.argv[1] && pathToFileURL(resolve(process.argv[1])).href === import.meta.url) {
  const port = Number(process.env.PORT || 4173);
  const server = await createApp();
  server.once('error', err => { console.error(err.message); process.exitCode=1; });
  server.listen(port, '127.0.0.1', () => console.log('Ticket Desk is running at http://127.0.0.1:' + port));
}
