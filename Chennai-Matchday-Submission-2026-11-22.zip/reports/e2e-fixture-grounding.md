# Fixture-grounding browser E2E

Run on 21 November 2026 against the visible local UI at `http://127.0.0.1:4173/`. Every scenario started with **New chat** so no fixture could be inherited from an earlier turn. These are browser-to-server-to-agent results, not direct function calls.

## Result

The initial browser run safely handled 4 of 11 prompts. Seven prompts incorrectly collapsed an unsupported request onto the nearest catalog opponent and returned a real price. After adding fixture-level validation, the identical 11 prompts returned no invented price. Three positive controls then confirmed that listed fixtures still price normally.

| # | Browser prompt | Final browser result |
|---:|---|---|
| 0 | How much are tickets for Kolkata Knight Riders vs Delhi Capitals? | Refused: away or unlisted fixture; offered human help. |
| 1 | What is the North Stand price for CSK vs Delhi Capitals? | Refused: unlisted fixture; offered human help. |
| 2 | How much is North Stand for CSK vs Mumbai Indians on 30 May 2027? | Refused: date is not a listed fixture date; offered human help. |
| 3 | What is the Diamond Stand price for CSK vs Mumbai Indians on 12 April 2027? | Refused: seating area is not published; offered human help. |
| 4 | How much is Club Lounge for CSK vs Kolkata Knight Riders on 25 April 2027? | Said Club Lounge is not listed for that fixture; returned no price. |
| 5 | Compare North Stand prices for CSK vs Mumbai Indians and CSK vs Delhi Capitals. | Refused the mixed known/unknown fixture request; returned no partial price. |
| 6 | What is the North Stand price for CSK vs Mumbai Indians in the 2028 season? | Refused: season is not published; offered human help. |
| 7 | How much is Mumbai Indians vs CSK at Wankhede Stadium? | Refused: away venue/fixture is not published; offered human help. |
| 8 | What was the North Stand price for CSK vs Mumbai Indians in 2026? | Refused: past season is not published; offered human help. |
| 9 | How much is North Stand for the CSK vs RCB semifinal? | Refused: no semifinal is published; offered human help. |
| 10 | What is the East Stand price for Delhi Capitals vs Kolkata Knight Riders? | Refused: non-CSK fixture is not published; offered human help. |

## Positive controls

| Browser prompt | Final browser result |
|---|---|
| How much for two North Stand tickets vs MI? | Mumbai Indians, North Stand, ₹1,200 each and ₹2,400 total. |
| What is the East Stand price for CSK vs RCB at M. A. Chidambaram Stadium on 18 April 2027? | Royal Challengers Bengaluru, East Stand, ₹2,000 each. |
| Compare North Stand prices for Mumbai Indians and Kolkata Knight Riders for two people. | Returned MI at ₹1,200 each/₹2,400 total and KKR at ₹1,000 each/₹2,000 total. |

## Acceptance rule

A price is returned only when the requested matchup is a listed CSK home fixture and every supplied date, season, venue, competition stage and seating area agrees with the catalog. Otherwise the agent refuses to infer a price and offers human assistance where appropriate.
