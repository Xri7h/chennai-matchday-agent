# Chennai Super Kings repeat-fan outreach plan

Four of the 20 repeat fans qualify for an opening message at the example campaign time, 1 April 2027 at 11:00 IST. Imran Gupta (L043) and Meera Menon (L057) qualify for SMS. Sameer Rao (L049) and Vihaan Patel (L052) qualify for a voice call. Six other leads are due for review in seven days, three are on hold, and seven are skipped. The prototype generates drafts using synthetic data. Its clock represents a campaign rehearsal.

The row-by-row plan includes every lead ID, score components, decision, channel, timing, proposed opening and reason. A blank channel or opening means the campaign takes no outreach action. For nurture rows the timestamp is a **review date** and the proposed copy is a preview. Rebuild the same snapshot from the project root with `node src/outreach.js`. [Campaign decisions](outreach.csv)

## Why this audience

These fans bought within the last eight months. We know they have bought tickets before, so the opening offers to help compare the new home fixtures or seats. It never assumes a supporter sat in a particular stand, has an active reservation, wants a discount, or still has seats in a cart.

## How the score works

| Component | Points |
| --- | --- |
| Intent, up to 40 | An abandoned cart adds 20. Zero site visits add 0, 1–2 add 8, 3–5 add 14 and 6 or more add 20. |
| Engagement, up to 30 | Each email open adds 3, capped at 15. Each SMS reply adds 7.5, capped at 15. |
| History, up to 30 | Each lifetime ticket adds 1.5, capped at 15. A last purchase within 0–6 months adds 15 and one 7–8 months ago adds 10. |
| Fatigue | Contact within the last seven days deducts 20. A contact today independently blocks outreach. The final score has a floor of zero. |

The thresholds are assumptions for a first campaign. A score of 50 or above can qualify for immediate contact. Scores from 30 up to 50 trigger a review seven days later. Lower scores stay on hold until fresh engagement arrives. Previous spend has no weight because the goal is to find returning fans interested in a match across budgets. The score ranks interest and has no power to grant permission.

Meera Menon (L057) earns 34 for a cart and four visits, 21 for two opens and two replies, and 21 for four tickets and a purchase two months ago. Her last contact was 15 days ago. The total is **76**. Both channels have consent, so SMS takes priority as the less intrusive option. If SMS is unavailable, voice requires its own affirmative consent.

## Contact rules and seed data

Every draft request recomputes eligibility. The application can pass current opt-outs and IDs already contacted on the current India date. The plan records all applicable blockers for a lead. Only an eligible `contact_now` row can be released for the interactive draft.

| Case | Action |
| --- | --- |
| Opt-out, no eligible channel, registered or unverified DND, contact today | Suppress the promotion. A blank channel permission disallows that channel. L058 has two unknown permissions. L045 has both DND and a same-day contact. |
| Suspected duplicate | Compare normalized full name and city across all 60 rows and check repeated lead IDs. Quarantine each match pending identity review. L003/L004 and L027/L028 match, and each pair contains conflicting permission data. They belong to other segments. The two repeat fans named Aarav Bose live in different cities and retain their own IDs. |
| Impossible value or missing purchase history | Flag and skip the row for review. L037 has −1 lifetime tickets in the win-back group. Repeat fan L053 has a missing purchase recency. Its displayed **33.5** uses zero recency points, and the missing value blocks contact. Empty purchase recency is expected for the 20 new buyers. |
| Other seed anomalies | L009 and L032 also have unknown permissions, and L015 was contacted today. These IDs remain in the supplied dataset and fall outside the repeat-fan campaign. |
| Missing or malformed fields | Suppress rows with incomplete identity, invalid nonnegative integer fields, invalid cart status, or history that conflicts with repeat-fan membership. Show a provisional score using zero for missing positive signals and the full fatigue penalty for unknown contact recency. |
| Time | Allow promotions from 10:00 inclusive until 19:00 exclusive, India time, for both SMS and voice. Outside the window, suggest the next opening and recheck eligibility there. A draft carries no authority to contact later. |

The supplied file has no telephone number, verified identity key, consent receipt, recipient-specific day/time preferences or timestamps for the underlying signals. Name and city are a screening heuristic. A second person can share both. Relative ages are interpreted as the sample campaign snapshot. A real campaign would refresh source data and apply revocations before attempting delivery.

## Indian communication preferences

TRAI provides separate preferences for communication mode, time band, day and category. Schedule II lists the bands before 10:00 and from 21:00 as off by default unless a subscriber changes them. The demo uses its own narrower 10:00–19:00 IST operating window, channel-specific affirmative consent and a blanket DND block required by the caselet. The regulations also distinguish registered explicit digital consent from ordinary customer records. [TRAI consolidated regulations, definitions and Schedule II](https://www.trai.gov.in/sites/default/files/2026-11/CR_10112026.pdf)

Connecting to real fans would require a registered sender and provider workflow for the applicable campaign, approved commercial sender identities and templates, preference and consent scrubbing, and a way to record and honor revocations. The browser voice rehearsal and CSV demonstrate the decision logic. [TRAI guidance for senders](https://www.trai.gov.in/advice-to-senders)
