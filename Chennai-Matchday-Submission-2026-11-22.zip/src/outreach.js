import { readFile, writeFile } from 'node:fs/promises';
import { pathToFileURL } from 'node:url';
import campaignCatalog from '../data/catalog.json' with { type: 'json' };

const seedUrl = new URL('../data/leads.csv', import.meta.url);
const reportUrl = new URL('../reports/outreach.csv', import.meta.url);
export const sampleCampaignTime = '2027-04-01T11:00:00+05:30';
const istOffset = 330 * 60_000;
const openingHour = 10;
const closingHour = 19;
const dayMs = 86_400_000;

// The supplied file has one record per line. Accept quoted fields and doubled quotes.
function readCsvLine(line) {
  const fields = [];
  let field = '';
  let quoted = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"' && quoted && line[i + 1] === '"') { field += '"'; i++; }
    else if (ch === '"') quoted = !quoted;
    else if (ch === ',' && !quoted) { fields.push(field); field = ''; }
    else field += ch;
  }
  if (quoted) throw new Error('Unclosed quote in lead file.');
  return [...fields, field];
}

export async function loadLeads() {
  const lines = (await readFile(seedUrl, 'utf8')).replace(/^\uFEFF/, '').trimEnd().split(/\r?\n/);
  const header = readCsvLine(lines.shift());
  return lines.map((line, index) => {
    const values = readCsvLine(line);
    if (values.length !== header.length) throw new Error(`Incorrect column count on lead file line ${index + 2}.`);
    return Object.fromEntries(header.map((key, col) => [key, values[col]]));
  });
}

function integer(value) {
  if (value == null || !/^\d+$/.test(String(value))) return null;
  const n = Number(value);
  return Number.isSafeInteger(n) ? n : null;
}

function scoreLead(lead) {
  const invalid = [];
  function read(field) {
    const n = integer(lead[field]);
    if (n === null) invalid.push(`missing or invalid ${field}`);
    // The report exposes this lower-bound treatment for invalid rows. Eligibility fails closed.
    return n;
  }
  const visits = read('site_visits_30d');
  const opens = read('email_opens_30d');
  const replies = read('sms_replies_30d');
  const tickets = read('tickets_bought_lifetime');
  const months = read('months_since_last_purchase');
  const days = read('days_since_last_contact');
  read('avg_ticket_spend_inr');
  if (tickets === 0 || (months !== null && months > 8)) invalid.push('inconsistent repeat-fan history');
  if (!['Y', 'N'].includes(lead.cart_abandon_30d)) invalid.push('unverified cart status');
  if (!lead.lead_id?.trim() || !lead.name?.trim() || !lead.city?.trim()) invalid.push('incomplete identity');

  const visitPoints = visits >= 6 ? 20 : visits >= 3 ? 14 : visits >= 1 ? 8 : 0;
  const intent = visitPoints + (lead.cart_abandon_30d === 'Y' ? 20 : 0);
  const engagement = Math.min(opens ?? 0, 5) * 3 + Math.min(replies ?? 0, 2) * 7.5;
  const recency = months === null || months > 8 ? 0 : months <= 6 ? 15 : 10;
  const history = Math.min(tickets ?? 0, 10) * 1.5 + recency;
  const fatigue = days === null || days < 7 ? -20 : 0;
  const score = Math.max(0, intent + engagement + history + fatigue);
  return {score, intent, engagement, history, fatigue, invalid};
}

const normalize = value => String(value ?? '').trim().toLowerCase().replace(/\s+/g, ' ');
function duplicateFlags(leads) {
  const ids = new Map();
  const people = new Map();
  const key = lead => normalize(lead.name) + '|' + normalize(lead.city);
  for (const lead of leads) {
    const id = normalize(lead.lead_id);
    ids.set(id, (ids.get(id) ?? 0) + 1);
    people.set(key(lead), [...(people.get(key(lead)) ?? []), lead.lead_id]);
  }
  return lead => {
    if (ids.get(normalize(lead.lead_id)) > 1) return 'repeated lead ID';
    const matches = people.get(key(lead));
    if (matches.length > 1) return 'possible duplicate with ' + matches.filter(id => id !== lead.lead_id).join(', ');
    return null;
  };
}

function istStamp(local) {
  return local.toISOString().slice(0, 19) + '+05:30';
}

function openingTime(local, daysAhead) {
  const next = new Date(local.getTime() + daysAhead * dayMs);
  next.setUTCHours(openingHour, 0, 0, 0);
  return istStamp(next);
}

function openingMessage(lead, channel, team) {
  const first = lead.name.trim().split(/\s+/)[0];
  const question = lead.cart_abandon_30d === 'Y'
    ? 'Would you like help comparing ticket options for a home match?'
    : 'Would you like the fixtures and seat prices for a home match?';
  if (channel === 'voice') return `Hello ${first}, this is the ${team} automated ticket assistant. ${question} You can say stop to opt out.`;
  return `Hi ${first}, ${team} ticket desk here. ${question} Reply STOP to opt out.`;
}

export function planOutreach(leads, {now = new Date(), optedOutIds = [], contactedTodayIds = [], team = campaignCatalog.team, channel: requestedChannel = null} = {}) {
  if (requestedChannel != null && !['sms','voice'].includes(requestedChannel)) throw new Error('Invalid outreach channel.');
  const local = new Date(new Date(now).getTime() + istOffset);
  if (Number.isNaN(local.getTime())) throw new Error('Invalid campaign time.');
  const optedOut = new Set(optedOutIds);
  const alreadyContacted = new Set(contactedTodayIds);
  const findDuplicate = duplicateFlags(leads);
  return leads.filter(lead => lead.segment === 'repeat_fan').map(lead => {
    const {score, intent, engagement, history, fatigue, invalid} = scoreLead(lead);
    const flags = [];
    const blockers = [];
    if (optedOut.has(lead.lead_id)) blockers.push('fan opted out');
    const channel = requestedChannel
      ? lead[`consent_${requestedChannel}`] === 'Y' ? requestedChannel : null
      : lead.consent_sms === 'Y' ? 'sms' : lead.consent_voice === 'Y' ? 'voice' : null;
    for (const key of ['consent_sms', 'consent_voice']) {
      if (!['Y', 'N'].includes(lead[key])) flags.push(`unknown ${key}`);
    }
    if (!channel) blockers.push(requestedChannel ? `no affirmative ${requestedChannel} consent` : 'no channel with affirmative consent');
    if (lead.dnd_registered === 'Y') blockers.push('DND registered');
    else if (lead.dnd_registered !== 'N') blockers.push('unverified DND status');
    if (integer(lead.days_since_last_contact) === 0 || alreadyContacted.has(lead.lead_id)) blockers.push('contacted today');
    const duplicate = findDuplicate(lead);
    if (duplicate) blockers.push(duplicate);
    blockers.push(...invalid);
    const row = {
      lead_id: lead.lead_id, name: lead.name, score, intent, engagement, history, fatigue,
      decision: 'skip', channel: null, scheduled_at: null, first_message: null,
      reason: '', flags: [...flags, ...blockers],
    };
    if (blockers.length) { row.reason = blockers.join(' / '); return row; }
    if (score < 30) {
      row.decision = 'hold';
      row.reason = 'Score below 30. Wait for fresh intent.';
      return row;
    }
    row.channel = channel;
    row.first_message = openingMessage(lead, channel, team);
    if (score < 50) {
      row.decision = 'nurture';
      row.scheduled_at = openingTime(local, 7);
      row.reason = 'Score from 30 to under 50. Review in seven days and rescore before contact.';
      return row;
    }
    const hour = local.getUTCHours();
    if (hour < openingHour || hour >= closingHour) {
      row.decision = 'schedule';
      row.scheduled_at = openingTime(local, hour >= closingHour ? 1 : 0);
      row.reason = 'Eligible score. Recheck the gates at the next campaign opening.';
      return row;
    }
    row.decision = 'contact_now';
    row.scheduled_at = istStamp(local);
    row.reason = 'Score at least 50, eligible channel and open campaign window.';
    return row;
  });
}

export function draftOutreach(leads, leadId, options = {}) {
  const row = planOutreach(leads, options).find(lead => lead.lead_id === leadId) ?? null;
  return {ok: row?.decision === 'contact_now', reason: row?.reason ?? 'Lead outside the repeat-fan cohort.', row};
}

// Rebuild the submitted scenario snapshot with Node alone.
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const rows = planOutreach(await loadLeads(), {now: sampleCampaignTime});
  const columns = Object.keys(rows[0]);
  const quote = value => '"' + String(value ?? '').replaceAll('"', '""') + '"';
  const lines = rows.map(row => columns.map(col => quote(Array.isArray(row[col]) ? row[col].join(' / ') : row[col])).join(','));
  await writeFile(reportUrl, [columns.join(','), ...lines, ''].join('\r\n'));
  console.log(`Wrote ${rows.length} repeat-fan decisions to reports/outreach.csv`);
}
