import test from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { mkdtemp, rm, writeFile, readFile, readdir } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { createApp } from '../server.mjs';
import { createDryRunTelecomProvider, createTwilioTelecomProvider, createExotelTelecomProvider, twilioSignature } from '../src/telecom.js';

async function open(t, opts={}) {
  // Tests stay deterministic even when the developer has a real .env file.
  // Individual cases can still override apiKey when testing cloud readiness.
  const app = await createApp({storePath:null, telecomStorePath:null, telecomProvider:createDryRunTelecomProvider(), apiKey:'', ...opts});
  app.listen(0, '127.0.0.1');
  await once(app, 'listening');
  t.after(() => new Promise(done => { app.close(done); app.closeAllConnections(); }));
  const base = 'http://127.0.0.1:' + app.address().port;
  return async (route, data, request={}) => {
    const init = request.form
      ? {method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded',...(request.headers || {})},body:request.form.toString()}
      : data ? {method:'POST',headers:{'Content-Type':'application/json',...(request.localOrigin?{Origin:base}:{}),...(request.headers || {})},body:JSON.stringify(data)} : {};
    const res = await fetch(base+route,init);
    const type = res.headers.get('content-type') || '';
    if (/application\/json/.test(type)) return {status:res.status,...await res.json()};
    return {status:res.status,text:await res.text()};
  };
}

test('campaign simulation suppresses repeat contact and preserves opt-outs after restart', async t => {
  const temp = await mkdtemp(path.join(tmpdir(),'boundary-test-'));
  t.after(() => rm(temp,{recursive:true,force:true}));
  const storePath = path.join(temp,'preferences.json');
  const api = await open(t,{storePath});
  const leads = await api('/api/leads');
  assert.equal(leads.rows.length,20);
  assert.equal((await api('/api/outreach',{leadId:'L053'})).status,409);
  const batch = await Promise.all([1,2].map(()=>api('/api/outreach',{leadId:'L057'})));
  assert.deepEqual(batch.map(r=>r.status).sort(),[200,409]);
  const chat = batch.find(r=>r.status===200);
  assert.match(chat.text,/Meera/);
  const stop = await api('/api/chat',{sessionId:chat.sessionId,message:'STOP'});
  assert.equal(stop.state.optedOut,true);
  const restarted=await open(t,{storePath});
  const suppressed=(await restarted('/api/leads')).rows.find(r=>r.lead_id==='L057');
  assert.equal(suppressed.decision,'skip');
  assert.match(suppressed.reason,/opted out/);
});

test('rehearsal reset restores previews but preserves opt-outs, real contacts, and backups',async t=>{
  const dir=await mkdtemp(path.join(tmpdir(),'rehearsal-reset-'));
  t.after(()=>rm(dir,{recursive:true,force:true}));
  const storePath=path.join(dir,'preferences.json');
  await writeFile(storePath,JSON.stringify({optouts:['L043'],contacts:{L052:'2027-04-01',L049:'2027-04-01',L057:'2026-11-22'}}));
  const telecomStore={snapshot:()=>({profiles:{},dispatches:{real:{leadId:'L049',provider:'exotel'}}})};
  const api=await open(t,{storePath,telecomStore});
  assert.equal((await api('/api/outreach/reset-rehearsal',{clock:'campaign'})).status,403);
  assert.equal((await api('/api/outreach/reset-rehearsal',{clock:'live'},{localOrigin:true})).status,409);
  const reset=await api('/api/outreach/reset-rehearsal',{clock:'campaign'},{localOrigin:true});
  assert.equal(reset.cleared,1);
  const stored=JSON.parse(await readFile(storePath,'utf8'));
  assert.deepEqual(stored.optouts,['L043']);
  assert.deepEqual(stored.contacts,{L049:'2027-04-01',L057:'2026-11-22'});
  assert.equal((await readdir(dir)).filter(name=>name.includes('before-rehearsal-reset')).length,1);
  const rows=(await api('/api/leads?clock=campaign')).rows;
  assert.equal(rows.find(row=>row.lead_id==='L052').decision,'contact_now');
  assert.match(rows.find(row=>row.lead_id==='L043').reason,/opted out/);
  assert.match(rows.find(row=>row.lead_id==='L045').reason,/DND/);
  assert.equal((await api('/api/outreach/reset-rehearsal',{clock:'campaign'},{localOrigin:true})).cleared,0);
});

test('chat separates sessions, remembers group, and times out with a reply', async t => {
  const api = await open(t,{timeoutMs:100});
  const first = await api('/api/chat',{message:'Two tickets for MI in the North Stand, please.'});
  assert.equal(first.state.groupSize,2);
  assert.equal(first.state.matchId,'M1');
  assert.match(first.text,/2,400/);
  const next = await api('/api/chat',{sessionId:first.sessionId,message:'And East Stand?'});
  assert.equal(next.state.groupSize,2);
  assert.match(next.text,/3,600/);
  const isolated = await api('/api/chat',{message:'Hello'});
  assert.equal(isolated.state.groupSize,undefined);
  const slow = await api('/api/chat',{sessionId:first.sessionId,message:'Show me the home fixtures',scenario:'slow'});
  assert.equal(slow.source,'fallback');
  assert.ok(slow.modelMs >= 50 && slow.modelMs < 1500);
  assert.match(slow.text,/human/i);
  assert.equal((await api('/api/chat',{message:' '})).status,400);
});

test('status endpoint exposes provider readiness without exposing credentials', async t => {
  const api = await open(t, {
    groqApiKey: '',
    apiKey: 'do-not-return-me',
    provider: 'gemini',
    cloudModel: async () => ({intent:'greet'}),
    localModel: async () => ({intent:'greet'}),
  });
  const status = await api('/api/status');
  assert.equal(status.status, 200);
  assert.equal(status.agent.configured, true);
  assert.equal(status.agent.provider, 'gemini');
  assert.equal(JSON.stringify(status).includes('do-not-return-me'), false);
  assert.equal((await api('/healthz')).ok, true);
});

test('browser microphone audio is validated and transcribed without being stored', async t => {
  let received;
  const transcriber=async input=>{
    received={bytes:input.audioBuffer.length,mimeType:input.mimeType};
    return {text:'Two tickets for Mumbai Indians in the North Stand.',provider:'test-stt',model:'test-whisper'};
  };
  const api=await open(t,{transcriber,speechInputStatus:{configured:true,provider:'test-stt',model:'test-whisper',detail:'Test transcription.'}});
  const audioBase64=Buffer.alloc(128,7).toString('base64');
  const result=await api('/api/transcribe',{audioBase64,mimeType:'audio/webm;codecs=opus'});
  assert.equal(result.status,200);
  assert.equal(result.text,'Two tickets for Mumbai Indians in the North Stand.');
  assert.deepEqual(received,{bytes:128,mimeType:'audio/webm;codecs=opus'});
  assert.equal((await api('/api/transcribe',{audioBase64,mimeType:'audio/flac'})).status,415);
  assert.equal((await api('/api/transcribe',{audioBase64:'not base64',mimeType:'audio/webm'})).status,400);
  assert.equal((await api('/api/transcribe',{audioBase64,mimeType:'audio/webm'},{headers:{Origin:'https://evil.example'}})).status,403);
});

test('telecom dry-run stores the demo number privately, rechecks gates, and is idempotent', async t => {
  const api = await open(t,{telecomNow:()=>'2027-04-01T11:00:00+05:30'});
  const phone = '+1' + '5'.repeat(10);
  const profile = await api('/api/telecom/profile',{leadId:'L057',phoneE164:phone});
  assert.equal(profile.profile.phoneConfigured,true);
  assert.equal(JSON.stringify(profile).includes(phone),false);
  const key = 'test-dispatch-0001';
  const first = await api('/api/telecom/dispatch',{leadId:'L057',channel:'sms',idempotencyKey:key});
  const replay = await api('/api/telecom/dispatch',{leadId:'L057',channel:'sms',idempotencyKey:key});
  assert.equal(first.dispatch.status,'dry_run_accepted');
  assert.equal(replay.dispatch.id,first.dispatch.id);
  assert.equal(replay.dispatch.replayed,true);
  await api('/api/telecom/profile',{leadId:'L047',phoneE164:phone});
  const dnd = await api('/api/telecom/dispatch',{leadId:'L047',channel:'voice',idempotencyKey:'test-dispatch-0002'});
  assert.equal(dnd.status,409);
  assert.match(dnd.error,/DND registered/);
});

test('Exotel dispatch enforces score, DND, real hours, and single accepted contact',async t=>{
  let calls=0;
  const provider=createExotelTelecomProvider({accountSid:'test',apiKey:'test',apiToken:'test',callerId:'08000000000',flowId:'123',
    fetchImpl:async()=>{calls++;return new Response(JSON.stringify({Call:{Sid:'test-call',Status:'queued'}}),{status:200});}});
  const api=await open(t,{telecomProvider:provider,telecomNow:()=>'2027-04-01T11:00:00+05:30'});
  for(const leadId of ['L049','L047','L050'])await api('/api/telecom/profile',{leadId,phoneE164:'+15555550101'});
  for(const leadId of ['L047','L050'])assert.equal((await api('/api/telecom/dispatch',{leadId,channel:'voice',idempotencyKey:'blocked-'+leadId})).status,409);
  const body={leadId:'L049',channel:'voice',idempotencyKey:'exotel-idempotent'};
  assert.equal((await api('/api/telecom/dispatch',body)).dispatch.status,'provider_accepted');
  assert.equal((await api('/api/telecom/dispatch',body)).dispatch.replayed,true);
  assert.equal((await api('/api/telecom/dispatch',{...body,idempotencyKey:'second-attempt'})).status,409);
  assert.equal(calls,1);
  const closed=await open(t,{telecomProvider:provider,telecomNow:()=>'2027-04-01T22:00:00+05:30'});
  await closed('/api/telecom/profile',{leadId:'L049',phoneE164:'+15555550101'});
  assert.equal((await closed('/api/telecom/dispatch',{...body,clock:'campaign'})).status,409);
  assert.equal(calls,1);
});

test('personal Exotel demo calls only the saved owner phone and is idempotent and throttled',async t=>{
  let calls=0;
  const provider=createExotelTelecomProvider({accountSid:'test',apiKey:'test',apiToken:'test',callerId:'08000000000',flowId:'123',fetchImpl:async(url,init)=>{
    calls++;assert.equal(init.body.get('From'),'+15555550101');return new Response(JSON.stringify({Call:{Sid:'self-test-call',Status:'queued'}}),{status:200});
  }});
  const api=await open(t,{telecomProvider:provider,ownDemoPhone:'+15555550101'});
  const body={confirmed:true,idempotencyKey:'personal-test-1',to:'+15555550999'};
  assert.equal((await api('/api/telecom/self-test',body)).status,403);
  assert.equal((await api('/api/telecom/self-test',{...body,confirmed:false},{localOrigin:true})).status,409);
  assert.equal((await api('/api/telecom/self-test',body,{localOrigin:true})).dispatch.status,'provider_accepted');
  assert.equal((await api('/api/telecom/self-test',body,{localOrigin:true})).dispatch.replayed,true);
  assert.equal((await api('/api/telecom/self-test',{...body,idempotencyKey:'personal-test-2'},{localOrigin:true})).status,429);
  assert.equal(calls,1);
});

test('signed inbound STOP persists suppression and forged Twilio webhooks are rejected', async t => {
  const publicBaseUrl = 'https://demo.example';
  const authToken = 'test-auth-token';
  const provider = createTwilioTelecomProvider({
    accountSid:'AC_TEST', authToken, fromNumber:'+15555550101', publicBaseUrl,
    fetchImpl:async () => { throw new Error('No outbound provider call expected.'); },
  });
  const api = await open(t,{telecomProvider:provider});
  const phone = '+1' + '5'.repeat(10);
  await api('/api/telecom/profile',{leadId:'L057',phoneE164:phone});
  const route = '/webhooks/twilio/message/inbound';
  const form = new URLSearchParams({MessageSid:'SM_STOP_TEST',From:phone,To:'+15555550101',Body:'STOP'});
  const signature = twilioSignature(authToken,publicBaseUrl+route,form);
  const accepted = await api(route,null,{form,headers:{'X-Twilio-Signature':signature}});
  assert.equal(accepted.status,200);
  assert.match(accepted.text,/<Response>/);
  const suppressed=(await api('/api/leads')).rows.find(row=>row.lead_id==='L057');
  assert.match(suppressed.reason,/opted out/);
  const forged = await api(route,null,{form:new URLSearchParams({...Object.fromEntries(form),MessageSid:'SM_FORGED'}),headers:{'X-Twilio-Signature':'invalid'}});
  assert.equal(forged.status,403);
});

test('accepted call exposes signed TwiML speech and a grounded Gather turn', async t => {
  const publicBaseUrl = 'https://demo.example';
  const authToken = 'voice-test-token';
  const provider = createTwilioTelecomProvider({
    accountSid:'AC_TEST', authToken, fromNumber:'+15555550101', publicBaseUrl,
    fetchImpl:async () => new Response(JSON.stringify({sid:'CA_VOICE_TEST',status:'queued'}),{status:201,headers:{'Content-Type':'application/json'}}),
  });
  const api = await open(t,{telecomProvider:provider,telecomNow:()=>'2027-04-01T11:00:00+05:30'});
  const phone = '+1' + '5'.repeat(10);
  await api('/api/telecom/profile',{leadId:'L057',phoneE164:phone});
  const sent = await api('/api/telecom/dispatch',{leadId:'L057',channel:'voice',idempotencyKey:'voice-dispatch-001'});
  assert.equal(sent.dispatch.status,'provider_accepted');
  const firstRoute = `/webhooks/twilio/voice/outbound?dispatchId=${sent.dispatch.id}`;
  const firstForm = new URLSearchParams({CallSid:'CA_VOICE_TEST'});
  const first = await api(firstRoute,null,{form:firstForm,headers:{'X-Twilio-Signature':twilioSignature(authToken,publicBaseUrl+firstRoute,firstForm)}});
  assert.equal(first.status,200);
  assert.match(first.text,/<Gather/);
  assert.match(first.text,/automated ticket assistant/);
  const gatherRoute = `/webhooks/twilio/voice/gather?dispatchId=${sent.dispatch.id}`;
  const gatherForm = new URLSearchParams({CallSid:'CA_VOICE_TEST',SpeechResult:'What is the North Stand price for the Mumbai Indians match?'});
  const gather = await api(gatherRoute,null,{form:gatherForm,headers:{'X-Twilio-Signature':twilioSignature(authToken,publicBaseUrl+gatherRoute,gatherForm)}});
  assert.equal(gather.status,200);
  assert.match(gather.text,/1,200/);
  assert.match(gather.text,/<Say/);
  const answeredRoute = `/webhooks/twilio/voice/status?dispatchId=${sent.dispatch.id}`;
  const answeredForm = new URLSearchParams({CallSid:'CA_VOICE_TEST',CallStatus:'in-progress'});
  assert.equal((await api(answeredRoute,null,{form:answeredForm,headers:{'X-Twilio-Signature':twilioSignature(authToken,publicBaseUrl+answeredRoute,answeredForm)}})).status,204);
  assert.equal((await api('/api/telecom?leadId=L057')).dispatches[0].status,'answered');
  const completedForm = new URLSearchParams({CallSid:'CA_VOICE_TEST',CallStatus:'completed'});
  assert.equal((await api(answeredRoute,null,{form:completedForm,headers:{'X-Twilio-Signature':twilioSignature(authToken,publicBaseUrl+answeredRoute,completedForm)}})).status,204);
  assert.equal((await api('/api/telecom?leadId=L057')).dispatches[0].status,'completed');
});

test('signed SMS delivery callback upgrades provider acceptance to delivered', async t => {
  const publicBaseUrl = 'https://demo.example';
  const authToken = 'sms-test-token';
  const provider = createTwilioTelecomProvider({
    accountSid:'AC_TEST',authToken,fromNumber:'+15555550101',publicBaseUrl,
    fetchImpl:async () => new Response(JSON.stringify({sid:'SM_DELIVERY_TEST',status:'queued'}),{status:201,headers:{'Content-Type':'application/json'}}),
  });
  const api = await open(t,{telecomProvider:provider,telecomNow:()=>'2027-04-01T11:00:00+05:30'});
  const phone = '+1' + '5'.repeat(10);
  await api('/api/telecom/profile',{leadId:'L057',phoneE164:phone});
  const sent = await api('/api/telecom/dispatch',{leadId:'L057',channel:'sms',idempotencyKey:'sms-delivery-001'});
  assert.equal(sent.dispatch.status,'provider_accepted');
  const route = `/webhooks/twilio/message/status?dispatchId=${sent.dispatch.id}`;
  const form = new URLSearchParams({MessageSid:'SM_DELIVERY_TEST',MessageStatus:'delivered'});
  const signature = twilioSignature(authToken,publicBaseUrl+route,form);
  assert.equal((await api(route,null,{form,headers:{'X-Twilio-Signature':signature}})).status,204);
  assert.equal((await api('/api/telecom?leadId=L057')).dispatches[0].status,'delivered');
});

test('voice Gather returns a spoken fallback instead of dead air when the model stalls', async t => {
  const publicBaseUrl = 'https://demo.example';
  const authToken = 'slow-voice-token';
  const provider = createTwilioTelecomProvider({
    accountSid:'AC_TEST',authToken,fromNumber:'+15555550101',publicBaseUrl,
    fetchImpl:async () => new Response(JSON.stringify({sid:'CA_SLOW_TEST',status:'queued'}),{status:201,headers:{'Content-Type':'application/json'}}),
  });
  const api = await open(t,{
    telecomProvider:provider,telecomNow:()=>'2027-04-01T11:00:00+05:30',voiceTurnTimeoutMs:120,
    model:async () => new Promise(() => {}),mode:'model-first',
  });
  const phone = '+1' + '5'.repeat(10);
  await api('/api/telecom/profile',{leadId:'L057',phoneE164:phone});
  const sent = await api('/api/telecom/dispatch',{leadId:'L057',channel:'voice',idempotencyKey:'slow-voice-001'});
  const route = `/webhooks/twilio/voice/gather?dispatchId=${sent.dispatch.id}`;
  const form = new URLSearchParams({CallSid:'CA_SLOW_TEST',SpeechResult:'Tell me something the catalog has never seen before.'});
  const started = performance.now();
  const result = await api(route,null,{form,headers:{'X-Twilio-Signature':twilioSignature(authToken,publicBaseUrl+route,form)}});
  assert.equal(result.status,200);
  assert.ok(performance.now() - started < 1000);
  assert.match(result.text,/<Say/);
  assert.match(result.text,/human|taking too long/i);
});
