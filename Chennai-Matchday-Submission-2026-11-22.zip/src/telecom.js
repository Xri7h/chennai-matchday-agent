import { createHmac, randomUUID, timingSafeEqual } from 'node:crypto';
import { mkdir, readFile, rename, writeFile } from 'node:fs/promises';
import { dirname } from 'node:path';

const defaultState = () => ({version:1, profiles:{}, dispatches:{}, idempotency:{}, webhookEvents:{}});

export function normalizePhone(value) {
  const phone = String(value ?? '').trim().replace(/[\s()-]/g, '');
  if (!/^\+[1-9]\d{7,14}$/.test(phone)) throw Object.assign(new Error('Enter a phone number in E.164 format, such as +91 followed by the mobile number.'), {status:400});
  return phone;
}

export function xmlEscape(value) {
  return String(value ?? '').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&apos;');
}

export function twilioSignature(authToken, url, parameters) {
  const entries = parameters instanceof URLSearchParams ? [...parameters.entries()] : Object.entries(parameters ?? {});
  entries.sort(([left],[right]) => left < right ? -1 : left > right ? 1 : 0);
  const source = entries.reduce((text,[key,value]) => text + key + value, url);
  return createHmac('sha1', authToken).update(source).digest('base64');
}

function safeEqual(left, right) {
  const a = Buffer.from(String(left ?? ''));
  const b = Buffer.from(String(right ?? ''));
  return a.length === b.length && timingSafeEqual(a,b);
}

export async function createTelecomStore(storePath) {
  let state = defaultState();
  if (storePath) {
    try { state = JSON.parse(await readFile(storePath,'utf8')); }
    catch (error) { if (error.code !== 'ENOENT') throw error; }
  }
  if (state.version !== 1 || !state.profiles || !state.dispatches || !state.idempotency || !state.webhookEvents) {
    throw new Error('Invalid private telecom store.');
  }
  let pending = Promise.resolve();
  async function persist(next) {
    if (!storePath) return;
    await mkdir(dirname(storePath),{recursive:true});
    const temporary = storePath + '.tmp';
    await writeFile(temporary,JSON.stringify(next),{mode:0o600});
    await rename(temporary,storePath);
  }
  function change(update) {
    const work = pending.then(async () => {
      const next = structuredClone(state);
      const result = await update(next);
      await persist(next);
      state = next;
      return result;
    });
    pending = work.catch(() => {});
    return work;
  }
  return {
    snapshot: () => structuredClone(state),
    change,
    async setPhone(leadId, value) {
      const phoneE164 = normalizePhone(value);
      await change(next => { next.profiles[leadId] = {phoneE164, updatedAt:new Date().toISOString()}; });
    },
    async clearPhone(leadId) {
      await change(next => { delete next.profiles[leadId]; });
    },
  };
}

export function createDryRunTelecomProvider() {
  return {
    name:'dry-run',
    real:false,
    status:{provider:'dry-run', configured:true, real:false, label:'Local dry-run', detail:'Records an accepted rehearsal without contacting a carrier.'},
    async sendSms() { return {providerId:'dry-sms-' + randomUUID(), status:'dry_run_accepted'}; },
    async startCall() { return {providerId:'dry-call-' + randomUUID(), status:'dry_run_accepted'}; },
    verifyWebhook() { return false; },
  };
}

export function createTwilioTelecomProvider({
  accountSid = process.env.TWILIO_ACCOUNT_SID,
  authToken = process.env.TWILIO_AUTH_TOKEN,
  fromNumber = process.env.TWILIO_FROM_NUMBER,
  messagingServiceSid = process.env.TWILIO_MESSAGING_SERVICE_SID,
  contentSid = process.env.TWILIO_CONTENT_SID,
  publicBaseUrl = process.env.PUBLIC_BASE_URL,
  endpoint = 'https://api.twilio.com',
  fetchImpl = fetch,
  timeoutMs = 10_000,
} = {}) {
  const base = String(publicBaseUrl ?? '').replace(/\/$/,'');
  const configured = Boolean(accountSid && authToken && fromNumber && base);
  async function request(resource, form) {
    if (!configured) throw Object.assign(new Error('Twilio is selected but its server-side configuration is incomplete.'),{status:503});
    const response = await fetchImpl(`${endpoint}/2010-04-01/Accounts/${encodeURIComponent(accountSid)}/${resource}.json`,{
      method:'POST',
      headers:{
        Authorization:'Basic ' + Buffer.from(`${accountSid}:${authToken}`).toString('base64'),
        'Content-Type':'application/x-www-form-urlencoded',
      },
      body:new URLSearchParams(form),
      signal:AbortSignal.timeout(timeoutMs),
    });
    let payload = {};
    try { payload = await response.json(); } catch { /* A status code is enough for a safe error. */ }
    if (!response.ok || !payload.sid) {
      const code = payload.code ? `, code ${String(payload.code).replace(/[^\w.-]/g,'')}` : '';
      throw Object.assign(new Error(`Twilio rejected the request (HTTP ${response.status}${code}).`),{status:502,providerCode:payload.code});
    }
    return payload;
  }
  return {
    name:'twilio',
    real:true,
    publicBaseUrl:base,
    status:{
      provider:'twilio', configured, real:true, label:'Twilio Programmable Messaging and Voice',
      detail:configured ? 'Ready for an explicitly approved real test.' : 'Add the required server-side Twilio settings before a real test.',
    },
    async sendSms({to,text,dispatchId}) {
      const payload = await request('Messages',{
        To:to,
        ...(messagingServiceSid ? {MessagingServiceSid:messagingServiceSid} : {From:fromNumber}),
        ...(contentSid ? {ContentSid:contentSid} : {Body:text}),
        StatusCallback:`${base}/webhooks/twilio/message/status?dispatchId=${encodeURIComponent(dispatchId)}`,
      });
      return {providerId:payload.sid,status:payload.status || 'queued'};
    },
    async startCall({to,dispatchId}) {
      const payload = await request('Calls',{
        To:to,
        From:fromNumber,
        Url:`${base}/webhooks/twilio/voice/outbound?dispatchId=${encodeURIComponent(dispatchId)}`,
        Method:'POST',
        StatusCallback:`${base}/webhooks/twilio/voice/status?dispatchId=${encodeURIComponent(dispatchId)}`,
        StatusCallbackMethod:'POST',
        StatusCallbackEvent:'initiated ringing answered completed',
      });
      return {providerId:payload.sid,status:payload.status || 'queued'};
    },
    verifyWebhook({url,parameters,signature}) {
      if (!configured || !signature) return false;
      return safeEqual(twilioSignature(authToken,url,parameters),signature);
    },
  };
}

export function createTelecomProvider(options = {}) {
  const name = String(options.name ?? process.env.TELECOM_PROVIDER ?? 'dry-run').toLowerCase();
  if (name === 'dry-run') return createDryRunTelecomProvider();
  if (name === 'twilio') return createTwilioTelecomProvider(options);
  if (name === 'exotel') return createExotelTelecomProvider(options);
  throw new Error(`Unsupported telecom provider: ${name}`);
}

export function createExotelTelecomProvider({
  accountSid=process.env.EXOTEL_ACCOUNT_SID, apiKey=process.env.EXOTEL_API_KEY,
  apiToken=process.env.EXOTEL_API_TOKEN, callerId=process.env.EXOTEL_CALLER_ID,
  flowId=process.env.EXOTEL_FLOW_ID, region=process.env.EXOTEL_REGION || 'singapore',
  fetchImpl=fetch, timeoutMs=10_000,
}={}) {
  const configured=Boolean(accountSid && apiKey && apiToken && callerId && flowId);
  const host=region==='mumbai'?'api.in.exotel.com':'api.exotel.com';
  return {
    name:'exotel',real:true,
    status:{provider:'exotel',configured,real:true,channels:['voice'],label:'Exotel voice agent',
      detail:configured?'Calls connect the verified demo phone to the configured voice agent.':'Complete the private Exotel setup to enable calls.'},
    async startCall({to,dispatchId}) {
      if(!configured)throw Object.assign(new Error('Exotel configuration is incomplete.'),{status:503});
      const response=await fetchImpl(`https://${host}/v1/Accounts/${encodeURIComponent(accountSid)}/Calls/connect.json`,{
        method:'POST',headers:{Authorization:'Basic '+Buffer.from(`${apiKey}:${apiToken}`).toString('base64'),'Content-Type':'application/x-www-form-urlencoded'},
        body:new URLSearchParams({From:normalizePhone(to),CallerId:callerId,Url:`https://my.exotel.com/${encodeURIComponent(accountSid)}/exoml/start_voice/${encodeURIComponent(flowId)}`,
          TimeLimit:'180',TimeOut:'30',CustomField:dispatchId}),signal:AbortSignal.timeout(timeoutMs),
      });
      let payload={};try{payload=await response.json();}catch{}
      const call=payload.Call ?? payload.TwilioResponse?.Call;
      if(!response.ok || !call?.Sid)throw Object.assign(new Error(`Exotel did not confirm call acceptance (HTTP ${response.status}). Check verified recipient, credits and API settings.`),{status:502});
      return {providerId:call.Sid,status:call.Status || 'queued'};
    },
    async sendSms(){throw Object.assign(new Error('This Exotel connection supports voice only. Live SMS is not configured.'),{status:409});},
    verifyWebhook(){return false;},
  };
}
