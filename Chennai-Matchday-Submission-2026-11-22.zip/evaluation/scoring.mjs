import { readFile } from 'node:fs/promises';
import { isDeepStrictEqual } from 'node:util';

export const root = new URL('../', import.meta.url);
export const loadJson = async path => JSON.parse(await readFile(new URL(path, root), 'utf8'));

export function scoreTurn(expected, actual) {
  const failures = [];
  const text = String(actual.text ?? '').replace(/[’‘]/g, "'");
  const matches = pattern => new RegExp(pattern, 'iu').test(text);
  if (!text.trim()) failures.push('empty response');
  for (const pattern of expected.all ?? []) {
    if (!matches(pattern)) failures.push(`missing expected content /${pattern}/`);
  }
  for (const pattern of expected.none ?? []) {
    if (matches(pattern)) failures.push(`forbidden claim or pitch /${pattern}/`);
  }
  if (expected.handoff && !matches('human|ticket(?:ing)? (?:team|desk|staff|support)|member of (?:the|our) team|support (?:team|agent)|representative')) {
    failures.push('missing human handoff');
  }
  for (const [key, value] of Object.entries(expected.state ?? {})) {
    if (!isDeepStrictEqual(actual.state?.[key], value)) {
      failures.push(`state.${key} expected ${JSON.stringify(value)}, got ${JSON.stringify(actual.state?.[key])}`);
    }
  }
  return failures;
}

export async function runSuite(cases, respond) {
  const rows = [];
  for (const scenario of cases) {
    let state = {};
    for (const [index, turn] of scenario.turns.entries()) {
      const result = await respond({ message: turn.fan, state, sessionId: scenario.id });
      const failures = scoreTurn(turn, result);
      rows.push({
        id: `${scenario.id}.${index + 1}`, fan: turn.fan, expected: turn.expect,
        text: result.text, state: result.state, source: result.source, intent: result.intent,
        provider: result.provider, providerMeta:result.providerMeta,
        modelMs: result.modelMs, logicMs: result.logicMs, firstTextMs:result.firstTextMs,
        pass: failures.length === 0, failures,
      });
      state = result.state ?? {};
    }
  }
  return rows;
}

export const nearestRank = (values, fraction) => {
  if (values.length === 0) throw new Error('Cannot summarize an empty sample');
  const sorted = [...values].sort((a, b) => a - b);
  return sorted[Math.max(0, Math.ceil(fraction * sorted.length) - 1)];
};

export function median(values) {
  if (!values.length) throw new Error('Cannot summarize an empty sample');
  const sorted = [...values].sort((a,b) => a-b);
  const center = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[center] : (sorted[center - 1] + sorted[center]) / 2;
}
