# Chennai Matchday

Chennai Matchday is an independent IPL ticket-sales caselet for **Chennai Super Kings** at M. A. Chidambaram Stadium, Chepauk. It scores repeat-fan leads, rehearses consent-aware outreach, and helps a fan choose an invented 2027 home fixture and seating area. It is not an official CSK service; fixtures, prices, policies, inventory and all fan records are synthetic assignment data.

**Submission video:** [Chennai Matchday walkthrough and live phone demonstration](https://www.loom.com/share/3c6af046dd7d43e4b586fb49e6a28f17). Start with the [deliverables and limitations](SUBMISSION.md) for a map of the evidence.

## What to install

You need:

- **Node.js 22 or newer** ([download](https://nodejs.org/en/download)); this build was verified with Node 24.14.1.
- **Chrome or Edge**.
- A **Groq API key** from [Groq Console](https://console.groq.com/keys) for the preferred hosted planner.
- Optional: a **Gemini API key** from [Google AI Studio](https://aistudio.google.com/app/apikey) for the hosted fallback.
- Optional: an existing **Exotel voice-agent account** for the demonstrated phone route, or a **Twilio account** for the alternative adapter. Only use your own verified phone number. Browser speech also provides the assignment's voice option.

There is no `npm install`, database, Docker, Python or paid package. The server uses Node built-ins. The bundled Potion model is the final local fallback.

## Configure and run on Windows

1. Open PowerShell in the folder containing `server.mjs`.
2. Create the local environment file:

   ```powershell
   Copy-Item .env.example .env
   notepad .env
   ```

3. Paste keys only for providers you want to use; leave an unused key blank:

   ```text
   AGENT_PROVIDER=groq
   GROQ_API_KEY=your_groq_key
   GEMINI_API_KEY=your_optional_gemini_key
   ```

   `.env` is ignored by Git, keys stay on the server, and `/api/status` never returns them.
4. Start the app:

   ```powershell
   node server.mjs
   ```

5. Open [http://127.0.0.1:4173](http://127.0.0.1:4173). Keep PowerShell open; press **Ctrl+C** there to stop.

The app also runs with no hosted key and labels itself **Local fallback**. To choose another port, set `$env:PORT='4180'` before starting.

## Telecom modes

The live Exotel voice agent can be linked under **Outreach → Connect existing Exotel voice agent**. Enter the existing account SID, API key/token, account region, ExoPhone and voice-agent flow ID, plus your own verified demo number. This saves credentials only in ignored `.runtime/exotel-config.json` and the number in the private runtime store; none are returned to the browser or included in source submissions. Saving does not place a call. The adapter follows Exotel's [connect-to-flow API](https://developer.exotel.com/docs/voice) and calls the recipient directly into the configured flow, avoiding a second human phone leg.

**Place real call** applies the selected lead's score (at least 50), consent, DND, opt-out, duplicate, contact-frequency and real IST hours checks. The example campaign clock cannot override real calling hours. **Test call to my demo phone** is a separately labelled personal demonstration: it only calls the saved owner's phone after confirmation, leaves campaign lead contact state unchanged, and limits attempts to one per minute. It cannot accept a different destination in the request. Both call paths use idempotency keys and do not automatically retry uncertain requests. Exotel SMS and authenticated progress callbacks are not configured; `provider_accepted` means only that Exotel accepted the API request, not that someone answered. The existing dashboard flow has been heard working on the owner's handset; a fresh end-to-end call from this web button still needs user verification.

Telecom defaults to `TELECOM_PROVIDER=dry-run`. A dry-run recomputes consent, DND, data-quality, duplicate, same-day, opt-out, score and calling-hour gates, then stores `dry_run_accepted`; it never contacts a carrier and does not mark the lead as contacted.

The alternative real adapter is Twilio. Before using it, read the [provider review and verification plan](reports/telecom-provider-review.md). The historical review describes trial restrictions; account permissions and India reply routing must be checked before use.

For a real test, add the following only to the ignored `.env` file:

```text
TELECOM_PROVIDER=twilio
TWILIO_ACCOUNT_SID=
TWILIO_AUTH_TOKEN=
TWILIO_FROM_NUMBER=provider_number
TWILIO_MESSAGING_SERVICE_SID=
TWILIO_CONTENT_SID=
PUBLIC_BASE_URL=https://your-exact-public-origin.example
```

`PUBLIC_BASE_URL` must exactly match the public HTTPS origin Twilio calls because the server validates every callback against `X-Twilio-Signature`. If the trial Console supplies an approved `HX...` content-template SID, set `TWILIO_CONTENT_SID`; the adapter then omits the custom SMS body and asks Twilio to use that template. Leave it blank on an account allowed to send the agent's grounded text. The browser never receives credentials or the stored demo number. The number entered in **Outreach → Phone demo** is written only to ignored `.runtime/telecom.json`; API responses expose only whether one is configured.

## Agent architecture

The production request path is:

```text
outreach gates + deterministic catalog/safety rules
                    ↓ unresolved language only
Groq openai/gpt-oss-20b (2.5 s)
                    ↓ failure
Gemini 3.1 Flash-Lite (5 s)
                    ↓ failure
bundled Potion semantic model
                    ↓
validated IDs → local catalog lookup + arithmetic → grounded reply
```

Known facts and safety controls do not wait for a model. The hosted planners return only a strict structured action; server code validates catalog IDs and fan-supplied numbers. Dates, prices, totals and policy wording always come from local data. Three consecutive failures open a 30-second circuit breaker for that provider, and the same provider is never retried inside a turn. See the [four-architecture decision](reports/architecture.md).

The Groq system prompt and response schema are stable, with state and the current fan message appended last. This lets Groq reuse an exact prefix when its automatic cache is available. The app records provider queue, prompt, generation, cached-token and client timing without exposing a key. [Groq structured output](https://console.groq.com/docs/structured-outputs) · [Groq prompt caching](https://console.groq.com/docs/prompt-caching)

## Measured provider comparison

The saved live run used 47 synthetic regression turns. Each forced hosted route still resolved 21 exact safety/FAQ/catalog turns locally, leaving 26 planner-eligible calls.

| Configuration | Planner returned / eligible | Pass when returned | Successful engine completion median / p90 / worst |
| --- | ---: | ---: | ---: |
| Groq cacheable | 13/26 | 11/13 | 572 / 691 / 725 ms |
| Groq minimal | 8/26 | 8/8 | 445 / 616 / 616 ms |
| Gemini | 17/26 | 17/17 | 1,794 / 4,553 / 7,267 ms |
| Local semantic | 26/26 | 26/26 | 0.7 / 2.5 / 33 ms |
| Production cascade | 5/5 after 42 local turns | **47/47 end to end** | 345 / 620 / 620 ms for Groq turns |

This run supports Groq as the faster primary and Gemini as an independent fallback, but it does not prove that one hosted model is universally more accurate. The old recorder discarded the exact cause of unavailable provider calls; that instrumentation is fixed for future runs. Cacheable versus minimal was not a matched causal cache test. Read the caveats, layer timings and raw evidence in the [provider comparison](reports/provider-comparison.md).

## Try the full flow

1. Open **Fan outreach**. The fixed **Campaign example** clock is 1 April 2027, 11:00 IST; **Current IST** tests the real time gate.
2. Inspect **L053** to see missing purchase recency block outreach. Select **L052, Vihaan Patel**, for a score of 55.5 and voice-only consent, or **L057, Meera Menon**, for a score of 76 and an SMS draft. **Preview outreach in chat** starts a rehearsal and records that day's simulated contact; it sends no real SMS or call. **Reset rehearsal contacts** clears only campaign-example contact markers, preserves opt-outs and real-call records, and saves a local backup. A STOP remains effective after a rehearsal reset.
3. In **Phone demo**, save a synthetic E.164 test value and run the default SMS or call dry-run. The status must say `dry run accepted`, not delivered or connected. Do not enter a real number when recording screenshots.
4. Ask: “Two tickets for MI in the North Stand, please.” The local catalog returns ₹1,200 each and ₹2,400 total. Then ask “And East Stand?” to reuse the headcount and quote ₹3,600.
5. Ask: “Can you guarantee a wheelchair space beside those seats?” Accessibility and adjacent-seat guarantees are unpublished, so the agent offers human help. Say “Connect me to a human” to record the handoff request.
6. Open **Demo & connection settings**, enable **Slow next reply**, and ask an unfamiliar question. The separate fault-injection path has a 1,600 ms outer deadline and a 1,350 ms planner allowance, then returns a safe fallback. Normal turns retain the full provider budgets.
7. Send **STOP** from an outreach conversation, then reopen the lead. The opt-out persists in `.runtime/preferences.json` and blocks further promotional rehearsal. A real inbound STOP is a separate evidence level and is complete only after a handset reply reaches the signed webhook.

**Start speaking** defaults to **Live captions**, showing interim words as you speak through the browser speech service. Pause or click **Finish speaking**, check the words, then press **Send**. **Speak replies** enables browser speech synthesis. If browser recognition is unavailable, choose **Record & transcribe** (requires `GROQ_API_KEY`): the recording finishes after about 0.9 seconds of silence following detected speech, or after 15 seconds maximum. This mode shows the input level and sends audio to Groq speech-to-text without saving it to disk. The UI reports transcription time separately from chat response time. A flat input level may indicate that the laptop microphone is muted (for example, using F4). Real speech recognition latency still depends on the browser service and network; live captions avoid the separate post-recording upload step. In Twilio mode the server can place a controlled outbound call, speak with `<Say>`, collect English speech or DTMF with `<Gather>`, and return grounded catalog responses. A timeout returns a spoken handoff fallback instead of silence.

Voice input options are under **Voice settings** below the composer. The **Performance** tab contains the per-turn timing table. On **Fan outreach**, the personal demo call is separate from lead campaign actions; credentials and lead phone controls are collapsed by default.

## Assignment deliverables

| Item | Evidence |
| --- | --- |
| Working agent | [server](server.mjs), [conversation engine](src/conversation.js), [Groq adapter](src/groq.js), [provider cascade](src/agent.js), [UI](public/index.html), [synthetic catalog](data/catalog.json) |
| 60 synthetic leads and 20 selected decisions | [leads](data/leads.csv), [decision CSV](reports/outreach.csv), [scoring and gates](reports/outreach.md) |
| 47-turn regression evaluation | [evaluation report](reports/evaluation.md), [development cases](evaluation/fan-cases.json), [regression cases](evaluation/holdout.json) |
| Latency and optimization evidence | [local HTTP benchmark](reports/latency.md), [provider comparison](reports/provider-comparison.md), [raw provider results](reports/provider-comparison-results.json) |
| Demo video | [Current Loom demonstration](https://www.loom.com/share/3c6af046dd7d43e4b586fb49e6a28f17), [recording notes and archived walkthrough](demo/README.md) |
| Telecom extension | [provider abstraction](src/telecom.js), [provider review and honest evidence levels](reports/telecom-provider-review.md) |

## Reproduce the checks

Run from the project folder:

```powershell
node --test
node src/outreach.js
node scripts/evaluate.mjs
node scripts/benchmark.mjs
node scripts/compare-providers.mjs
```

The first four commands need no quota. Provider comparison uses configured keys and free-tier quota; it intentionally sends only synthetic caselet data. To regenerate only its Markdown from saved raw results, run `node scripts/compare-providers.mjs --report-only`.

`node --test` includes dry-run dispatch, channel-specific gates, idempotency, the official Twilio signature test vector, forged-webhook rejection, signed inbound STOP, TwiML call startup and a grounded speech-gather turn. These are local tests, not evidence of carrier delivery or an audible call.

The submission check passed **56/56 tests**. Saved performance runs have their own dates and conditions; running tests again does not replace those benchmark results. The latency report's 76-turn benchmark measures first usable text at the local HTTP client, excluding browser rendering, microphone recognition, speech synthesis and carrier delays. The Loom phone demonstration is separate evidence, not a 40-call speech-latency study.

## Backend and deployment boundaries

API keys remain server-side. JSON bodies are capped at 16 KB, fan messages at 1,800 characters and each session at 30 turns per minute. Sessions expire after 30 minutes and the in-memory store is bounded. The server enforces same-origin writes, per-session turn locking, atomic preference writes, persistent opt-outs and explicit handoff boundaries. `/healthz` reports process health; `/api/status` reports non-secret provider readiness.

This is production-oriented architecture, not live ticketing. A public multi-instance deployment still needs TLS and edge abuse protection, shared sessions/rate limits such as Redis, observability, authorized live inventory and checkout, a staffed handoff destination, privacy review and appropriately registered commercial messaging infrastructure. India production messaging also requires provider, KYC, DLT, sender/template and campaign review appropriate to the route. A listed seat area is not a live availability or adjacent-seat guarantee.

## Design, photography and provenance

The interface uses archival cricket photographs with in-app credit links. The Dhoni portrait is by B A Raju / Times of India ([CC BY 3.0](https://creativecommons.org/licenses/by/3.0/)); the wicketkeeping image is by Pulkitsinha ([CC BY-SA 2.0](https://creativecommons.org/licenses/by-sa/2.0/)); the Chepauk match photograph is by Chandrachoodan Gopalakrishnan ([CC BY 3.0](https://creativecommons.org/licenses/by/3.0/)). Local Barlow Condensed and DM Sans license files are bundled in `public/assets`.

OpenAI Codex and parallel coding agents helped design and implement the prototype, synthetic data, evaluation and demo. The UI redesign used Anthropic's [frontend-design skill](https://github.com/anthropics/skills/tree/main/skills/frontend-design) for art direction and interface review; installing this skill is not required to run the app. The bundled MinishLab `potion-base-2M` assets are pinned to revision `389b9f64be5aa4ae7a6bc6fe95ef20ce485ae5da`; its model card and MIT license are in [models/potion](models/potion/README.md).
