# Production-agent architecture decision

## Constraints

The assignment needs catalog-grounded ticket answers, multi-turn selection, unfamiliar-language handling, opt-out and outreach safety, a slow-provider fallback, reproducible evaluation and latency evidence. All fan and inventory data in this prototype is synthetic. Prices, arithmetic and policy text must stay deterministic even when a hosted planner is wrong or unavailable.

## Four architectures considered

| Architecture | Strengths | Risks | Decision |
| --- | --- | --- | --- |
| One hosted model for every turn | Small integration surface and broad language coverage | Network latency and quota on every turn; one outage blocks known answers; probabilistic safety controls | Reject |
| Race Groq and Gemini in parallel | Can reduce tail latency when both are healthy | Sends every message twice, spends two quotas and produces nondeterministic winners | Reject |
| Local generative model, cloud escalation | Private and offline-capable | Multi-GB download/runtime and uncertain reviewer hardware | Future option |
| Deterministic-first, then Groq → Gemini → local semantic model | Immediate known answers, grounded rendering, two hosted choices and an offline fallback | More routing and timeout logic | **Selected** |

## Selected request path

1. The outreach gate checks consent, DND, duplicates, data quality, contact hours and same-day contact before a message can be rehearsed.
2. In conversation, STOP/opt-out, decline, explicit human requests, known unpublished topics, prompt injection, exact FAQs and recognized catalog requests are handled locally.
3. Only unresolved language calls Groq `openai/gpt-oss-20b` with strict JSON Schema output.
4. A Groq timeout, rate limit or provider error tries Gemini `gemini-3.1-flash-lite` within a separate budget.
5. If both hosted providers fail, the bundled Potion semantic model proposes an intent locally.
6. Server code validates IDs and fan-supplied numbers, reads facts from the catalog, calculates totals and renders the reply. Models never supply prices or policy prose.

Each hosted provider has its own three-failure, 30-second circuit breaker. A turn never retries the same provider. Normal requests have an 8,500 ms outer deadline and an 8,250 ms planner allowance: Groq gets 2,500 ms and Gemini fallback gets 5,000 ms. The demo fault uses a separate 1,600 ms outer deadline and 1,350 ms planner allowance.

## Context and prefix cache

The Groq request begins with a byte-stable system message containing rules and a compact catalog. The response schema is also stable. Dynamic conversation state and the current fan message appear only in the final user message. The model sees entity IDs, aliases and FAQ-routing terms—not prices or policy answers.

Groq caching is automatic and requires an exact shared prefix. The experiment compared:

- `cacheable`: retains FAQ routing terms in the stable catalog prefix.
- `minimal`: retains FAQ questions but removes their keyword lists.

This is prefix-friendly, but the saved run is not a controlled causal cache experiment: the two contexts differ, trials ran sequentially, and only four cacheable responses versus one minimal response reported cached tokens. The current build therefore keeps the richer cacheable context for routing coverage without claiming that caching alone reduced tail latency.

## Measured evidence

The 20 November 2026 run used 47 synthetic regression turns. Forced-provider routes bypassed 21 exact local controls and attempted 26 planner calls.

| Route | Planner returned / eligible | Rubric pass when returned | Successful completion median / p90 / worst |
| --- | ---: | ---: | ---: |
| Groq cacheable | 13/26 | 11/13 | 572 / 691 / 725 ms |
| Groq minimal | 8/26 | 8/8 | 445 / 616 / 616 ms |
| Gemini | 17/26 | 17/17 | 1,794 / 4,553 / 7,267 ms |
| Local semantic | 26/26 | 26/26 | 0.7 / 2.5 / 33 ms |
| Production cascade | 5/5 after 42 local turns | 5/5; 47/47 end to end | 345 / 620 / 620 ms for Groq turns |

The old recorder collapsed provider exceptions, so unavailable calls in this run cannot be attributed honestly to quota, timeout or model error. Runtime instrumentation now preserves a safe failure category for future measurements. The 47 turns are a regression suite, not an untouched holdout; a publishable provider-quality claim needs a newly frozen set and matched, alternating, quota-paced trials with identical pre-turn state.

The result supports the production architecture, not a blanket claim that one hosted model is always more accurate. Groq was materially faster on successful calls, Gemini provides a useful independent fallback, and deterministic-first routing produced the only 47/47 hosted production result while sending just five turns to Groq.

Full raw results and layer timings: [provider comparison](provider-comparison.md) and [JSON evidence](provider-comparison-results.json).

## Telecom boundary

Telecom is a separate adapter boundary after outreach eligibility. The default dry-run adapter records a rehearsal without contacting a carrier. The Twilio adapter is the first real implementation; both expose the same SMS, call, status and webhook-verification contract.

The current build also implements Exotel outbound voice into an existing managed-agent flow, with no second human phone leg. Private local setup stores the existing credentials and owner's verified demo number outside the submission. Its selected-lead call path rechecks real campaign gates; a separately labelled personal self-test can only call that fixed owner number, requires confirmation and is throttled and idempotent. Exotel SMS and authenticated progress callbacks are not implemented. The Exotel conversation and speech settings belong to that separately managed service, not the Groq/Gemini web cascade.

Before every dispatch, the server recomputes the chosen channel's consent, DND, duplicate, data-quality, score, same-day contact, persistent opt-out and India-time gates. A client idempotency key maps to one dispatch. Real provider acceptance marks the lead contacted for the day; dry-run acceptance does not. The demo phone number is stored only in the ignored private runtime file and never returned by the API.

Twilio status and inbound webhooks are accepted only after `X-Twilio-Signature` validation against the configured exact public URL. Callback events are deduplicated. A signed inbound STOP persists through the existing suppression store. Voice uses `<Say>` and `<Gather>`; each speech turn goes through the same deterministic-first conversation engine with a three-second voice budget and a spoken fallback on timeout.

See the [provider review](telecom-provider-review.md) for current trial constraints, India routing uncertainty and the evidence levels that separate dry-run, API acceptance, SMS delivery, answered/completed calls, audible speech and a handset STOP reply.

References: [Groq structured outputs](https://console.groq.com/docs/structured-outputs), [prompt caching](https://console.groq.com/docs/prompt-caching), [latency measurement](https://console.groq.com/docs/production-readiness/optimizing-latency), and [GPT-OSS 20B](https://console.groq.com/docs/model/openai/gpt-oss-20b).
