import { loadEnvFile } from 'node:process';
import { mkdir, writeFile } from 'node:fs/promises';
import { replyTurn } from '../src/conversation.js';
import { createProductionAgent } from '../src/agent.js';
import { loadJson, root, runSuite } from '../evaluation/scoring.mjs';

try { loadEnvFile(new URL('../.env', import.meta.url)); } catch (error) { if (error.code !== 'ENOENT') throw error; }

const catalog = await loadJson('data/catalog.json');
const development = await loadJson('evaluation/fan-cases.json');
const holdout = await loadJson('evaluation/holdout.json');
const agent = await createProductionAgent(catalog);
if (!agent.status.configured) throw new Error('Set GEMINI_API_KEY in .env before running the cloud evaluation.');

const run = suite => runSuite(suite, input => replyTurn({
  ...input,
  catalog,
  model: agent.model,
  mode: agent.mode,
  timeoutMs: 8500,
}));
const outcomes = {
  measuredAtUtc: new Date().toISOString(),
  provider: agent.status.provider,
  model: agent.status.model,
  development: await run(development),
  holdout: await run(holdout),
};
const passed = rows => rows.filter(row => row.pass).length;
const failures = [...outcomes.development, ...outcomes.holdout].filter(row => !row.pass);
const providers = [...outcomes.development, ...outcomes.holdout].reduce((counts, row) => {
  const key = row.provider || row.source || 'unknown';
  counts[key] = (counts[key] || 0) + 1;
  return counts;
}, {});
const report = [
  '# Gemini cloud evaluation',
  '',
  `Measured ${outcomes.measuredAtUtc} with \`${outcomes.model}\`. The production planner received only synthetic caselet messages, compact conversation state and the assumed catalog. Final prices and policy text remained locally rendered from the catalog.`,
  '',
  '| Suite | Passing turns |',
  '| --- | ---: |',
  `| Development | ${passed(outcomes.development)} / ${outcomes.development.length} |`,
  `| Held out | ${passed(outcomes.holdout)} / ${outcomes.holdout.length} |`,
  '',
  `Routing counts: ${Object.entries(providers).map(([name, count]) => `\`${name}\` ${count}`).join(', ')}. Exact consent, safety and published-FAQ matches may be resolved locally before the probabilistic planner.`,
  '',
  '## Failures and fixes',
  '',
  ...(failures.length ? failures.map(row => `- **${row.id}:** ${row.failures.join('; ')} Reply: “${row.text.replaceAll('\n', ' ')}”`) : ['All cloud-evaluated development and held-out turns passed their written assertions.']),
  '',
  'The test set is finite and synthetic. A passing result does not establish real-world telephony, inventory or checkout performance.',
  '',
];
await mkdir(new URL('../reports/', import.meta.url), {recursive:true});
await writeFile(new URL('../reports/cloud-evaluation-results.json', import.meta.url), JSON.stringify(outcomes, null, 2) + '\n');
await writeFile(new URL('../reports/cloud-evaluation.md', import.meta.url), report.join('\n'));
console.log(`Gemini ${outcomes.model}: development ${passed(outcomes.development)}/${outcomes.development.length}; holdout ${passed(outcomes.holdout)}/${outcomes.holdout.length}.`);

