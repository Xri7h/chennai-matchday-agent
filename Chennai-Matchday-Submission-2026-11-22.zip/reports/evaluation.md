# Conversation evaluation

This run uses the assumed 2027 Chennai Super Kings caselet catalog at M. A. Chidambaram Stadium, Chepauk, Chennai, with Mumbai Indians as the first opponent. The fixtures, prices and policies are assignment assumptions, not official or live inventory. The development suite contains 38 English fan turns across 31 independent conversations. Each conversation starts with empty state. Within it, the next turn receives exactly the state the engine returned.

| Engine path | Turns passing all checks |
| --- | ---: |
| deterministic | 37 / 38 |
| semantic | 38 / 38 |

## Scoring

Each labeled turn has a written expectation. A binary pass requires every specified fact or price pattern, every expected state value, a human handoff when required, and the absence of the listed unsafe claims. State assertions check corrections, group count, budget basis and remembered selections. A safe handoff counts as a miss when the question has a published answer. The input includes budget boundaries, misremembered policies, requests for payment, prompt injection, opt-out, and unfamiliar paraphrases.

The full inputs and rubrics are in [fan-cases.json](../evaluation/fan-cases.json), fixture fingerprint `2687826a83c3b35b`. [Per-turn transcripts](evaluation-results.json) contain the actual answer and each failed assertion. These finite checks cover the listed behaviors. Passing does not establish performance on all fan messages, real phone audio, or real-world bookings.

## Cases to review

Every scored turn in the primary configuration passed its assertions.

## Effect of adding semantic matching

Adding the bundled intent model changed the verdict on 1 turn. The conversation engine still renders prices and policies from the catalog.

| Turn | Rules only | With model |
| --- | --- | --- |
| paraphrase-return.1 | miss | pass |

## Historical holdout regression scenarios

The [historical holdout](../evaluation/holdout.json) contains 9 additional turns across 8 conversations. These scenarios were set aside during initial development, but they have since been inspected and some phrases now appear in catalog routing keywords. They are therefore regression evidence, not an untouched final holdout. The franchise update preserves their scoring rules and updates fixture and venue references. The shipped path passed 9/9. The latency benchmark repeats the 38 development turns.

| Regression turn | Result |
| --- | --- |
| holdout-stadium.1 | Pass |
| holdout-lift.1 | Pass |
| holdout-cap.1 | Pass |
| holdout-arithmetic.1 | Pass |
| holdout-made-up-offer.1 | Pass |
| holdout-delivery.1 | Pass |
| holdout-budget-change.1 | Pass |
| holdout-budget-change.2 | Pass |
| holdout-optout.1 | Pass |

## Archived development baseline and current retest

Before the franchise rename, the original development suite (fingerprint `5f2644daf3cf6cc0`) initially passed 26/38 without the model and 27/38 with it. At the end of that run the semantic path passed 36/38 and 8/9 on the holdout. The table above uses fresh Chennai Super Kings responses. Scenario IDs link the following historical failures to their current retests.

- **group-budget.2.** The first run kept three people after the fan changed the group to four and returned a human handoff. The slot parser now recognizes conditional group-size changes and checks the retained total budget. The current retest is a **pass**.
- **price-correction.1.** The first run quoted one North Stand seat correctly but lost the headcount in “two North Stand tickets”. The quantity parser now accepts a catalog area between a number and the ticket noun. The current retest is a **pass**.
- **club.1.** The first run returned a general handoff for a known seat and fixture whose combination was unavailable. The revised routing resolves price and availability requests against the selected fixture. The current retest is a **pass**.
- **budget-boundary.1.** The first response asked for the headcount even though the fan had opened with “Two for RCB”. The parser now recognizes compact group-and-opponent requests and includes a seat at the exact budget cap. The current retest is a **pass**.
