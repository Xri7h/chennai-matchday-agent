# Text latency and routing trade-offs

Measured locally on win32 x64 with Node 24.14.1 using the assumed 2027 Chennai Super Kings caselet catalog at M. A. Chidambaram Stadium, Chepauk, Chennai. The primary run used the in-process intent model, the actual chat HTTP route, a preloaded catalog and one persistent loopback connection. Each configuration received the same 76 fan turns (2 passes through the evaluation set). Each conversation got a new session on each pass. Application startup and one warmup turn were excluded.

## Turn measurements

Values are milliseconds, shown as **median / p90 / worst**. Model time includes the intent call when invoked and is zero on locally resolved turns. Logic is the app-reported engine processing time outside the model. The client measures elapsed time from request dispatch until it parses the complete chat JSON and can read the first word. This includes loopback HTTP and request handling. UI paint, speech synthesis, speech recognition and carrier timing lie outside this clock.

| Configuration | Turns | Model call | Own logic | First usable text | Passed rubric |
| --- | ---: | ---: | ---: | ---: | ---: |
| shipped | 76 | 0.000 / 0.157 / 0.289 | 0.530 / 0.832 / 3.184 | 1.289 / 2.118 / 5.925 | 76/76 |
| model_first | 76 | 0.129 / 0.307 / 2.061 | 0.529 / 1.012 / 4.829 | 1.254 / 2.268 / 8.360 | 76/76 |
| uncached_anchors | 76 | 0.663 / 0.828 / 33.306 | 0.520 / 0.830 / 8.567 | 1.801 / 2.783 / 43.599 | 76/76 |
| new_connection | 76 | 0.000 / 0.141 / 0.336 | 0.558 / 0.966 / 1.926 | 2.278 / 3.438 / 4.947 | 76/76 |
| rules_only | 76 | 0.000 / 0.000 / 0.000 | 0.555 / 0.857 / 2.195 | 1.344 / 2.107 / 3.855 | 74/76 |

The guide for a text pipeline is about 2,500 ms at median and 4,000 ms at p90. This local prototype measured 1.289 ms and 2.118 ms. Payloads and the model stay on this machine. Deployed networks and real calls require their own measurements.

## Controlled changes

Each comparison changes the named behavior while retaining the same workload. Positive savings indicate lower latency. The fourth row is a separate in-process comparison. Its readings cannot be added to the HTTP results.

| Change | Timed scope at p90 | Before (ms) | After (ms) | Saved (ms) |
| --- | --- | ---: | ---: | ---: |
| Precompute catalog anchor embeddings | model-first model call | 0.828 | 0.307 | 0.522 |
| Resolve recognized requests before invoking the model | HTTP to text | 2.268 | 2.118 | 0.150 |
| Reuse the local HTTP connection | HTTP to text | 3.438 | 2.118 | 1.320 |
| Reuse the parsed catalog across requests | rules-only engine plus catalog access | 1.554 | 0.840 | 0.714 |

## Speed and accuracy

Bypassing the model gave 74/76 passing turns at 2.107 ms p90. Enabling selective semantic matching gave 76/76 passing turns at 2.118 ms p90. Sending every eligible turn through the model gave 76/76 passing turns at 2.268 ms p90. The denominator counts two runs of each fan message. [Individual verdicts and timing rows](latency-measurements.json) identify the cases behind those scores.

On the indirect question about leaving at the innings break and coming back, rules-only answered correctly on 0/2 attempts using zero model time. Selective semantic routing spent a median of 0.165 ms on the model call and answered correctly on 2/2 attempts. This isolates the extra inference cost of recognizing that phrasing.

## Timeout demonstration

The delivery route was called once with its slow-model scenario. It injected an eight-second wait into the model adapter. The server deadline was 1.6 seconds, with no automatic retries. Source: `fallback`. Time to usable fallback: 1366.059 ms. The UI can read the resulting sentence aloud with browser speech enabled. This separate fault-injection turn is excluded from the ordinary latency distribution.

> The ticket assistant is taking longer than expected or is temporarily unavailable. Please try again, or ask for a human ticket representative.

Run `node scripts/benchmark.mjs` for a fresh measurement. The script interleaves configurations at each turn, reverses scenario order for the second pass, averages the two middle values for the median and uses nearest-rank p90. Very small local differences, especially tail values, can vary with CPU scheduling, antivirus and other host activity.
