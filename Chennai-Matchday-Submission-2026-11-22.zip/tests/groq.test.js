import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createGroqAgent } from '../src/groq.js';

const catalog = JSON.parse(readFileSync(new URL('../data/catalog.json', import.meta.url), 'utf8'));

test('Groq adapter uses strict structured output, compact context and never places its key in the body', async () => {
  const secret = 'groq-secret-do-not-leak';
  const requests = [];
  const fetchImpl = async (url, options) => {
    requests.push({url, options});
    return {ok:true, status:200, json:async () => ({usage:{prompt_tokens:1200,completion_tokens:45,queue_time:.005,prompt_time:.01,completion_time:.02,total_time:.03,prompt_tokens_details:{cached_tokens:1024}},choices:[{message:{content:JSON.stringify({
      intent:'quote', matchId:'M1', seatIds:['A1'], faqId:null,
      groupSize:2, budgetInr:null, budgetBasis:null,
    })}}]})};
  };
  const model = createGroqAgent({apiKey:secret, fetchImpl});
  const result = await model({message:'Two north tickets for Mumbai', state:{}, catalog, signal:AbortSignal.timeout(1000)});
  await model({message:'What about east?', state:{matchId:'M1',groupSize:2}, catalog, signal:AbortSignal.timeout(1000)});
  const request = requests[0];
  const body = JSON.parse(request.options.body);
  const next = JSON.parse(requests[1].options.body);
  assert.equal(result._meta.provider, 'groq');
  assert.equal(body.model, 'openai/gpt-oss-20b');
  assert.equal(body.response_format.json_schema.strict, true);
  assert.equal(body.messages[0].content.includes('price_inr_by_match'), false);
  assert.equal(request.options.body.includes(secret), false);
  assert.equal(request.options.headers.Authorization, `Bearer ${secret}`);
  assert.equal(body.messages[0].content, next.messages[0].content);
  assert.deepEqual(body.response_format, next.response_format);
  assert.notEqual(body.messages[1].content, next.messages[1].content);
  assert.equal(result._meta.cachedTokens, 1024);
  assert.equal(result._meta.promptTokens, 1200);
  assert.ok(result._meta.networkOverheadMs >= 0);
});
