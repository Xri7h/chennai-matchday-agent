# Provider, context and prefix-cache comparison

Measured 2026-11-20T18:23:05.799Z using 47 synthetic regression turns. Values are median / p90 / worst milliseconds. The three forced-provider configurations still bypass 21 exact safety, FAQ and catalog controls, leaving 26 planner-eligible turns. “Returned” means the configured planner produced a usable structured result; unavailable calls are not scored as model mistakes.

| Configuration | Local rule turns | Planner returned / eligible | Rubric pass when returned | End-to-end pass | Successful engine completion |
| --- | ---: | ---: | ---: | ---: | ---: |
| groq_cacheable | 21 | 13/26 | 11/13 | 34/47 | 572.2 / 690.8 / 724.8 |
| groq_minimal | 21 | 8/26 | 8/8 | 30/47 | 444.5 / 615.5 / 615.5 |
| gemini | 21 | 17/26 | 17/17 | 38/47 | 1793.5 / 4552.7 / 7267.1 |
| local_semantic | 21 | 26/26 | 26/26 | 47/47 | 0.7 / 2.5 / 33.3 |
| production_cascade | 42 | 5/5 | 5/5 | 47/47 | 345.4 / 619.6 / 619.6 |

“Successful engine completion” is in-process request-to-complete-reply time, not browser paint, streaming first-token time, speech start or carrier latency.

## Groq layer breakdown for successful returns

| Context | Queue | Prompt processing | Generation | Client/transport residual | Cache-token ratio | Requests with cache tokens |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| groq_cacheable | 316.5 / 367.9 / 379.6 | 58.1 / 99.4 / 111.7 | 112.2 / 170.9 / 257.5 | 50.5 / 132.7 / 266.4 | 4096/15149 (27.0%) | 4/13 |
| groq_minimal | 224.4 / 368.6 / 368.6 | 43.0 / 65.5 / 65.5 | 101.6 / 127.3 / 127.3 | 46.7 / 109.2 / 109.2 | 256/6762 (3.8%) | 1/8 |

Groq `usage.total_time` excludes queue time, so the residual subtracts both queue and provider processing from client elapsed time. It still includes transport, serialization, parsing and client scheduling.

## Interpretation and selected production path

- Gemini returned 17/26 planner attempts and passed 17/17 returned cases, but its successful completion latency was materially higher than Groq in this run.
- Groq cacheable returned 13/26 and passed 11/13 returned cases; minimal returned 8/26 and passed 8/8. Only four cases returned in both Groq variants, and both passed all four, so this run does not establish a causal accuracy advantage for either context.
- The unavailable causes were discarded by the old recorder. Most ended quickly, but they cannot honestly be labelled rate limits, timeouts or model errors. The corrected runtime now preserves the failure category for future runs.
- Cache evidence is directional, not conclusive: four cacheable requests and one minimal request reported cached tokens. The contexts also differ in FAQ content, and the trials were sequential rather than matched and alternating.
- Production deterministic-first routing passed 47/47: 42 turns were resolved locally and five went to Groq, all five passing. This run did not exercise Gemini or Potion failover.

The production choice remains deterministic-first → Groq `openai/gpt-oss-20b` → Gemini → local Potion. It keeps known ticket facts and controls immediate, uses the faster hosted planner only for unresolved language, and retains two safe fallbacks. The 2,500 ms Groq timeout exceeds the observed 725 ms worst successful Groq completion; the 5,000 ms Gemini fallback budget exceeds the observed 4,553 ms successful p90 while keeping the two-provider budget below the 8,250 ms planner allowance.

The 47 messages are a regression suite, not an untouched holdout: several phrases have since become catalog routing keywords. A publishable provider-quality claim needs a newly frozen test set plus matched, alternating, quota-paced trials with identical pre-turn state.

All messages and catalog data in this comparison are synthetic caselet data. No real fan data was transmitted.
