import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';

const app = await readFile(new URL('../public/app.js',import.meta.url),'utf8');
const voice = app.slice(app.indexOf('function microphoneUi('),app.indexOf("$('chat-form').onsubmit"));
function harness() {
  const nodes=new Map();
  const node=id=>{
    if(!nodes.has(id))nodes.set(id,{value:'',textContent:'',disabled:false,hidden:false,setAttribute(){},focus(){},querySelector:selector=>node(id+selector)});
    return nodes.get(id);
  };
  let recognizer;
  class Recognition {
    constructor(){recognizer=this;}
    start(){this.onstart();}
    stop(){this.onend();}
    abort(){}
  }
  const context=vm.createContext({$:node,window:{SpeechRecognition:Recognition,speechSynthesis:{cancel(){}}},navigator:{mediaDevices:{getUserMedia(){}}},MediaRecorder:{},performance,
    clearTimeout,setTimeout,cancelAnimationFrame(){},AbortController,Blob,Uint8Array,btoa});
  vm.runInContext(`let recording=false, recorder, recognition, recordingTimer,recordingFrame,recordingContext,recordingStream;
    let recordingChunks=[],recordingPeak=0,speechEpoch=0,speechRequest,speechPending=false,microphoneOpening=false;
    let micReady=false,chatting=false,nativeBase='',nativeFinal='',nativeError=false,nativeActive=false;
    ${voice}
    initVoice({configured:true});`,context);
  return {node,recognizer,run:code=>vm.runInContext(code,context)};
}
function result(text,final=false){const row=[{transcript:text}];row.isFinal=final;return row;}

test('voice defaults to live interim captions and replaces partial words without duplication',()=>{
  const h=harness();
  assert.equal(h.node('speech-method').value,'live');
  assert.equal(h.recognizer.interimResults,true);
  h.node('message').value='For MI'; h.node('mic').onclick();
  h.recognizer.onresult({results:[result('two tick')]});
  assert.equal(h.node('message').value,'For MI two tick');
  h.recognizer.onresult({results:[result('two tickets',true)]});
  assert.equal(h.node('message').value,'For MI two tickets');
  h.node('mic').onclick();
  assert.equal(h.node('mic').textContent,'Start speaking');
  assert.match(h.node('speech-status').textContent,/Ready/);
});

test('cancelled speech callbacks cannot overwrite a sent message or new chat',()=>{
  const h=harness();h.node('mic').onclick();h.run('cancelMicrophone()');
  h.node('message').value='new draft';h.node('speech-status').textContent='Checking the catalog…';
  h.recognizer.onresult({results:[result('stale recording',true)]});h.recognizer.onend();
  assert.equal(h.node('message').value,'new draft');
  assert.equal(h.node('speech-status').textContent,'Checking the catalog…');
});

test('speech errors retain actionable muted-microphone and fallback guidance',()=>{
  const h=harness();h.node('mic').onclick();
  h.recognizer.onerror({error:'no-speech'});h.recognizer.onend();
  assert.match(h.node('speech-status').textContent,/F4/);
  h.node('mic').onclick();h.recognizer.onerror({error:'network'});h.recognizer.onend();
  assert.match(h.node('speech-status').textContent,/Record & transcribe/);
});
