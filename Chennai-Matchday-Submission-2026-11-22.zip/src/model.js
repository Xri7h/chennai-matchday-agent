import { readFile } from 'node:fs/promises';

// This encoder uses the English WordPiece vocabulary and static token embeddings
// from MinishLab's Potion model. Scores rank intents, never ticket facts.
async function loadEncoder() {
  const asset = name => new URL('../models/potion/' + name, import.meta.url);
  const [file, vocabulary] = await Promise.all([readFile(asset('model.safetensors')), readFile(asset('vocab.txt'), 'utf8')]);
  const offset = 8 + Number(file.readBigUInt64LE());
  const { embeddings } = JSON.parse(file.toString('utf8', 8, offset));
  const [rows, width] = embeddings.shape;
  const ids = new Map(vocabulary.trimEnd().split(/\r?\n/).map((token, i) => [token, i]));
  if (embeddings.dtype !== 'F32' || ids.size !== rows || file.length - offset !== rows * width * 4) {
    throw new Error('The bundled model and vocabulary do not match.');
  }
  const weights = new Float32Array(file.buffer, file.byteOffset + offset, rows * width);
  function tokenize(word) {
    if (ids.has(word)) return [ids.get(word)];
    const tokens = [];
    for (let start = 0; start < word.length;) {
      let end = word.length;
      let id;
      while (end > start) {
        id = ids.get((start ? '##' : '') + word.slice(start, end));
        if (id !== undefined) break;
        end--;
      }
      if (end === start) return [];
      tokens.push(id);
      start = end;
    }
    return tokens;
  }
  return text => {
    const vector = new Float32Array(width);
    const words = text.normalize('NFD').replace(/\p{M}/gu, '').toLowerCase().match(/[a-z0-9]+|[^\s\p{L}\p{N}]/gu) || [];
    for (const word of words) {
      if (word.length > 100) continue;
      for (const id of tokenize(word)) {
        const pos = id * width;
        for (let j = 0; j < width; j++) vector[j] += weights[pos + j];
      }
    }
    const norm = Math.hypot(...vector) || 1;
    for (let j = 0; j < width; j++) vector[j] /= norm;
    return vector;
  };
}

const examples = {
  fixtures: ['Who are we playing next?', 'Show me the home fixture list', 'When is the next home game?', 'Which dates can we come to the cricket?'],
  quote: ['How much would a ticket set me back?', 'What is the damage for a pair of seats?', 'Which tickets fit my spending limit?', 'Where can we sit without spending much?'],
  compare: ['How do these sections differ?', 'Weigh up the two seating choices', 'Compare what those seats would cost'],
  handoff: ['May I speak with a real person?', 'Please connect me with a representative'],
  unknown: ['How do I sell my ticket?', 'How is the weather?', 'Who will win the match?', 'Tell me a joke', 'What other benefits are included?', 'I want to make a payment', 'Is my booking confirmed?', 'Any special exceptions to the rules?', 'Do you serve food inside?', 'Can I bring a water bottle or a backpack?']
};
const faqExamples = {
  'ticket-format': ['Can I scan it off my screen at the turnstile?', 'Will the digital pass on my handset get me in?'],
  'ticket-delivery': ['Where will my admission pass land after I pay?', 'How do the admission passes reach the purchaser?'],
  'reentry': ['If I pop out at the interval will they let me back through?', 'Can I exit the ground and come back later?'],
  'outside-food': ['Is a homemade sandwich allowed through the turnstiles?', 'May we pack our own supper?'],
  'id-proof': ['Does the purchaser need to carry identification?', 'What documents does the person who booked need?'],
  'purchase-limit': ['Is there a cap on the number of passes in one order?'],
  'gates': ['How long before play can spectators get inside?'],
  'venue': ['Which ground hosts the team this season?'],
  'children': ['Does my five year old need a separate admission pass?']
};

let encoderPromise;
export async function createIntentModel(catalog, { cacheEmbeddings = true, threshold = 0.67 } = {}) {
  const encode = await (encoderPromise ??= loadEncoder());
  const labels = Object.entries(examples).map(([intent, texts]) => ({ intent, texts }));
  for (const faq of catalog.faq) {
    labels.push({ intent: 'faq', faqId: faq.id, texts: [faq.question, ...(faqExamples[faq.id] || [])] });
  }
  labels.find(l => l.intent === 'unknown').texts = [...examples.unknown, ...catalog.not_published];
  function buildIndex() {
    return labels.map(({texts, ...label}) => ({ ...label, vectors: texts.map(encode) }));
  }
  const index = cacheEmbeddings ? buildIndex() : null;
  return async ({ message, signal }) => {
    signal?.throwIfAborted();
    const query = encode(message);
    const ranked = (index || buildIndex()).map(({ vectors, ...label }) => {
      let best = -1;
      for (const vector of vectors) {
        let score = 0;
        for (let j = 0; j < query.length; j++) score += vector[j] * query[j];
        best = Math.max(best, score);
      }
      return { ...label, confidence: best };
    }).sort((a,b) => b.confidence - a.confidence);
    const [first, second] = ranked;
    if (first.confidence < threshold || first.confidence - second.confidence < 0.055) {
      return { intent: 'unknown', confidence: first.confidence };
    }
    return first;
  };
}
