import http from 'node:http';
import os from 'node:os';
import { loadEnvFile } from 'node:process';
import { mkdir, writeFile } from 'node:fs/promises';
import { createApp } from '../server.mjs';
import { loadJson, median, nearestRank, root, scoreTurn } from '../evaluation/scoring.mjs';

try { loadEnvFile(new URL('../.env', import.meta.url)); } catch (error) { if (error.code !== 'ENOENT') throw error; }
if (!process.env.GEMINI_API_KEY) throw new Error('Set GEMINI_API_KEY in .env before running the cloud benchmark.');

const development = await loadJson('evaluation/fan-cases.json');
const holdout = await loadJson('evaluation/holdout.json');
const catalog = await loadJson('data/catalog.json');
const model = process.env.GEMINI_MODEL || 'gemini-3.1-flash-lite';
const measuredAtUtc = new Date().toISOString();
const turns = [];
for (const [suite, scenarios] of [['development', development], ['holdout', holdout]]) {
  for (const scenario of scenarios) {
    for (const [index, expected] of scenario.turns.entries()) {
      turns.push({ suite, expected, id: `${scenario.id}.${index + 1}`, sessionId: `${suite}-${scenario.id}` });
    }
  }
}

function listen(server) {
  return new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', () => {
      server.off('error', reject);
      resolve(server.address().port);
    });
  });
}

function postTurn(port, agent, payload) {
  const body = JSON.stringify(payload);
  const started = performance.now();
  return new Promise((resolve, reject) => {
    const request = http.request({
      hostname: '127.0.0.1', port, path: '/api/chat', method: 'POST', agent,
      headers: {'Content-Type':'application/json', 'Content-Length':Buffer.byteLength(body), Origin:`http://127.0.0.1:${port}`},
    }, response => {
      response.setEncoding('utf8');
      let data = '';
      response.on('data', part => { data += part; });
      response.on('error', reject);
      response.on('end', () => {
        try {
          if (response.statusCode !== 200) throw new Error(`Chat HTTP ${response.statusCode}: ${data.slice(0, 400)}`);
          const result = JSON.parse(data);
          if (!result.text?.trim()) throw new Error('Chat endpoint returned no usable reply.');
          resolve({result, firstTextMs:performance.now() - started});
        } catch (error) { reject(error); }
      });
    });
    request.setTimeout(15000, () => request.destroy(new Error('Cloud benchmark request timed out.')));
    request.on('error', reject);
    request.end(body);
  });
}

const setups = [
  {name:'gemini_cloud', server:await createApp({storePath:null, timeoutMs:8500}), agent:new http.Agent({keepAlive:true, maxSockets:1})},
  {name:'local_fallback', server:await createApp({apiKey:'', storePath:null, timeoutMs:8500}), agent:new http.Agent({keepAlive:true, maxSockets:1})},
];
const samples = [];
try {
  for (const setup of setups) setup.port = await listen(setup.server);
  for (const turn of turns) {
    for (const setup of setups) {
      const {result, firstTextMs} = await postTurn(setup.port, setup.agent, {message:turn.expected.fan, sessionId:turn.sessionId});
      samples.push({
        configuration:setup.name, suite:turn.suite, turn:turn.id,
        provider:result.provider || result.source, modelMs:result.modelMs,
        logicMs:result.logicMs, firstTextMs, pass:scoreTurn(turn.expected, result).length === 0,
      });
    }
  }
} finally {
  for (const setup of setups) setup.agent.destroy();
  await Promise.all(setups.map(setup => new Promise(resolve => setup.server.close(resolve))));
}

const metric = values => ({median:median(values), p90:nearestRank(values, .9), worst:Math.max(...values)});
const summary = {};
for (const setup of setups) {
  const rows = samples.filter(row => row.configuration === setup.name);
  summary[setup.name] = {
    turns:rows.length,
    passed:rows.filter(row => row.pass).length,
    providers:rows.reduce((counts, row) => ({...counts, [row.provider]:(counts[row.provider] || 0) + 1}), {}),
    modelMs:metric(rows.map(row => row.modelMs)),
    logicMs:metric(rows.map(row => row.logicMs)),
    firstTextMs:metric(rows.map(row => row.firstTextMs)),
  };
}
if (!(summary.gemini_cloud.providers.gemini > 0)) throw new Error('The cloud route never returned a Gemini-planned turn.');

const f = value => value.toFixed(1);
const cell = value => `${f(value.median)} / ${f(value.p90)} / ${f(value.worst)}`;
const cloud = summary.gemini_cloud;
const local = summary.local_fallback;
const report = [
  '# Production-route cloud latency',
  '',
  `Measured ${measuredAtUtc} on ${os.platform()} ${os.arch()} with Node ${process.versions.node} and \`${model}\`. The workload contains all ${turns.length} synthetic development and held-out fan turns, preserves state within each conversation, and uses the real local HTTP chat endpoint.`,
  '',
  'Values are milliseconds shown as **median / p90 / worst**. First usable text is measured from HTTP request dispatch until the complete JSON reply is available to the browser client. Model and own-logic time are instrumented inside the agent.',
  '',
  '| Route | Turns | Model call | Own logic | First usable text | Passed rubric |',
  '| --- | ---: | ---: | ---: | ---: | ---: |',
  `| Gemini production route | ${cloud.turns} | ${cell(cloud.modelMs)} | ${cell(cloud.logicMs)} | ${cell(cloud.firstTextMs)} | ${cloud.passed}/${cloud.turns} |`,
  `| Local resilience route | ${local.turns} | ${cell(local.modelMs)} | ${cell(local.logicMs)} | ${cell(local.firstTextMs)} | ${local.passed}/${local.turns} |`,
  '',
  `Production routing counts: ${Object.entries(cloud.providers).map(([name, count]) => `\`${name}\` ${count}`).join(', ')}. Safety controls, exact published FAQs and other deterministic matches intentionally avoid unnecessary cloud inference.`,
  '',
  '## Measured trade-off',
  '',
  `The Gemini route changes p90 time to first usable text from ${f(local.firstTextMs.p90)} ms to ${f(cloud.firstTextMs.p90)} ms while changing scored accuracy from ${local.passed}/${local.turns} to ${cloud.passed}/${cloud.turns}. This is the measured speed/accuracy and resilience trade-off for the submitted configuration.`,
  '',
  'The separate local latency report measures four controlled optimizations and the forced slow-model fallback. Carrier, speech-recognition and live telephony latency remain outside this browser prototype.',
  '',
];

await mkdir(new URL('reports/', root), {recursive:true});
await writeFile(new URL('reports/cloud-latency-measurements.json', root), JSON.stringify({measuredAtUtc, model, turns:turns.length, summary, samples}, null, 2) + '\n');
await writeFile(new URL('reports/cloud-latency.md', root), report.join('\n'));
console.log(`Cloud benchmark: ${cloud.passed}/${cloud.turns} passed; p90 first text ${f(cloud.firstTextMs.p90)} ms; Gemini-planned turns ${cloud.providers.gemini}.`);
