import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createGeminiAgent } from '../src/gemini.js';
import { createProductionAgent } from '../src/agent.js';

const catalog = JSON.parse(readFileSync(new URL('../data/catalog.json', import.meta.url), 'utf8'));

test('Gemini adapter requests structured output without leaking its key', async () => {
  const secret = 'server-only-test-key';
  let request;
  const fetchImpl = async (url, options) => {
    request = {url, options};
    return {
      ok: true,
      status: 200,
      json: async () => ({
        candidates: [{content:{parts:[{text:JSON.stringify({
          intent:'quote', matchId:'M1', seatIds:['A1'], faqId:null,
          groupSize:2, budgetInr:null, budgetBasis:null,
        })}]}}],
      }),
    };
  };
  const model = createGeminiAgent({apiKey:secret, fetchImpl});
  const result = await model({message:'Can the two of us take north for Mumbai?', state:{}, catalog, signal:AbortSignal.timeout(1000)});

  assert.equal(result.intent, 'quote');
  assert.equal(result._meta.provider, 'gemini');
  assert.match(request.url, /gemini-3\.1-flash-lite:generateContent$/);
  assert.doesNotMatch(request.url, new RegExp(secret));
  assert.equal(request.options.headers['x-goog-api-key'], secret);
  assert.doesNotMatch(request.options.body, new RegExp(secret));
  const body = JSON.parse(request.options.body);
  assert.equal(body.generationConfig.responseMimeType, 'application/json');
  assert.deepEqual(body.generationConfig.responseJsonSchema.properties.matchId.enum, ['M1','M2','M3',null]);
  assert.match(body.systemInstruction.parts[0].text, /Never invent prices/);
});

test('production router falls back locally when the cloud provider fails', async () => {
  const localModel = async () => ({intent:'faq', faqId:'gates'});
  const cloudModel = async () => { const error = new Error('quota'); error.status=429; throw error; };
  const agent = await createProductionAgent(catalog, {apiKey:'configured', localModel, cloudModel});
  const result = await agent.model({message:'When may we enter?', state:{}, catalog, signal:AbortSignal.timeout(1000)});

  assert.equal(agent.mode, 'auto');
  assert.equal(agent.status.provider, 'gemini');
  assert.equal(result.intent, 'faq');
  assert.equal(result._meta.provider, 'local-fallback');
  assert.equal(result._meta.reason, 'rate-limit');
});

test('production router prefers Groq, then Gemini, without calling both on success', async () => {
  let groqCalls = 0;
  let geminiCalls = 0;
  const agent = await createProductionAgent(catalog, {
    groqApiKey:'groq-configured', apiKey:'gemini-configured',
    groqAgent:async () => { groqCalls += 1; return {intent:'fixtures', _meta:{provider:'groq'}}; },
    geminiAgent:async () => { geminiCalls += 1; return {intent:'unknown', _meta:{provider:'gemini'}}; },
    localModel:async () => ({intent:'unknown'}),
  });
  const result = await agent.model({message:'Show the schedule in different words', state:{}, catalog, signal:AbortSignal.timeout(1000)});
  assert.equal(result._meta.provider, 'groq');
  assert.equal(groqCalls, 1);
  assert.equal(geminiCalls, 0);
  assert.deepEqual(agent.status.chain.map(item => item.provider), ['groq','gemini','local']);
});

test('production router uses Gemini only after Groq fails, then local after both fail', async () => {
  let geminiFails = false;
  const agent = await createProductionAgent(catalog, {
    groqApiKey:'groq-configured', apiKey:'gemini-configured',
    groqAgent:async () => { const error = new Error('groq timeout'); error.name='TimeoutError'; throw error; },
    geminiAgent:async () => {
      if (geminiFails) throw new Error('gemini unavailable');
      return {intent:'faq', faqId:'gates', _meta:{provider:'gemini'}};
    },
    localModel:async () => ({intent:'unknown'}),
  });
  const gemini = await agent.model({message:'When may we enter?', state:{}, catalog, signal:AbortSignal.timeout(1000)});
  assert.equal(gemini._meta.provider, 'gemini-fallback');
  assert.deepEqual(gemini._meta.attempted, ['groq','gemini']);
  geminiFails = true;
  const local = await agent.model({message:'A new paraphrase', state:{}, catalog, signal:AbortSignal.timeout(1000)});
  assert.equal(local._meta.provider, 'local-fallback');
  assert.deepEqual(local._meta.attempted, ['groq','gemini','local']);
});

test('production router reports an honest local mode without a key', async () => {
  const agent = await createProductionAgent(catalog, {apiKey:'', localModel:async () => ({intent:'greet'})});
  assert.equal(agent.status.configured, false);
  assert.equal(agent.mode, 'auto');
  assert.equal((await agent.model({}))._meta.provider, 'local');
});

