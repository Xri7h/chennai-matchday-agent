import { createGeminiAgent } from './gemini.js';
import { createGroqAgent } from './groq.js';
import { createIntentModel } from './model.js';

const waitAfterFailuresMs = 30_000;

function withMeta(result, provider, detail = {}) {
  return { ...result, _meta: { ...result?._meta, provider, ...detail } };
}

function failureReason(error) {
  if (error?.status === 429) return 'rate-limit';
  if (['AbortError', 'TimeoutError'].includes(error?.name)) return 'timeout';
  return 'provider-error';
}

export async function createProductionAgent(catalog, options = {}) {
  const local = options.localModel ?? await createIntentModel(catalog);
  const groqKey = options.groqApiKey ?? process.env.GROQ_API_KEY;
  const geminiKey = options.apiKey ?? process.env.GEMINI_API_KEY ?? process.env.GOOGLE_API_KEY;
  const preference = options.provider ?? process.env.AGENT_PROVIDER ?? 'groq';
  const groqModelName = options.groqModelName ?? (preference === 'groq' ? options.modelName : undefined) ?? process.env.GROQ_MODEL ?? 'openai/gpt-oss-20b';
  const geminiModelName = options.geminiModelName ?? (preference === 'gemini' ? options.modelName : undefined) ?? process.env.GEMINI_MODEL ?? 'gemini-3.1-flash-lite';
  const groqTimeoutMs = Number(options.groqTimeoutMs ?? (preference === 'groq' ? options.cloudTimeoutMs : undefined) ?? process.env.GROQ_TIMEOUT_MS ?? 2500);
  const geminiTimeoutMs = Number(options.geminiTimeoutMs ?? (preference === 'gemini' ? options.cloudTimeoutMs : undefined) ?? process.env.GEMINI_FALLBACK_TIMEOUT_MS ?? (groqKey ? 5000 : process.env.GEMINI_TIMEOUT_MS ?? 8000));

  const candidates = [];
  if (groqKey) candidates.push({
    provider:'groq', model:groqModelName, timeoutMs:groqTimeoutMs,
    call:options.groqAgent ?? (preference === 'groq' ? options.cloudModel : undefined) ?? createGroqAgent({
      apiKey:groqKey, model:groqModelName, endpoint:options.groqEndpoint, fetchImpl:options.fetchImpl,
      contextMode:options.groqContextMode ?? process.env.GROQ_CONTEXT_MODE ?? 'cacheable',
    }),
    failures:0, circuitOpenUntil:0,
  });
  if (geminiKey) candidates.push({
    provider:'gemini', model:geminiModelName, timeoutMs:geminiTimeoutMs,
    call:options.geminiAgent ?? (!groqKey ? options.cloudModel : undefined) ?? createGeminiAgent({
      apiKey:geminiKey, model:geminiModelName, endpoint:options.endpoint, fetchImpl:options.fetchImpl,
    }),
    failures:0, circuitOpenUntil:0,
  });
  if (preference === 'gemini') candidates.sort((a, b) => Number(b.provider === 'gemini') - Number(a.provider === 'gemini'));

  if (!candidates.length) {
    return {
      model: async args => withMeta(await local(args), 'local', {attempted:['local']}),
      mode:'auto',
      status:{
        configured:false, provider:'local', model:'potion-base-2M', label:'Local safety fallback',
        chain:[{provider:'local', model:'potion-base-2M'}],
        reason:'No hosted-provider API key is configured.',
      },
    };
  }

  const model = async args => {
    const attempted = [];
    let lastReason = 'provider-error';
    for (const candidate of candidates) {
      if (Date.now() < candidate.circuitOpenUntil) {
        lastReason = 'circuit-open';
        continue;
      }
      attempted.push(candidate.provider);
      try {
        const providerSignal = AbortSignal.any([args.signal, AbortSignal.timeout(candidate.timeoutMs)].filter(Boolean));
        const result = await candidate.call({...args, signal:providerSignal});
        candidate.failures = 0;
        const fallback = candidate !== candidates[0];
        return withMeta(result, fallback ? `${candidate.provider}-fallback` : candidate.provider, {attempted:[...attempted]});
      } catch (error) {
        lastReason = failureReason(error);
        candidate.failures += 1;
        if (candidate.failures >= 3) candidate.circuitOpenUntil = Date.now() + waitAfterFailuresMs;
      }
    }
    attempted.push('local');
    return withMeta(await local(args), 'local-fallback', {reason:lastReason, attempted});
  };

  const chain = [
    ...candidates.map(({provider, model, timeoutMs}) => ({provider, model, timeoutMs})),
    {provider:'local', model:'potion-base-2M'},
  ];
  return {
    model,
    // Known catalog and safety cases stay deterministic; hosted reasoning is
    // reserved for turns the local classifier cannot resolve confidently.
    mode:'auto',
    status:{
      configured:true,
      provider:candidates[0].provider,
      model:candidates[0].model,
      label:candidates[0].provider === 'groq' ? 'Groq open-model agent' : 'Gemini cloud agent',
      fallback:chain.slice(1).map(item => item.model).join(' → '),
      chain,
      timeoutMs:candidates.reduce((sum, item) => sum + item.timeoutMs, 0),
    },
  };
}
