import http from 'node:http';
import os from 'node:os';
import { randomUUID } from 'node:crypto';
import { mkdir, writeFile } from 'node:fs/promises';
import { createApp } from '../server.mjs';
import { replyTurn } from '../src/conversation.js';
import { createIntentModel } from '../src/model.js';
import { loadJson, median, nearestRank, root, scoreTurn } from '../evaluation/scoring.mjs';

const catalog = await loadJson('data/catalog.json');
const cases = await loadJson('evaluation/fan-cases.json');
const rounds = 2;
const runId = randomUUID().slice(0, 8);
const run = { measuredAtUtc: new Date().toISOString(), franchise: catalog.team, venue: catalog.home_venue, firstOpponent: catalog.matches[0].opponent };
const orderedCases = [cases, [...cases].reverse()];
const turns = orderedCases.flatMap((batch, round) => batch.flatMap(scenario =>
  scenario.turns.map((expected, i) => ({
    expected, round: round + 1, id: `${scenario.id}.${i + 1}`,
    sessionId: `${runId}-${round}-${scenario.id}`,
  }))));

function listen(server) {
  return new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', () => {
      server.off('error', reject);
      resolve(server.address().port);
    });
  });
}

// The web client consumes JSON. Its first usable text arrives when the body is
// complete. The first packet or HTTP response headers can precede that event.
function postTurn(port, agent, payload) {
  const body = JSON.stringify(payload);
  const started = performance.now();
  return new Promise((resolve, reject) => {
    const request = http.request({
      hostname: '127.0.0.1', port, path: '/api/chat', method: 'POST', agent,
      headers: {
        'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body),
        Origin: `http://127.0.0.1:${port}`,
      },
    }, response => {
      response.setEncoding('utf8');
      let data = '';
      response.on('data', part => { data += part; });
      response.on('error', reject);
      response.on('end', () => {
        try {
          if (response.statusCode !== 200) throw new Error(`Chat HTTP ${response.statusCode}: ${data.slice(0, 400)}`);
          const result = JSON.parse(data);
          const usableMs = performance.now() - started;
          if (!result.text?.trim()) throw new Error('Chat endpoint returned no usable reply');
          resolve({ result, usableMs });
        } catch (error) { reject(error); }
      });
    });
    request.setTimeout(20000, () => request.destroy(new Error('Benchmark request timed out')));
    request.on('error', reject);
    request.end(body);
  });
}

const configurations = [
  { name: 'shipped', mode: 'auto', cached: true, keepAlive: true },
  { name: 'model_first', mode: 'model-first', cached: true, keepAlive: true },
  { name: 'uncached_anchors', mode: 'model-first', cached: false, keepAlive: true },
  { name: 'new_connection', mode: 'auto', cached: true, keepAlive: false },
  { name: 'rules_only', mode: 'auto', modelOff: true, keepAlive: true },
];
const handles = [];
const samples = [];
let slowResult;
try {
  for (const config of configurations) {
    const model = config.modelOff ? null : await createIntentModel(catalog, { cacheEmbeddings: config.cached });
    const server = await createApp({ catalog, model, mode: config.mode, storePath: null, timeoutMs: 1600 });
    const agent = new http.Agent({ keepAlive: config.keepAlive, maxSockets: 1 });
    const port = await listen(server);
    const handle = { ...config, server, agent, port };
    handles.push(handle);
    await postTurn(port, agent, { message: 'Which stadium?', sessionId: 'warmup' });
  }
  for (const [i, turn] of turns.entries()) {
    // Rotate which configuration runs first so that order and CPU warmup do
    // not systematically favor the same configuration.
    const order = [...handles.slice(i % handles.length), ...handles.slice(0, i % handles.length)];
    for (const setup of order) {
      const { result, usableMs } = await postTurn(setup.port, setup.agent, {
        message: turn.expected.fan, sessionId: turn.sessionId,
      });
      if (![result.modelMs, result.logicMs].every(x => Number.isFinite(x) && x >= 0)) {
        throw new Error('Chat response is missing a modelMs or logicMs measurement');
      }
      samples.push({
        configuration: setup.name, round: turn.round, turn: turn.id, source: result.source,
        modelMs: result.modelMs, logicMs: result.logicMs, firstTextMs: usableMs,
        pass: scoreTurn(turn.expected, result).length === 0,
      });
    }
  }
  const primary = handles[0];
  const slow = await postTurn(primary.port, primary.agent, {
    sessionId: 'forced-slow-probe', message: 'Can you explain what my pass allows?', scenario: 'slow',
  });
  slowResult = { ...slow.result, firstTextMs: slow.usableMs };
  if (slowResult.modelMs < 1200 || !/slow|time|taking|trouble|delay|unavailable|problem|longer|failed/i.test(slowResult.text)) {
    throw new Error(`Slow scenario did not exercise the expected timeout path: ${JSON.stringify(slowResult)}`);
  }
} finally {
  for (const h of handles) h.agent.destroy();
  await Promise.all(handles.map(h => new Promise(resolve => h.server.close(resolve))));
}

// Isolate another production choice without attributing file-system time to
// HTTP or network behavior. Both halves use exactly the rules-only engine.
const catalogSamples = { readPerTurn: [], preloaded: [] };
for (const turn of turns) {
  const order = catalogSamples.preloaded.length % 2 ? ['preloaded','readPerTurn'] : ['readPerTurn','preloaded'];
  for (const choice of order) {
    const start = performance.now();
    const input = choice === 'preloaded' ? catalog : await loadJson('data/catalog.json');
    await replyTurn({ message: turn.expected.fan, state: {}, catalog: input });
    catalogSamples[choice].push(performance.now() - start);
  }
}
const summary = {};
for (const config of configurations) {
  const items = samples.filter(r => r.configuration === config.name);
  const metrics = {};
  for (const field of ['modelMs','logicMs','firstTextMs']) {
    const values = items.map(x => x[field]);
    metrics[field] = { median: median(values), p90: nearestRank(values, .9), worst: Math.max(...values) };
  }
  summary[config.name] = { turns: items.length, passed: items.filter(x => x.pass).length, ...metrics };
}
const f = n => n.toFixed(3);
const metricCell = stats => `${f(stats.median)} / ${f(stats.p90)} / ${f(stats.worst)}`;
const tableRow = (label, a, b, scope) => `| ${label} | ${scope} | ${f(a)} | ${f(b)} | ${f(a-b)} |`;
const p90catalog = key => nearestRank(catalogSamples[key], .9);
const semanticA = summary.model_first;
const selective = summary.shipped;
const returnQuestion = config => samples.filter(s => s.configuration === config && s.turn === 'paraphrase-return.1');
const returnRules = returnQuestion('rules_only');
const returnSemantic = returnQuestion('shipped');
const countPass = rows => rows.filter(r => r.pass).length;
const lines = [
  '# Text latency and routing trade-offs',
  '',
  `Measured locally on ${os.platform()} ${os.arch()} with Node ${process.versions.node} using the assumed 2027 ${run.franchise} caselet catalog at ${run.venue}. The primary run used the in-process intent model, the actual chat HTTP route, a preloaded catalog and one persistent loopback connection. Each configuration received the same ${turns.length} fan turns (${rounds} passes through the evaluation set). Each conversation got a new session on each pass. Application startup and one warmup turn were excluded.`,
  '',
  '## Turn measurements',
  '',
  'Values are milliseconds, shown as **median / p90 / worst**. Model time includes the intent call when invoked and is zero on locally resolved turns. Logic is the app-reported engine processing time outside the model. The client measures elapsed time from request dispatch until it parses the complete chat JSON and can read the first word. This includes loopback HTTP and request handling. UI paint, speech synthesis, speech recognition and carrier timing lie outside this clock.',
  '',
  '| Configuration | Turns | Model call | Own logic | First usable text | Passed rubric |',
  '| --- | ---: | ---: | ---: | ---: | ---: |',
  ...Object.entries(summary).map(([k,s]) => `| ${k} | ${s.turns} | ${metricCell(s.modelMs)} | ${metricCell(s.logicMs)} | ${metricCell(s.firstTextMs)} | ${s.passed}/${s.turns} |`),
  '',
  `The guide for a text pipeline is about 2,500 ms at median and 4,000 ms at p90. This local prototype measured ${f(selective.firstTextMs.median)} ms and ${f(selective.firstTextMs.p90)} ms. Payloads and the model stay on this machine. Deployed networks and real calls require their own measurements.`,
  '',
  '## Controlled changes',
  '',
  'Each comparison changes the named behavior while retaining the same workload. Positive savings indicate lower latency. The fourth row is a separate in-process comparison. Its readings cannot be added to the HTTP results.',
  '',
  '| Change | Timed scope at p90 | Before (ms) | After (ms) | Saved (ms) |',
  '| --- | --- | ---: | ---: | ---: |',
  tableRow('Precompute catalog anchor embeddings', summary.uncached_anchors.modelMs.p90, semanticA.modelMs.p90, 'model-first model call'),
  tableRow('Resolve recognized requests before invoking the model', semanticA.firstTextMs.p90, selective.firstTextMs.p90, 'HTTP to text'),
  tableRow('Reuse the local HTTP connection', summary.new_connection.firstTextMs.p90, selective.firstTextMs.p90, 'HTTP to text'),
  tableRow('Reuse the parsed catalog across requests', p90catalog('readPerTurn'), p90catalog('preloaded'), 'rules-only engine plus catalog access'),
  '',
  '## Speed and accuracy',
  '',
  `Bypassing the model gave ${summary.rules_only.passed}/${summary.rules_only.turns} passing turns at ${f(summary.rules_only.firstTextMs.p90)} ms p90. Enabling selective semantic matching gave ${selective.passed}/${selective.turns} passing turns at ${f(selective.firstTextMs.p90)} ms p90. Sending every eligible turn through the model gave ${semanticA.passed}/${semanticA.turns} passing turns at ${f(semanticA.firstTextMs.p90)} ms p90. The denominator counts two runs of each fan message. [Individual verdicts and timing rows](latency-measurements.json) identify the cases behind those scores.`,
  '',
  `On the indirect question about leaving at the innings break and coming back, rules-only answered correctly on ${countPass(returnRules)}/${returnRules.length} attempts using zero model time. Selective semantic routing spent a median of ${f(median(returnSemantic.map(s => s.modelMs)))} ms on the model call and answered correctly on ${countPass(returnSemantic)}/${returnSemantic.length} attempts. This isolates the extra inference cost of recognizing that phrasing.`,
  '',
  '## Timeout demonstration',
  '',
  `The delivery route was called once with its slow-model scenario. It injected an eight-second wait into the model adapter. The server deadline was 1.6 seconds, with no automatic retries. Source: \`${slowResult.source}\`. Time to usable fallback: ${f(slowResult.firstTextMs)} ms. The UI can read the resulting sentence aloud with browser speech enabled. This separate fault-injection turn is excluded from the ordinary latency distribution.`,
  '',
  `> ${slowResult.text}`,
  '',
  'Run `node scripts/benchmark.mjs` for a fresh measurement. The script interleaves configurations at each turn, reverses scenario order for the second pass, averages the two middle values for the median and uses nearest-rank p90. Very small local differences, especially tail values, can vary with CPU scheduling, antivirus and other host activity.',
];
await mkdir(new URL('reports/',root),{recursive:true});
await writeFile(new URL('reports/latency-measurements.json',root), JSON.stringify({ run, summary, slowResult, samples, catalogSamples },null,2) + '\n');
await writeFile(new URL('reports/latency.md',root),lines.join('\n') + '\n');
console.log(lines.join('\n'));
