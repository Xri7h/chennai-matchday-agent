# Assignment submission: Chennai Matchday

One segment: **repeat fans**. Team: **Chennai Super Kings**. Fixtures, prices, policies and all 60 seed leads are synthetic. The assignment heading says five deliverables but enumerates D1–D4; the required AI-tool disclosure is included below and in the README.

| Deliverable | Files or link |
| --- | --- |
| D1 — runnable text agent, outreach logic and voice demo | [Run instructions](README.md), `server.mjs`, `src/`, `public/`, [catalog](data/catalog.json), [60 seed leads](data/leads.csv) |
| D2 — 20 scored repeat fans, contact/skip, channel, timing and first message | [Scoring and gates](reports/outreach.md), [all 20 decisions](reports/outreach.csv) |
| D3 — evaluation, failures, fixes and latency | [Evaluation](reports/evaluation.md), [38 development turns](evaluation/fan-cases.json), [9 historical regression turns](evaluation/holdout.json), [76-turn local latency benchmark](reports/latency.md), [provider comparison](reports/provider-comparison.md), raw JSON files in `reports/` |
| D4 — recorded walkthrough | [Loom video](https://www.loom.com/share/3c6af046dd7d43e4b586fb49e6a28f17), [recording notes](demo/README.md) |

## Reproduce

Use Node.js 22 or newer. No package installation is required. Run `node server.mjs` and open `http://127.0.0.1:4173`. Run `node --test` for the automated checks. Copy `.env.example` to `.env` only if enabling hosted providers. With no keys, catalog answers and the bundled local semantic fallback remain available. Browser live captions depend on the browser's speech-recognition service; the recording backup requires a Groq key.

## Models and speech

- Web intent planning: Groq `openai/gpt-oss-20b`, then Gemini `gemini-3.1-flash-lite`, then local MinishLab `potion-base-2M` intent matching. Deterministic code handles recognized catalog requests, safety, arithmetic and validation.
- Browser live captions: browser SpeechRecognition, English India. Recording backup: Groq `whisper-large-v3-turbo`. Spoken web replies: browser SpeechSynthesis, with the available English voice.
- Telephone demonstration: separately configured Exotel managed voice agent. Its conversation does not run through the web planner. The configured speech services used Smallest AI Pulse for recognition and Lightning 3.1 Pro / Mishka for speech output; the managed conversational LLM identity has not been verified. Those managed settings and credentials are not bundled in the repository.

## Scope and evidence boundaries

- 56/56 automated tests passed during submission preparation. Development and historical regression cases are disclosed as regression evidence, not an untouched holdout or proof of arbitrary-question accuracy.
- The saved latency benchmark covers 76 local text turns and reports model time, logic time and first usable HTTP text. It excludes microphone, TTS, browser painting and telephone transport. The provider comparison reports separate successful engine-completion timings. A 40-turn live-phone first-spoken-word study has not been completed.
- The normal conversation, hard questions, slow-provider behavior and phone demonstration are shown in the supplied video. Its duration is **5:31**, exceeding the requested 3–5-minute range. It should be shortened for strict adherence. The correct saved local benchmark count is **76**, regardless of a spoken/transcribed slip in the video; use the reports for the exact figures.
- Voice is demonstrated on the owner's phone. Carrier SMS delivery, a live staffed handoff, inventory reservation, checkout and payment are not implemented or verified. A handoff records a request and clearly states when no representative is connected.
- Exotel API acceptance is not reported as an answered or completed call. Authenticated Exotel progress callbacks and synchronizing spoken STOP back to the web preference store remain unfinished. Web lead-linked STOP persists and blocks subsequent outreach; signed Twilio inbound STOP is covered by local tests.
- The web interface is English. The managed phone agent needs a separate English-only language/output check before broader use.

## Privacy and configuration

The repository excludes `.env`, `.runtime/`, `.qa/`, local preference backups and private phone/provider configuration. Only empty configuration examples and synthetic test numbers are included. The owner's real number is deliberately kept in the ignored local runtime store rather than in the public seed CSV. Reviewers can configure their own verified number locally. No recruiter email, assignment attachment, browser session, token or credential is included.

## AI-tool disclosure

OpenAI Codex and coding agents assisted with implementation, tests, synthetic examples, reports and documentation. Anthropic's frontend-design skill informed the UI redesign. Runtime model roles are described above; model outputs are constrained by catalog validation and deterministic rendering. Bundled models, fonts and photographs retain their source and license notices.
