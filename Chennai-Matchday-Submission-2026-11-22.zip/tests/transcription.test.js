import test from 'node:test';
import assert from 'node:assert/strict';
import { createGroqTranscriber } from '../src/transcription.js';

test('Groq transcriber sends supported audio as multipart data and returns text', async () => {
  let inspected = false;
  const transcribe = createGroqTranscriber({
    apiKey:'test-key',
    fetchImpl:async (url, init) => {
      assert.equal(url,'https://api.groq.com/openai/v1/audio/transcriptions');
      assert.equal(init.method,'POST');
      assert.equal(init.headers.Authorization,'Bearer test-key');
      assert.ok(init.body instanceof FormData);
      assert.equal(init.body.get('model'),'whisper-large-v3-turbo');
      assert.equal(init.body.get('language'),'en');
      const file=init.body.get('file');
      assert.equal(file.type,'audio/webm');
      assert.equal(file.name,'speech.webm');
      assert.equal(file.size,64);
      inspected=true;
      return new Response(JSON.stringify({text:'  Two tickets for Mumbai Indians.  '}),{status:200,headers:{'Content-Type':'application/json'}});
    },
  });
  const result=await transcribe({audioBuffer:Buffer.alloc(64,1),mimeType:'audio/webm;codecs=opus'});
  assert.equal(result.text,'Two tickets for Mumbai Indians.');
  assert.equal(result.provider,'groq');
  assert.equal(inspected,true);
});

test('Groq transcriber rejects unsupported formats and reports missing configuration', async () => {
  const unavailable=createGroqTranscriber({apiKey:''});
  await assert.rejects(()=>unavailable({audioBuffer:Buffer.alloc(64),mimeType:'audio/webm'}),error=>error.status===503);
  const configured=createGroqTranscriber({apiKey:'test',fetchImpl:async()=>{throw new Error('must not fetch');}});
  await assert.rejects(()=>configured({audioBuffer:Buffer.alloc(64),mimeType:'audio/flac'}),error=>error.status===415);
});
