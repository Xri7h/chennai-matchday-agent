import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { replyTurn } from '../src/conversation.js';

const catalog = JSON.parse(readFileSync(new URL('../data/catalog.json', import.meta.url), 'utf8'));
const turn = (message, state = {}, extra = {}) => replyTurn({ catalog, message, state, ...extra });

test('catalog prices and available areas agree for all fixtures', () => {
  assert.ok(catalog.matches.length >= 3 && catalog.seat_areas.length >= 4 && catalog.faq.length >= 8 && catalog.not_published.length >= 3);
  for (const match of catalog.matches) {
    const priced = catalog.seat_areas.filter(s => Number.isFinite(s.price_inr_by_match[match.id])).map(s => s.id);
    assert.deepEqual(match.seat_areas_available.toSorted(), priced.toSorted());
  }
});

test('CSK names the selected home team and MI selects the Mumbai fixture', async () => {
  const home = await turn('Two tickets for CSK');
  assert.equal(home.state.matchId, undefined);
  assert.equal(home.state.awaiting, 'match');
  const away = await turn('MI please', home.state);
  assert.equal(away.state.matchId, 'M1');
  assert.match(away.text, /Mumbai Indians.*₹2,400/);
  const fixture = await turn('When is CSK vs MI?');
  assert.match(fixture.text, /Chennai Super Kings vs Mumbai Indians.*12 Apr 2027.*M\. A\. Chidambaram Stadium, Chepauk, Chennai/);
  const quote = await turn('Tickets for Chennai Super Kings versus Mumbai Indians?');
  assert.match(quote.text, /Mumbai Indians.*North Stand ₹1,200/);
});

test('resolves partial preferences across clarification, comparison and switch', async () => {
  const first = await turn('Two East Stand tickets, ₹4,000 total');
  assert.equal(first.state.groupSize, 2);
  assert.equal(first.state.awaiting, 'match');
  const second = await turn('Bengaluru please', first.state);
  assert.match(second.text, /₹4,000 total for 2/);
  const third = await turn('Compare the east and north stands', second.state);
  assert.deepEqual(third.state.seatIds, ['A2', 'A1']);
  assert.match(third.text, /East Stand/);
  assert.match(third.text, /North Stand/);
  const revised = await turn('Change from East Stand to North Stand instead', third.state);
  assert.deepEqual(revised.state.seatIds, ['A1']);
  const next = await turn('I meant Mumbai. Same seats.', revised.state);
  assert.equal(next.state.matchId, 'M1');
  assert.match(next.text, /₹2,400 total for 2/);
  assert.equal(next.state.budgetInr, 4000);
});

test('keeps ambiguous budget and explicit budget basis distinct', async () => {
  const first = await turn('Party of three for Mumbai. My budget is 1800.');
  assert.equal(first.state.awaiting, 'basis');
  const second = await turn('Per ticket', first.state);
  assert.match(second.text, /₹5,400 total for 3/);
  assert.doesNotMatch(second.text, /Pavilion/);
  const third = await turn('Actually, ₹2,000 total', second.state);
  assert.match(third.text, /No listed option.*₹2,000 total/);
});

test('comparison shows requested over-budget areas instead of hiding them', async () => {
  const first = await turn('Two tickets for Mumbai in North Stand. My budget is ₹2,500 total.');
  const compared = await turn('Compare North Stand with East Stand for the same match.', first.state);
  assert.match(compared.text, /North Stand.*₹2,400 total.*within your budget/i);
  assert.match(compared.text, /East Stand.*₹3,600 total.*₹1,100 over your total budget/i);
  assert.deepEqual(compared.state.seatIds, ['A1', 'A2']);
});

test('does not confuse a missing area with a live seat inventory', async () => {
  const unavailable = await turn('Can I get Club Lounge for Kolkata?');
  assert.match(unavailable.text, /Club Lounge is not listed/);
  assert.doesNotMatch(unavailable.text, /sold out/i);
  const adjacent = await turn('Will you guarantee that we sit next to each other?', unavailable.state);
  assert.match(adjacent.text, /does not publish.*human/);
});

test('names every unpublished topic in a compound request', async () => {
  const result = await turn('Can you guarantee wheelchair access, parking, and two adjacent seats?');
  assert.match(result.text, /parking arrangements/i);
  assert.match(result.text, /accessibility arrangements/i);
  assert.match(result.text, /live inventory or adjoining seats/i);
  assert.match(result.text, /human ticket representative/i);
});

test('opt-out takes precedence over sales and can be issued politely', async () => {
  for (const message of ['STOP', 'Please, stop!', 'No more sales calls', "Don't contact me; when is MI?", 'Opt me out']) {
    const result = await turn(message, {}, { model: () => { throw new Error('Unnecessary model call'); } });
    assert.equal(result.state.optedOut, true);
    assert.equal(result.source, 'local');
  }
  const decline = await turn('No thanks');
  assert.equal(decline.state.declined, true);
  assert.equal(decline.state.optedOut, undefined);
  assert.notEqual((await turn('End time for RCB?')).intent, 'optout');
});

test('catalog policy and grounding constrain model proposals', async () => {
  const unpublished = await turn('Which seats have an unobstructed view?', {}, { mode: 'model-first', model: () => ({ intent: 'quote', text: 'Perfect view!' }) });
  assert.equal(unpublished.source, 'local');
  assert.match(unpublished.text, /does not publish seat views/);
  const invalid = await turn('A query with unfamiliar wording', {}, { model: () => ({ intent: 'faq', faqId: 'bogus', text: 'Guaranteed refund' }) });
  assert.equal(invalid.intent, 'unknown');
  assert.doesNotMatch(invalid.text, /guaranteed refund/i);
  const valid = await turn('An indirectly phrased entry question', {}, { model: () => ({ intent: 'faq', faqId: 'gates', text: 'Eat free all day', groupSize: 90 }) });
  assert.equal(valid.text, catalog.faq.find(f => f.id === 'gates').answer);
  assert.equal(valid.state.groupSize, undefined);
});

test('an exact published FAQ cannot be overwritten by a cloud misclassification', async () => {
  let calls = 0;
  const result = await turn('My five-year-old is coming. Does my child need a separate ticket?', {}, {
    mode: 'model-first',
    model: () => { calls += 1; return { intent: 'quote', groupSize: 5 }; },
  });
  assert.equal(calls, 0);
  assert.equal(result.intent, 'faq');
  assert.match(result.text, /five or older needs a ticket/i);
});

test('answers both a published policy and a catalog price in one turn', async () => {
  const result = await turn('What time do the gates open for the MI game and how much is a North Stand seat?');
  assert.match(result.text, /gates open two hours before/i);
  assert.match(result.text, /North Stand ₹1,200 each/);
});

test('returns the requested number of cheapest seating areas', async () => {
  const result = await turn('What are the two cheapest stands for the RCB game?');
  assert.match(result.text, /North Stand ₹1,400 each/);
  assert.match(result.text, /East Stand ₹2,000 each/);
  assert.doesNotMatch(result.text, /Pavilion ₹3,200 each/);
});

test('an explicit cheapest ranking is not hidden by a remembered budget', async () => {
  const first = await turn('Two tickets for Mumbai in North Stand. My budget is ₹2,500 total.');
  const result = await turn('What are the two cheapest stands for the RCB game?', first.state);
  assert.match(result.text, /North Stand ₹1,400 each/);
  assert.match(result.text, /East Stand ₹2,000 each/);
  assert.match(result.text, /₹300 over your total budget/);
  assert.match(result.text, /₹1,500 over your total budget/);
});

test('a model ignoring abort cannot hang a turn or erase conversation memory', async () => {
  const first = await turn('Two tickets for Mumbai');
  const start = performance.now();
  const stalled = await turn('Can you explain that weird thing?', first.state, { model: () => new Promise(() => {}), timeoutMs: 15 });
  assert.equal(stalled.source, 'fallback');
  assert.match(stalled.text, /try again|human/i);
  assert.equal(stalled.state.matchId, 'M1');
  assert.ok(stalled.modelMs > 0 && performance.now() - start < 1000);
});

test('provider failures retain a safe failure category', async () => {
  const limited = await turn('Can you decode this unfamiliar request?', {}, {
    model: () => { const error = new Error('limited'); error.status = 429; throw error; },
  });
  assert.equal(limited.provider, 'unavailable');
  assert.equal(limited.providerMeta.reason, 'rate-limit');
  assert.doesNotMatch(JSON.stringify(limited.providerMeta), /limited/);
});

test('unknown opponents and areas never borrow a known price or overwrite a budget', async () => {
  const first = await turn('Two North Stand tickets for MI, Rs 4000 total');
  const unknownTeam = await turn('What do Gujarat Titans tickets cost?', first.state);
  assert.match(unknownTeam.text, /does not publish.*human/);
  assert.doesNotMatch(unknownTeam.text, /₹/);
  const bogusSeat = await turn('Is a Diamond Deck ticket for MI ₹500?', first.state);
  assert.match(bogusSeat.text, /human/);
  assert.equal(bogusSeat.state.budgetInr, 4000);
  const verifyPrice = await turn('Is an East Stand ticket for MI ₹500?', first.state);
  assert.match(verifyPrice.text, /East Stand ₹1,800/);
  assert.equal(verifyPrice.state.budgetInr, 4000);
});

test('fixture attributes must agree with a published CSK home fixture before pricing', async () => {
  const unsupported = [
    'How much are tickets for Kolkata Knight Riders vs Delhi Capitals?',
    'What is the North Stand price for CSK vs Delhi Capitals?',
    'How much is North Stand for CSK vs Mumbai Indians on 30 May 2027?',
    'Compare North Stand prices for CSK vs Mumbai Indians and CSK vs Delhi Capitals.',
    'What is the North Stand price for CSK vs Mumbai Indians in the 2028 season?',
    'How much is Mumbai Indians vs CSK at Wankhede Stadium?',
    'What was the North Stand price for CSK vs Mumbai Indians in 2026?',
    'How much is North Stand for the CSK vs RCB semifinal?',
    'What is the East Stand price for Delhi Capitals vs Kolkata Knight Riders?'
  ];
  for (const message of unsupported) {
    const result = await turn(message);
    assert.equal(result.intent, 'unknown', message);
    assert.doesNotMatch(result.text, /₹[\d,]+/, message);
  }
  const valid = await turn('What is the East Stand price for CSK vs RCB at M. A. Chidambaram Stadium on 18 April 2027?');
  assert.match(valid.text, /East Stand ₹2,000 each/);
});

test('can answer a published price and flag unknown policy in the same turn', async () => {
  const result = await turn('What do two North Stand tickets for MI cost, and is parking included?');
  assert.match(result.text, /North Stand ₹1,200 each \(₹2,400 total for 2\)/);
  assert.match(result.text, /does not publish parking.*human/);
});
