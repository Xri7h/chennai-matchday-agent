import test from 'node:test';
import assert from 'node:assert/strict';
import {draftOutreach, loadLeads, planOutreach, sampleCampaignTime} from '../src/outreach.js';

const leads = await loadLeads();
const now = sampleCampaignTime;
const plan = planOutreach(leads, {now});
const byId = id => plan.find(row => row.lead_id === id);
const smsLead = leads.find(row => row.lead_id === 'L057');

test('the report retains each of the 20 selected rows and reconciles score components', () => {
  assert.equal(leads.length, 60);
  assert.equal(plan.length, 20);
  assert.equal(new Set(plan.map(row => row.lead_id)).size, 20);
  for (const row of plan) {
    assert.equal(row.score, Math.max(0, row.intent + row.engagement + row.history + row.fatigue));
  }
  assert.deepEqual(plan.filter(row => row.decision === 'contact_now').map(row => row.lead_id),
    ['L043', 'L049', 'L052', 'L057']);
  assert.equal(byId('L057').score, 76);
  assert.equal(byId('L052').channel, 'voice');
  assert.match(byId('L057').first_message, /STOP/);
  assert.match(byId('L052').first_message, /say stop/i);
});

test('all gate failures and uncertain consents remain visible, without a contact draft', () => {
  assert.deepEqual(byId('L045').flags, ['DND registered', 'contacted today']);
  assert.ok(byId('L058').flags.includes('unknown consent_voice'));
  assert.ok(byId('L053').flags.includes('missing or invalid months_since_last_purchase'));
  for (const row of plan.filter(row => ['skip', 'hold'].includes(row.decision))) {
    assert.equal(row.channel, null);
    assert.equal(row.first_message, null);
    assert.equal(draftOutreach(leads, row.lead_id, {now}).ok, false);
  }
});

test('new opt-outs, same-day outreach and revoked permission override an eligible score', () => {
  assert.equal(draftOutreach(leads, 'L057', {now}).ok, true);
  assert.equal(draftOutreach(leads, 'L057', {now, optedOutIds: new Set(['L057'])}).ok, false);
  assert.equal(draftOutreach(leads, 'L057', {now, contactedTodayIds: ['L057']}).ok, false);
  const revoked = {...smsLead, consent_sms: '', consent_voice: 'N'};
  assert.equal(draftOutreach([revoked], 'L057', {now}).ok, false);
  assert.equal(draftOutreach(leads, 'L001', {now}).ok, false);
});

test('channel consent is independent and DND or unknown DND blocks either channel', () => {
  assert.equal(draftOutreach([{...smsLead, consent_sms:'', consent_voice:'Y'}], 'L057', {now}).row.channel, 'voice');
  for (const dnd of ['Y', '', 'unknown']) {
    assert.equal(draftOutreach([{...smsLead, dnd_registered:dnd}], 'L057', {now}).ok, false);
  }
});

test('an immediate telecom dispatch rechecks the explicitly chosen channel', () => {
  const both = {...smsLead, consent_sms:'Y', consent_voice:'Y'};
  assert.equal(draftOutreach([both],both.lead_id,{now,channel:'voice'}).row.channel,'voice');
  const revoked = draftOutreach([{...both,consent_voice:'N'}],both.lead_id,{now,channel:'voice'});
  assert.equal(revoked.ok,false);
  assert.match(revoked.reason,/no affirmative voice consent/);
});

test('policy schedules outside 10:00 inclusive to 19:00 exclusive in India time', () => {
  for (const [at, ok, expected] of [
    ['2027-03-31T22:00:00Z', false, '2027-04-01T10:00:00+05:30'],
    ['2027-04-01T04:29:59Z', false, '2027-04-01T10:00:00+05:30'],
    ['2027-04-01T04:30:00Z', true, '2027-04-01T10:00:00+05:30'],
    ['2027-04-01T13:29:59Z', true, '2027-04-01T18:59:59+05:30'],
    ['2027-04-01T13:30:00Z', false, '2027-04-02T10:00:00+05:30'],
    ['2027-12-31T16:00:00Z', false, '2028-01-01T10:00:00+05:30'],
  ]) {
    const draft = draftOutreach(leads, 'L057', {now:at});
    assert.equal(draft.ok, ok);
    assert.equal(draft.row.scheduled_at, expected);
  }
  assert.throws(() => planOutreach(leads, {now:'unknown'}), /Invalid campaign time/);
});

test('duplicate identity across segments flags both records and differing cities stay distinct', () => {
  const other = {...smsLead, name:'  MEERA   MENON ', lead_id:'test', segment:'new_buyer'};
  const affected = draftOutreach([...leads, other], 'L057', {now});
  assert.equal(affected.ok, false);
  assert.match(affected.reason, /possible duplicate with test/);
  assert.equal(byId('L042').flags.length, 0);
  assert.equal(byId('L044').flags.length, 0);
  assert.match(draftOutreach([...leads, {...smsLead, name:'Other'}], 'L057', {now}).reason, /repeated lead ID/);
});

test('invalid counts and inconsistent segment history cannot make a draft eligible', () => {
  for (const bad of [{tickets_bought_lifetime:'-1'}, {months_since_last_purchase:''},
    {months_since_last_purchase:'12'}, {days_since_last_contact:'-7'}, {sms_replies_30d:'1.5'}]) {
    const result = draftOutreach([{...smsLead, ...bad}], 'L057', {now});
    assert.equal(result.ok, false);
    assert.ok(result.row.flags.length > 0);
  }
});

test('a nurture date is a review date and never grants release', () => {
  const result = draftOutreach(leads, 'L044', {now});
  assert.equal(result.row.scheduled_at, '2027-04-08T10:00:00+05:30');
  assert.equal(result.row.decision, 'nurture');
  assert.equal(result.ok, false);
  assert.equal(draftOutreach(leads, 'L044', {now:result.row.scheduled_at}).ok, false);
});
