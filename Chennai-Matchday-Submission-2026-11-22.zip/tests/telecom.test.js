import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import {
  createDryRunTelecomProvider, createTelecomStore, createTwilioTelecomProvider, createExotelTelecomProvider,
  normalizePhone, twilioSignature,
} from '../src/telecom.js';

test('Exotel calls the demo recipient directly into a flow without a second phone leg',async()=>{
  let count=0;
  const provider=createExotelTelecomProvider({accountSid:'testaccount',apiKey:'testkey',apiToken:'testtoken',callerId:'08000000000',flowId:'12345',
    fetchImpl:async(url,init)=>{
      count++;assert.equal(url,'https://api.exotel.com/v1/Accounts/testaccount/Calls/connect.json');
      assert.equal(init.body.get('From'),'+15555550101');assert.equal(init.body.has('To'),false);
      assert.equal(init.body.get('Url'),'https://my.exotel.com/testaccount/exoml/start_voice/12345');
      assert.equal(init.body.has('Record'),false);
      assert.equal(init.headers.Authorization,'Basic '+Buffer.from('testkey:testtoken').toString('base64'));
      return new Response(JSON.stringify({Call:{Sid:'exotel-test',Status:'queued'}}),{status:200});
    }});
  const result=await provider.startCall({to:'+15555550101',dispatchId:'test-dispatch'});
  assert.equal(result.providerId,'exotel-test');assert.equal(count,1);
  assert.equal(JSON.stringify(provider.status).includes('testtoken'),false);
  await assert.rejects(()=>provider.sendSms(),/voice only/);
});

test('phone normalization accepts E.164 without logging or returning a stored number', async t => {
  const temp = await mkdtemp(path.join(tmpdir(),'telecom-store-'));
  t.after(() => rm(temp,{recursive:true,force:true}));
  const file = path.join(temp,'private.json');
  const phone = '+1' + '5'.repeat(10);
  assert.equal(normalizePhone(phone),phone);
  assert.throws(() => normalizePhone('555-0100'),/E\.164/);
  const store = await createTelecomStore(file);
  await store.setPhone('L057',phone);
  assert.equal(store.snapshot().profiles.L057.phoneE164,phone);
  assert.equal((await readFile(file,'utf8')).includes(phone),true);
});

test('Twilio signature implementation matches the official webhook test vector', () => {
  const url = 'https://example.com/myapp.php?foo=1&bar=2';
  const params = new URLSearchParams({CallSid:'CA1234567890ABCDE',Caller:'+14158675310',Digits:'1234',From:'+14158675310',To:'+18005551212'});
  assert.equal(twilioSignature('12345',url,params),'L/OH5YylLD5NRKLltdqwSvS0BnU=');
});

test('dry-run provider labels acceptance honestly', async () => {
  const provider = createDryRunTelecomProvider();
  const sms = await provider.sendSms({});
  const call = await provider.startCall({});
  assert.equal(provider.real,false);
  assert.equal(sms.status,'dry_run_accepted');
  assert.equal(call.status,'dry_run_accepted');
});

test('Twilio adapter keeps credentials in the authorization header and requests callbacks', async () => {
  let captured;
  const provider = createTwilioTelecomProvider({
    accountSid:'AC_TEST', authToken:'server-secret', fromNumber:'+15555550101',
    publicBaseUrl:'https://demo.example', endpoint:'https://twilio.invalid',
    fetchImpl:async (url,options) => {
      captured={url,options};
      return new Response(JSON.stringify({sid:'SM_TEST',status:'queued'}),{status:201,headers:{'Content-Type':'application/json'}});
    },
  });
  const result = await provider.sendSms({to:'+15555550102',text:'Synthetic message',dispatchId:'dispatch-1'});
  const form = new URLSearchParams(captured.options.body);
  assert.equal(result.status,'queued');
  assert.equal(captured.url.includes('server-secret'),false);
  assert.match(captured.options.headers.Authorization,/^Basic /);
  assert.equal(form.get('StatusCallback'),'https://demo.example/webhooks/twilio/message/status?dispatchId=dispatch-1');
});

test('Twilio adapter can use approved content without leaking a custom SMS body', async () => {
  let captured;
  const provider = createTwilioTelecomProvider({
    accountSid:'AC_TEST', authToken:'server-secret', fromNumber:'+1' + '5'.repeat(10),
    contentSid:'HX_TEST', publicBaseUrl:'https://demo.example', endpoint:'https://twilio.invalid',
    fetchImpl:async (_url,options) => {
      captured=options;
      return new Response(JSON.stringify({sid:'SM_TEST',status:'queued'}),{status:201,headers:{'Content-Type':'application/json'}});
    },
  });
  await provider.sendSms({to:'+1' + '6'.repeat(10),text:'Must not be sent',dispatchId:'dispatch-2'});
  const form = new URLSearchParams(captured.body);
  assert.equal(form.get('ContentSid'),'HX_TEST');
  assert.equal(form.has('Body'),false);
});
