import { readFile, readdir, mkdir, copyFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const folders = ['data', 'demo', 'evaluation', 'models', 'public', 'reports', 'scripts', 'src', 'tests'];
const files = ['.env.example', '.gitignore', 'README.md', 'SUBMISSION.md', 'package.json', 'server.mjs'];
async function walk(dir, collect) {
  for (const entry of await readdir(path.join(root, dir), { withFileTypes: true })) {
    if (entry.isSymbolicLink()) throw new Error('Refusing symbolic link in submission');
    const name = path.posix.join(dir, entry.name);
    if (entry.isDirectory()) await walk(name, collect);
    else if (entry.isFile()) collect.push(name);
  }
}
for (const folder of folders) await walk(folder, files);

// Compare candidate bytes with private local values, without printing any value.
const privateValues = new Set();
const sensitiveKey = /api.?key|api.?token|auth.?token|account.?sid|caller.?id|phone|webhook.?secret/i;
function inspectPrivate(value, key = '') {
  if (typeof value === 'string' && sensitiveKey.test(key) && value.length >= 8) {
    privateValues.add(value);
    const digits = value.replace(/\D/g, '');
    if (/phone|caller.?id/i.test(key) && digits.length >= 10) privateValues.add(digits);
  } else if (value && typeof value === 'object') {
    for (const [childKey, child] of Object.entries(value)) inspectPrivate(child, childKey);
  }
}
try {
  const env = await readFile(path.join(root, '.env'), 'utf8');
  for (const line of env.split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
    if (match) inspectPrivate(match[2].replace(/^['"]|['"]$/g, ''), match[1]);
  }
} catch (error) { if (error.code !== 'ENOENT') throw error; }
try {
  for (const entry of await readdir(path.join(root, '.runtime'))) {
    if (entry.endsWith('.json')) {
      inspectPrivate(JSON.parse(await readFile(path.join(root, '.runtime', entry), 'utf8')));
    }
  }
} catch (error) { if (error.code !== 'ENOENT') throw error; }

const suspicious = [
  /gsk_[A-Za-z0-9]{20,}/,
  /AIza[A-Za-z0-9_-]{25,}/,
  /(?:ghp_|github_pat_)[A-Za-z0-9_]{20,}/,
  /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/,
];
const manifest = [];
for (const file of files.sort()) {
  const bytes = await readFile(path.join(root, file));
  if (bytes.length >= 25 * 1024 * 1024) throw new Error(`File exceeds browser upload limit: ${file}`);
  const text = bytes.toString('utf8');
  if ([...privateValues].some(value => text.includes(value)) || suspicious.some(pattern => pattern.test(text))) {
    throw new Error(`Sensitive-value scan failed in ${file}; no package was created.`);
  }
  manifest.push({ file, bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex') });
}
const destination = path.join(root, 'submission', `github-upload-${Date.now()}`);
await mkdir(destination, { recursive: true });
for (const { file } of manifest) {
  await mkdir(path.dirname(path.join(destination, file)), { recursive: true });
  await copyFile(path.join(root, file), path.join(destination, file));
}
await writeFile(path.join(root, 'submission', `${path.basename(destination)}-manifest.json`), JSON.stringify({
  createdAt: new Date().toISOString(), files: manifest,
  checks: { privateValueScan: 'passed', credentialPatternScan: 'passed', excluded: ['.env', '.runtime/', '.qa/', '.git/', 'submission/'] },
}, null, 2) + '\n');
console.log(JSON.stringify({ destination, files: manifest.length, bytes: manifest.reduce((sum, entry) => sum + entry.bytes, 0), scan: 'passed' }, null, 2));
