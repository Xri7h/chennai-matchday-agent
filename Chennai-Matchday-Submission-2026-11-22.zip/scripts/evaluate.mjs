import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { replyTurn } from '../src/conversation.js';
import { loadJson, root, runSuite } from '../evaluation/scoring.mjs';

const baselineOnly = process.argv.includes('--without-model');
const catalog = await loadJson('data/catalog.json');
const cases = await loadJson('evaluation/fan-cases.json');
const holdout = await loadJson('evaluation/holdout.json');
const fingerprint = createHash('sha256').update(await readFile(new URL('evaluation/fan-cases.json', root))).digest('hex').slice(0, 16);
const run = { measuredAtUtc: new Date().toISOString(), franchise: catalog.team, venue: catalog.home_venue, firstOpponent: catalog.matches[0].opponent };
const deterministic = await runSuite(cases, input => replyTurn({ ...input, catalog }));
const outcomes = { deterministic };
let heldOut;
if (!baselineOnly) {
  const { createIntentModel } = await import('../src/model.js');
  const model = await createIntentModel(catalog);
  outcomes.semantic = await runSuite(cases, input => replyTurn({ ...input, catalog, model }));
  heldOut = await runSuite(holdout, input => replyTurn({ ...input, catalog, model }));
}
const passCount = rows => rows.filter(row => row.pass).length;
const display = s => String(s).replaceAll('|', '\\|').replaceAll('\n', ' ');
const selected = outcomes.semantic ?? deterministic;
const failures = selected.filter(r => !r.pass);
const lines = [
  '# Conversation evaluation',
  '',
  `This run uses the assumed 2027 ${run.franchise} caselet catalog at ${run.venue}, with ${run.firstOpponent} as the first opponent. The fixtures, prices and policies are assignment assumptions, not official or live inventory. The development suite contains ${selected.length} English fan turns across ${cases.length} independent conversations. Each conversation starts with empty state. Within it, the next turn receives exactly the state the engine returned.`,
  '',
  '| Engine path | Turns passing all checks |',
  '| --- | ---: |',
  ...Object.entries(outcomes).map(([name, rows]) => `| ${name} | ${passCount(rows)} / ${rows.length} |`),
  '',
  '## Scoring',
  '',
  'Each labeled turn has a written expectation. A binary pass requires every specified fact or price pattern, every expected state value, a human handoff when required, and the absence of the listed unsafe claims. State assertions check corrections, group count, budget basis and remembered selections. A safe handoff counts as a miss when the question has a published answer. The input includes budget boundaries, misremembered policies, requests for payment, prompt injection, opt-out, and unfamiliar paraphrases.',
  '',
  `The full inputs and rubrics are in [fan-cases.json](../evaluation/fan-cases.json), fixture fingerprint \`${fingerprint}\`. [Per-turn transcripts](evaluation-results.json) contain the actual answer and each failed assertion. These finite checks cover the listed behaviors. Passing does not establish performance on all fan messages, real phone audio, or real-world bookings.`,
  '',
  '## Cases to review',
  '',
  ...(failures.length ? [
    '| Turn | Expected behavior | Actual reply |', '| --- | --- | --- |',
    ...failures.map(r => `| ${r.id} | ${display(r.expected)} | ${display(r.text)} |`)
  ] : ['Every scored turn in the primary configuration passed its assertions.']),
];
if (outcomes.semantic) {
  const changes = outcomes.semantic.filter((r, i) => r.pass !== deterministic[i].pass);
  lines.push('', '## Effect of adding semantic matching', '',
    `Adding the bundled intent model changed the verdict on ${changes.length} ${changes.length === 1 ? 'turn' : 'turns'}. The conversation engine still renders prices and policies from the catalog.`,
    '', ...(changes.length ? ['| Turn | Rules only | With model |', '| --- | --- | --- |',
      ...changes.map(r => `| ${r.id} | ${r.pass ? 'miss' : 'pass'} | ${r.pass ? 'pass' : 'miss'} |`)] : []));
}
if (heldOut) {
  lines.push('', '## Historical holdout regression scenarios', '',
    `The [historical holdout](../evaluation/holdout.json) contains ${heldOut.length} additional turns across ${holdout.length} conversations. These scenarios were set aside during initial development, but they have since been inspected and some phrases now appear in catalog routing keywords. They are therefore regression evidence, not an untouched final holdout. The franchise update preserves their scoring rules and updates fixture and venue references. The shipped path passed ${passCount(heldOut)}/${heldOut.length}. The latency benchmark repeats the ${selected.length} development turns.`,
    '', '| Regression turn | Result |', '| --- | --- |',
    ...heldOut.map(r => `| ${r.id} | ${r.pass?'Pass':`Miss. ${display(r.expected)} The agent replied, “${display(r.text)}”`} |`));
}
let regressions;
try {
  regressions = await loadJson('evaluation/regression-log.json');
} catch (error) {
  if (error.code !== 'ENOENT') throw error;
}
if (regressions?.fixes?.length) {
  const history = regressions.archive;
  lines.push('', '## Archived development baseline and current retest', '',
    `Before the franchise rename, the original development suite (fingerprint \`${history.fixtureFingerprint}\`) initially passed ${history.initialRules}/${history.developmentTurns} without the model and ${history.initialSemantic}/${history.developmentTurns} with it. At the end of that run the semantic path passed ${history.lastSemantic}/${history.developmentTurns} and ${history.holdoutPassed}/${history.holdoutTurns} on the holdout. The table above uses fresh ${catalog.team} responses. Scenario IDs link the following historical failures to their current retests.`, '');
  for (const item of regressions.fixes) {
    const current = selected.find(r => r.id === item.id);
    if (!current) throw new Error(`Unknown regression case ${item.id}`);
    lines.push(`- **${item.id}.** ${item.observed} ${item.change} The current retest is a **${current.pass ? 'pass' : 'miss'}**.`);
  }
}
await mkdir(new URL('reports/', root), { recursive: true });
// The diagnostic rules-only flag must not overwrite a full two-mode report.
if (!baselineOnly) {
  await writeFile(new URL('reports/evaluation-results.json', root), JSON.stringify({ run, fingerprint, outcomes, heldOut }, null, 2) + '\n');
  await writeFile(new URL('reports/evaluation.md', root), lines.join('\n') + '\n');
}
console.log(lines.join('\n'));
