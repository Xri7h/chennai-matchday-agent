import { loadEnvFile } from 'node:process';
import { setTimeout as delay } from 'node:timers/promises';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { createGroqAgent } from '../src/groq.js';
import { createGeminiAgent } from '../src/gemini.js';
import { createIntentModel } from '../src/model.js';
import { createProductionAgent } from '../src/agent.js';
import { replyTurn } from '../src/conversation.js';
import { loadJson, median, nearestRank, root, runSuite } from '../evaluation/scoring.mjs';

try { loadEnvFile(new URL('../.env', import.meta.url)); } catch (error) { if (error.code !== 'ENOENT') throw error; }

const reportOnly = process.argv.includes('--report-only');
const resultsUrl = new URL('reports/provider-comparison-results.json', root);
const catalog = await loadJson('data/catalog.json');
const development = await loadJson('evaluation/fan-cases.json');
const regression = await loadJson('evaluation/holdout.json');
const cases = [...development, ...regression];
let outcomes;
let modelInfo;
let measuredAt;

async function runConfiguration(config) {
  return runSuite(cases, async input => {
    const started = performance.now();
    const result = await replyTurn({...input, catalog, model:config.model, mode:config.mode, timeoutMs:8500});
    result.firstTextMs = performance.now() - started;
    if (config.paceMs && ['groq','gemini','gemini-fallback','local-fallback','unavailable'].includes(result.provider)) {
      await delay(config.paceMs);
    }
    return result;
  });
}

if (reportOnly) {
  const prior = JSON.parse(await readFile(resultsUrl, 'utf8'));
  outcomes = prior.outcomes;
  modelInfo = prior.model;
  measuredAt = prior.measuredAt || '2026-11-20T18:23:05.799Z';
} else {
  if (!process.env.GROQ_API_KEY) throw new Error('Set GROQ_API_KEY in .env before running provider comparison.');
  const groqModel = process.env.GROQ_MODEL || 'openai/gpt-oss-20b';
  const geminiModel = process.env.GEMINI_MODEL || 'gemini-3.1-flash-lite';
  const local = await createIntentModel(catalog);
  const production = await createProductionAgent(catalog);
  const configurations = [
    {name:'groq_cacheable', model:createGroqAgent({apiKey:process.env.GROQ_API_KEY, model:groqModel, contextMode:'cacheable'}), mode:'model-first', paceMs:2100},
    {name:'groq_minimal', model:createGroqAgent({apiKey:process.env.GROQ_API_KEY, model:groqModel, contextMode:'minimal'}), mode:'model-first', paceMs:2100},
    ...(process.env.GEMINI_API_KEY ? [{name:'gemini', model:createGeminiAgent({apiKey:process.env.GEMINI_API_KEY, model:geminiModel}), mode:'model-first', paceMs:0}] : []),
    {name:'local_semantic', model:local, mode:'model-first', paceMs:0},
    {name:'production_cascade', model:production.model, mode:production.mode, paceMs:2100},
  ];
  outcomes = {};
  for (const config of configurations) {
    console.log(`Running ${config.name}...`);
    outcomes[config.name] = await runConfiguration(config);
  }
  measuredAt = new Date().toISOString();
  modelInfo = {groq:groqModel, gemini:geminiModel};
}

const finite = (rows, field) => rows.map(row => row[field]).filter(Number.isFinite);
const stats = values => values.length ? {median:median(values), p90:nearestRank(values,.9), worst:Math.max(...values)} : null;
const plannerReturned = (name, row) => name === 'local_semantic'
  ? row.provider === 'model'
  : !['rules','local','local-fallback','unavailable'].includes(row.provider);
const residual = row => {
  const meta = row.providerMeta || {};
  const providerTotalMs = Number(meta.providerTotalMs);
  const queueMs = Number(meta.queueMs) || 0;
  return Number.isFinite(meta.clientMs) && Number.isFinite(providerTotalMs)
    ? Math.max(0, meta.clientMs - queueMs - providerTotalMs)
    : meta.networkOverheadMs;
};

const summaries = {};
for (const [name, rows] of Object.entries(outcomes)) {
  const rules = rows.filter(row => row.provider === 'rules');
  const eligible = rows.filter(row => row.provider !== 'rules');
  const returned = rows.filter(row => plannerReturned(name, row));
  const groqRows = rows.filter(row => row.provider === 'groq');
  const promptTokens = groqRows.reduce((sum, row) => sum + (row.providerMeta?.promptTokens || 0), 0);
  const cachedTokens = groqRows.reduce((sum, row) => sum + (row.providerMeta?.cachedTokens || 0), 0);
  summaries[name] = {
    turns:rows.length,
    passed:rows.filter(row => row.pass).length,
    rules:rules.length,
    eligible:eligible.length,
    returned:returned.length,
    returnedPassed:returned.filter(row => row.pass).length,
    unavailable:rows.filter(row => row.provider === 'unavailable').length,
    providers:rows.reduce((counts, row) => ({...counts,[row.provider || row.source]:(counts[row.provider || row.source] || 0) + 1}),{}),
    completionMs:stats(finite(returned,'firstTextMs')),
    modelMs:stats(finite(returned,'modelMs')),
    queueMs:stats(groqRows.map(row => row.providerMeta?.queueMs).filter(Number.isFinite)),
    promptMs:stats(groqRows.map(row => row.providerMeta?.promptMs).filter(Number.isFinite)),
    generationMs:stats(groqRows.map(row => row.providerMeta?.completionMs).filter(Number.isFinite)),
    clientResidualMs:stats(groqRows.map(residual).filter(Number.isFinite)),
    promptTokens,
    cachedTokens,
    cacheTokenRatio:promptTokens ? cachedTokens / promptTokens : null,
    cacheRequestHits:groqRows.filter(row => (row.providerMeta?.cachedTokens || 0) > 0).length,
    groqReturns:groqRows.length,
  };
}

const f = value => Number.isFinite(value) ? value.toFixed(1) : '—';
const metric = value => value ? `${f(value.median)} / ${f(value.p90)} / ${f(value.worst)}` : '—';
const ratio = (a, b) => b ? `${a}/${b}` : '—';
const report = [
  '# Provider, context and prefix-cache comparison',
  '',
  `Measured ${measuredAt} using 47 synthetic regression turns. Values are median / p90 / worst milliseconds. The three forced-provider configurations still bypass 21 exact safety, FAQ and catalog controls, leaving 26 planner-eligible turns. “Returned” means the configured planner produced a usable structured result; unavailable calls are not scored as model mistakes.`,
  '',
  '| Configuration | Local rule turns | Planner returned / eligible | Rubric pass when returned | End-to-end pass | Successful engine completion |',
  '| --- | ---: | ---: | ---: | ---: | ---: |',
  ...Object.entries(summaries).map(([name, item]) => `| ${name} | ${item.rules} | ${item.returned}/${item.eligible} | ${ratio(item.returnedPassed,item.returned)} | ${item.passed}/${item.turns} | ${metric(item.completionMs)} |`),
  '',
  '“Successful engine completion” is in-process request-to-complete-reply time, not browser paint, streaming first-token time, speech start or carrier latency.',
  '',
  '## Groq layer breakdown for successful returns',
  '',
  '| Context | Queue | Prompt processing | Generation | Client/transport residual | Cache-token ratio | Requests with cache tokens |',
  '| --- | ---: | ---: | ---: | ---: | ---: | ---: |',
  ...['groq_cacheable','groq_minimal'].map(name => {
    const item = summaries[name];
    return `| ${name} | ${metric(item.queueMs)} | ${metric(item.promptMs)} | ${metric(item.generationMs)} | ${metric(item.clientResidualMs)} | ${item.cachedTokens}/${item.promptTokens} (${f(item.cacheTokenRatio * 100)}%) | ${item.cacheRequestHits}/${item.groqReturns} |`;
  }),
  '',
  'Groq `usage.total_time` excludes queue time, so the residual subtracts both queue and provider processing from client elapsed time. It still includes transport, serialization, parsing and client scheduling.',
  '',
  '## Interpretation and selected production path',
  '',
  '- Gemini returned 17/26 planner attempts and passed 17/17 returned cases, but its successful completion latency was materially higher than Groq in this run.',
  '- Groq cacheable returned 13/26 and passed 11/13 returned cases; minimal returned 8/26 and passed 8/8. Only four cases returned in both Groq variants, and both passed all four, so this run does not establish a causal accuracy advantage for either context.',
  '- The unavailable causes were discarded by the old recorder. Most ended quickly, but they cannot honestly be labelled rate limits, timeouts or model errors. The corrected runtime now preserves the failure category for future runs.',
  '- Cache evidence is directional, not conclusive: four cacheable requests and one minimal request reported cached tokens. The contexts also differ in FAQ content, and the trials were sequential rather than matched and alternating.',
  '- Production deterministic-first routing passed 47/47: 42 turns were resolved locally and five went to Groq, all five passing. This run did not exercise Gemini or Potion failover.',
  '',
  'The production choice remains deterministic-first → Groq `openai/gpt-oss-20b` → Gemini → local Potion. It keeps known ticket facts and controls immediate, uses the faster hosted planner only for unresolved language, and retains two safe fallbacks. The 2,500 ms Groq timeout exceeds the observed 725 ms worst successful Groq completion; the 5,000 ms Gemini fallback budget exceeds the observed 4,553 ms successful p90 while keeping the two-provider budget below the 8,250 ms planner allowance.',
  '',
  'The 47 messages are a regression suite, not an untouched holdout: several phrases have since become catalog routing keywords. A publishable provider-quality claim needs a newly frozen test set plus matched, alternating, quota-paced trials with identical pre-turn state.',
  '',
  'All messages and catalog data in this comparison are synthetic caselet data. No real fan data was transmitted.',
  '',
];

await mkdir(new URL('reports/', root), {recursive:true});
await writeFile(resultsUrl, JSON.stringify({measuredAt,model:modelInfo,summaries,outcomes},null,2) + '\n');
await writeFile(new URL('reports/provider-comparison.md', root), report.join('\n'));
console.log(report.join('\n'));
