# Gemini cloud evaluation

Measured 2026-11-20T17:59:22.108Z with `gemini-3.1-flash-lite`. The production planner received only synthetic caselet messages, compact conversation state and the assumed catalog. Final prices and policy text remained locally rendered from the catalog.

| Suite | Passing turns |
| --- | ---: |
| Development | 38 / 38 |
| Held out | 9 / 9 |

Routing counts: `local-fallback` 24, `gemini` 2, `rules` 21. Exact consent, safety and published-FAQ matches may be resolved locally before the probabilistic planner.

## Failures and fixes

All cloud-evaluated development and held-out turns passed their written assertions.

The test set is finite and synthetic. A passing result does not establish real-world telephony, inventory or checkout performance.
