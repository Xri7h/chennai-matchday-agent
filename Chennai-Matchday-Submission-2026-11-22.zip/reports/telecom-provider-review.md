# Telecom provider review and verification plan

Reviewed on 21 November 2026 from provider documentation. This comparison is for a one-number assignment demonstration in India, not a production campaign. It does not treat API acceptance as proof of carrier delivery, call connection, audible speech, or a working reply path.

## Implementation update — 22 November 2026

The prototype now includes an **Exotel voice adapter** and a personal-phone demonstration shown in the [submission video](https://www.loom.com/share/3c6af046dd7d43e4b586fb49e6a28f17). It calls the configured recipient directly into an existing managed voice-agent flow. A selected-lead call rechecks campaign eligibility and actual IST hours. The separate personal self-test only calls the saved owner's number and uses explicit confirmation, idempotency and a one-minute cooldown. Credentials and real numbers remain in ignored local runtime files.

Exotel SMS, authenticated call-progress callbacks and a web-store update for spoken STOP remain unimplemented. The app therefore stops its evidence claim at API acceptance; the audible phone interaction is separate video evidence. The comparison and recommendation below are the **earlier documentation review**, retained to explain the original Twilio design rather than a claim that Exotel is still unimplemented.

## Original recommendation

Use the local dry-run adapter for routine development and the Twilio adapter for the first controlled real call to the account owner's verified number. Twilio is the best fit for this prototype because its documentation covers outbound SMS and voice, message and call status callbacks, voice text-to-speech, speech gathering, and cryptographically signed webhooks. Keep Exotel as the first India-local replacement candidate if trial onboarding or India routing prevents the Twilio demonstration.

Twilio has two material limitations for this case. Its current trial documentation says trials expire after 30 days, are limited to the sign-up country and verified recipients, and use predefined SMS content rather than arbitrary message bodies. Its India SMS pages are also inconsistent: the country guideline labels two-way SMS as supported, while a separate current help article says carrier sender rewriting makes replies to a Twilio number unavailable on the India route. The real test must therefore treat inbound SMS and STOP as unverified until a reply from the user's own handset reaches the signed webhook.

## Current official comparison

| Provider | Trial and verified-number restrictions | Voice | Inbound SMS and webhooks | Security and setup | Fit for this assignment |
| --- | --- | --- | --- | --- | --- |
| Twilio | The product trial is documented as 30 days, limited to the sign-up country and up to five verified recipients. Current trial SMS uses predefined content. Trial calls play a trial notice and are limited to verified numbers and ten minutes. | Programmable outbound and inbound voice, call progress callbacks, `<Say>` TTS and `<Gather>` speech/DTMF are documented. | Incoming-message and delivery-status webhooks are documented, but India reply reachability must be proved because the India help page describes the rewritten sender route as one-way. | Every webhook carries `X-Twilio-Signature`; HTTPS and signature validation are documented. Self-service trial onboarding is documented. | Best engineering fit and the implemented adapter; real SMS content and India replies remain account-and-route dependent. |
| Exotel | The documented India trial lasts 15 days and includes 1,000 credits, a sandbox number, and testing to verified users. Trial SMS is API-only with Exotel's default template. | Trial inbound and outbound calling is documented, and Exotel supports programmable voice and call status callbacks. | The sandbox documentation describes SMS-triggered flows using a PIN. SMS delivery callbacks are documented. A production India sender requires KYC, DLT entity, sender and template setup. | The official security page recommends HTTPS, source-IP verification, payload validation and idempotency. It does not document a webhook signature comparable to Twilio's on the reviewed page. | Strongest India-local alternative, especially for voice; more dashboard/KYC/DLT work and no reviewed signed-webhook mechanism. |
| MSG91 | Demo-mode SMS sends MSG91 test content until KYC. India production use requires KYC and DLT registration. | The official voice help states that no trial number is offered for voice services. | SMS and voice delivery-report webhooks are documented, including retries. The reviewed material does not establish an inbound handset-SMS conversation path. | India-native dashboard setup; webhook configuration and DLT work are required. | Useful production messaging candidate, but not a clean free voice-and-SMS assignment demo. |
| Plivo | Current SMS documentation says access is sales-provisioned for direct brands, is not self-service, and starts at a stated minimum monthly commitment. Domestic India DLT SMS is not currently offered. | Voice exists as a separate product, but the reviewed SMS onboarding makes the combined assignment path impractical. | India ILDO outbound SMS is documented. The reviewed pages do not establish the required self-service inbound STOP path. | Sales onboarding rather than a quick trial. | Not realistic for this small demonstration under the current documented access model. |

## Implemented provider boundary

`src/telecom.js` exposes the same operations for every provider:

- `sendSms` returns a provider identifier and provider status;
- `startCall` returns a provider identifier and provider status;
- `verifyWebhook` authenticates callbacks;
- `status` declares whether the adapter is real and configured.

The default `dry-run` adapter never contacts a carrier. The Twilio adapter uses server-side credentials, form-encoded REST calls, status callback URLs, and the official HMAC-SHA1 webhook construction. The Exotel adapter now shares the provider boundary for voice; its unsupported SMS and callback-verification operations fail safely.

For current trial accounts, `TWILIO_CONTENT_SID` optionally switches the SMS request from a custom `Body` to a Twilio Content Template (`ContentSid`). This does not claim that a particular template, recipient or India route is enabled; provider acceptance and the subsequent status webhook remain the evidence.

## Safety and state model

Immediately before each dispatch, the server recomputes the selected channel's affirmative consent, DND status, duplicate and malformed-data blocks, score tier, same-day contact state, persistent opt-out state, and the India campaign window. Real provider acceptance records a same-day contact; a dry-run does not suppress a later real test.

The privately entered demo number is stored only in ignored `.runtime/telecom.json`. API responses expose only `phoneConfigured`. Dispatch records omit the number and message text from the browser status API. Credentials remain in `.env` and are never returned by `/api/status`.

Client-supplied idempotency keys map to one dispatch. Provider callbacks are deduplicated by provider identifier and state. Signed inbound STOP, STOPALL, UNSUBSCRIBE, CANCEL, END, and QUIT set the existing persistent suppression flag.

## Evidence levels

| Evidence | Meaning |
| --- | --- |
| `dry_run_accepted` | Local gates passed and a rehearsal record was stored. No carrier request occurred. |
| `provider_accepted` | The provider API returned an identifier. This is not delivery or connection. |
| `delivered` | A valid signed SMS status callback reported delivery. |
| `answered` | A valid signed call callback reported an in-progress answered call. |
| `completed` | A valid signed call callback reported completion. It does not by itself prove the user heard intelligible speech. |
| `provider_rejected` or `provider_failed` | Submission failed, or a signed callback reported a terminal failure. |
| inbound STOP verified | The user's handset reply reached the signed inbound webhook and persisted suppression. A locally signed test alone is not carrier evidence. |
| audible speech verified | The user confirms hearing the opening and at least one grounded response on the actual phone call. |

## Real-test sequence

1. Create or log in to the chosen provider account and verify only the user's own number.
2. Inspect the trial number and country permissions without copying credentials into chat or screenshots.
3. Expose the local app through a public HTTPS URL and set that exact origin as `PUBLIC_BASE_URL`.
4. Add credentials only to `.env`, restart, and confirm `/api/status` says the provider is configured without returning a secret.
5. Save the verified demo number through the local UI. Run a dry-run first.
6. Place one call. Record provider acceptance, ringing, answer, completion, and the user's confirmation that speech was audible and grounded.
7. Send one SMS only if the account permits the required content. Record provider acceptance and the signed delivery state separately.
8. Reply STOP from the same handset. Treat STOP as complete only if the signed inbound webhook persists suppression and a new dispatch is blocked.
9. Run an invalid-signature request and a provider-failure case without exposing credentials or the phone number.

## Official sources

- [Twilio trial account](https://www.twilio.com/docs/usage/trials)
- [Twilio trial restrictions and limitations](https://help.twilio.com/articles/360036052753)
- [Twilio India SMS guidelines](https://www.twilio.com/en-us/guidelines/in/sms)
- [Twilio India SMS limitations](https://help.twilio.com/hc/en-us/articles/223134167-Limitations-sending-SMS-messages-to-Indian-mobile-devices)
- [Twilio webhook security](https://www.twilio.com/docs/usage/security)
- [Twilio messaging webhooks](https://www.twilio.com/docs/usage/webhooks/messaging-webhooks)
- [Twilio voice webhooks](https://www.twilio.com/docs/usage/webhooks/voice-webhooks)
- [Twilio speech gathering](https://www.twilio.com/docs/voice/twiml/gather)
- [Exotel trial account](https://docs.exotel.com/business-phone-system/create-a-trial-account)
- [Exotel trial SMS](https://support.exotel.com/support/solutions/articles/3000112470-how-to-create-and-send-sms-on-your-exotel-trial-account-)
- [Exotel authentication and webhook security](https://developer.exotel.com/docs/references/authentication)
- [Exotel SMS API](https://developer.exotel.com/docs/sms-api/overview)
- [Exotel programmable voice](https://developer.exotel.com/docs/exoml/programmable-voice)
- [MSG91 voice trial limitation](https://msg91.com/help/voice/how-to-use-voice-services)
- [MSG91 demo-mode SMS and KYC](https://msg91.com/help/text-sms/my-account-status-is-in-demo-what-can-i-do-to-make-my-account-live/)
- [MSG91 delivery webhooks](https://msg91.com/help/webhook-new)
- [Plivo SMS availability](https://www.plivo.com/docs/messaging/sms-availability)
