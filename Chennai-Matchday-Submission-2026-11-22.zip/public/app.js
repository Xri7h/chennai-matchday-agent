const $ = id => document.getElementById(id);
const elt = (tag, value, css) => {
  const node = document.createElement(tag);
  if (value !== undefined) node.textContent = value;
  if (css) node.className = css;
  return node;
};
const fmt = n => Number.isFinite(n) ? n.toFixed(1) + ' ms' : '—';
const cacheFmt = (cached, total) => Number.isFinite(total) ? `${cached || 0}/${total}` : '—';
let catalog, rows = [], telecom, sessionId = crypto.randomUUID(), chatting = false, recording = false;
let selected = 'L057', recognition, recorder, recordingStream, recordingTimer, recordingContext, recordingFrame;
let recordingChunks = [], recordingPeak = 0, micReady = false, conversation = {}, timings = [], nextAgent = 'Chepauk box office', audioEpoch = 0;
let speechEpoch = 0, speechRequest, speechPending = false, microphoneOpening = false;
let nativeBase = '', nativeFinal = '', nativeError = false, nativeActive = false;
function warn(text = '') { $('notice').textContent = text; $('notice').hidden = !text; }
async function api(url, data) {
  const opts = data ? {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)} : {};
  const res = await fetch(url, opts);
  const out = await res.json();
  if (!res.ok) throw Error(out.error || 'Request failed.');
  return out;
}
function drawTurn(text, who = 'agent', author = who === 'agent' ? nextAgent : 'Fan') {
  const item = elt('div',undefined,'turn ' + who);
  item.append(elt('span',author,'byline'),elt('div',text,'bubble ' + who));
  $('transcript').append(item);
  $('transcript').scrollTop = $('transcript').scrollHeight;
  return item;
}
function details(target, pairs) {
  target.replaceChildren(...pairs.map(([name,value]) => {
    const line = elt('div'); line.append(elt('dt',name),elt('dd',value ?? '—')); return line;
  }));
}
function drawState() {
  const s = conversation;
  const match = catalog?.matches.find(m=>m.id===s.matchId);
  const seats = (s.seatIds || []).map(id=>catalog?.seat_areas.find(a=>a.id===id)?.name).filter(Boolean).join(', ');
  details($('context'),[['Fixture',match?.aliases[0]],['Group size',s.groupSize],['Seat area',seats || null],
    ['Budget',s.budgetInr != null ? '₹' + s.budgetInr.toLocaleString('en-IN') + (s.budgetBasis === 'each' ? ' each' : s.budgetBasis === 'total' ? ' total' : '') : null]]);
}
function drawAgentStatus(status) {
  const agent = status.agent;
  const badge = $('agent-status');
  badge.textContent = agent.configured ? 'Ticket assistant ready' : 'Local assistant ready';
  badge.dataset.provider = agent.configured ? 'cloud' : 'local';
  badge.title = agent.configured
    ? agent.model + ' with ' + (agent.fallback || 'local') + ' fallback'
    : agent.reason;
  $('agent-note').hidden = agent.configured;
}
function drawTurnProvider(provider) {
  const badge = $('agent-status');
  if (provider === 'groq') {
    badge.textContent = 'Ticket assistant ready';
    badge.dataset.provider = 'cloud';
  } else if (provider === 'gemini' || provider === 'gemini-fallback') {
    badge.textContent = provider === 'gemini-fallback' ? 'Assistant ready · backup connected' : 'Ticket assistant ready';
    badge.dataset.provider = 'cloud';
  } else if (provider === 'local-fallback') {
    badge.textContent = 'Local assistant ready';
    badge.dataset.provider = 'local';
    badge.title = 'The cloud provider was unavailable for the last turn; the bundled model recovered it.';
  }
}
function say(text, onstart) {
  if (!$('voice-mode').checked || !window.speechSynthesis) return;
  const epoch = ++audioEpoch;
  window.speechSynthesis.cancel();
  const speech = new SpeechSynthesisUtterance(text);
  speech.lang = 'en-IN';
  const voices = window.speechSynthesis.getVoices().filter(v=>/^en\b/i.test(v.lang));
  const voice = voices.find(v=>v.localService && v.lang === 'en-IN') || voices.find(v=>v.localService) || voices[0];
  if (voice) speech.voice = voice;
  speech.onstart = () => { if (epoch===audioEpoch) { $('speech-status').textContent='Playing reply…'; onstart?.(); } };
  speech.onend = () => { if (epoch===audioEpoch) $('speech-status').textContent=''; };
  speech.onerror = event => { if (epoch===audioEpoch && !['canceled','interrupted'].includes(event.error)) $('speech-status').textContent='Audio unavailable in this browser. The reply is in the chat.'; };
  window.speechSynthesis.speak(speech);
}
function resetChat(opening, newId = crypto.randomUUID()) {
  audioEpoch++; window.speechSynthesis?.cancel(); cancelMicrophone();
  sessionId = newId; conversation = {}; $('transcript').replaceChildren(); $('message').value='';
  $('speech-status').textContent=''; $('slow-mode').checked=false;
  drawTurn(opening || 'Which match are you coming to? Tell me how many seats you need and I’ll work out the price.');
  drawState();
}
function drawTimes() {
  const target = $('timings');
  target.replaceChildren();
  if (!timings.length) { target.append(elt('p','Your next conversation starts the clock. Send a message from the ticket desk to see response times here.','timings-empty')); return; }
  const table = elt('table',undefined,'metrics-table');
  const header=elt('tr');
  for(const key of ['Turn','Route','Model','Queue','Prompt','Cache','Logic','First text','First speech','Holding audio']) header.append(elt('th',key));
  table.append(header);
  for (const [i,m] of [...timings.entries()].reverse()) {
    const row=elt('tr');
    for (const v of [i+1,m.source,fmt(m.modelMs),fmt(m.queueMs),fmt(m.promptMs),cacheFmt(m.cachedTokens,m.promptTokens),fmt(m.logicMs),fmt(m.firstText),fmt(m.firstSpeech),fmt(m.holdingSpeech)]) row.append(elt('td',v));
    table.append(row);
  }
  target.append(table);
}
function busy(value) {
  chatting=value;
  document.querySelector('.chat-card').setAttribute('aria-busy',String(value));
  for(const id of ['new-chat','send','launch-outreach','mic','slow-mode','save-phone','dispatch-telecom']) $(id).disabled=value;
  $('mic').disabled=value || !micReady || speechPending || microphoneOpening;
  document.querySelectorAll('[data-prompt], .fixture-row, #compare-seats, #featured-match').forEach(b=>b.disabled=value);
  if (rows.length) drawLead();
}
async function send(message) {
  if (chatting || !message.trim()) return;
  cancelMicrophone(); warn(); $('message').value=''; drawTurn(message,'fan');
  const slow=$('slow-mode').checked; $('slow-mode').checked=false; busy(true);
  const t0=performance.now(); const metrics={};
  const waiting=setTimeout(()=>{
    $('speech-status').textContent='Checking the catalog…';
    say('One moment while I check.',()=>{ metrics.holdingSpeech=performance.now()-t0; });
  },550);
  try {
    const result=await api('/api/chat',{sessionId,message,scenario:slow?'slow':'normal'});
    clearTimeout(waiting); $('speech-status').textContent='';
    conversation=result.state; drawTurn(result.text); drawState(); drawTurnProvider(result.provider);
    Object.assign(metrics,{source:result.provider || result.source,modelMs:result.modelMs,logicMs:result.logicMs,firstText:performance.now()-t0,
      queueMs:result.providerMeta?.queueMs,promptMs:result.providerMeta?.promptMs,cachedTokens:result.providerMeta?.cachedTokens,promptTokens:result.providerMeta?.promptTokens});
    timings.push(metrics); drawTimes(); say(result.text,()=>{ metrics.firstSpeech=performance.now()-t0; drawTimes(); });
  } catch(e) {
    $('message').value=message; warn(e.message); $('speech-status').textContent='';
  } finally { clearTimeout(waiting); busy(false); $('message').focus(); }
}
function drawFixtures() {
  const first = catalog.matches[0];
  const firstDate = new Date(first.date + 'T12:00:00Z');
  const month = date => date.toLocaleString('en', {month:'long', timeZone:'UTC'});
  $('fixture-month').textContent = month(firstDate) + ' ' + firstDate.getUTCFullYear();

  const featured = $('featured-match');
  featured.append(elt('span', 'Explore CSK v ' + first.aliases[0]));
  featured.setAttribute('aria-label', 'Ask about seats for the season opener against ' + first.opponent);
  featured.hidden = false;
  const askAbout = fixture => {
    if (!chatting) send('What seats and prices are listed for ' + fixture.opponent + '?');
    $('message').scrollIntoView({block:'nearest'});
  };
  featured.onclick = () => askAbout(first);
  $('compare-seats').onclick = () => {
    const selectedMatch = catalog.matches.find(match => match.id === conversation.matchId) || first;
    send('Compare North Stand and East Stand for ' + selectedMatch.opponent + '.');
  };
  for (const fixture of catalog.matches) {
    const button = elt('button', undefined, 'fixture-row');
    const date = new Date(fixture.date + 'T12:00:00Z');
    const day = elt('time', date.toLocaleString('en-GB', { weekday:'short', day:'numeric', month:'short', timeZone:'UTC' }));
    day.dateTime = fixture.date;
    const crest = elt('span', fixture.aliases[0], 'club-mark');
    crest.setAttribute('aria-hidden','true');
    button.dataset.club = fixture.aliases[0];
    const info = elt('span', undefined, 'fixture-info');
    const when = elt('span', undefined, 'fixture-detail');
    when.append(day, document.createTextNode(' · ' + fixture.time + ' IST'));
    info.append(when, elt('strong', fixture.opponent));
    const prices = catalog.seat_areas
      .filter(seat => fixture.seat_areas_available.includes(seat.id))
      .map(seat => seat.price_inr_by_match[fixture.id]).filter(Number.isFinite);
    button.append(crest, info);
    if (prices.length) {
      const price = elt('span', 'from ', 'fixture-price');
      price.append(elt('b', '₹' + Math.min(...prices).toLocaleString('en-IN')));
      info.append(price);
    }
    const arrow = elt('span','↗','fixture-arrow');
    arrow.setAttribute('aria-hidden','true');
    button.append(arrow);
    button.title = 'Ask about ' + fixture.opponent + ' seats';
    button.onclick = () => askAbout(fixture);
    $('fixtures').append(button);
  }
}
const decision=s=>s.replaceAll('_',' ');
function decisionTag(row) {
  const tag = elt('span', decision(row.decision), 'tag');
  tag.dataset.decision = row.decision;
  return tag;
}
function drawLead() {
  const r=rows.find(r=>r.lead_id===selected);
  if (!r) { $('launch-outreach').disabled=true; return; }
  $('lead-select').value=selected;
  const title=elt('div',undefined,'lead-title'); title.append(elt('h2',r.name),decisionTag(r));
  const list=elt('dl');
  details(list,[['Lead score',String(r.score) + ' / 100'],['Channel',r.channel?.toUpperCase()],['Scheduled',r.scheduled_at?.replace('T',' ')],['Decision reason',r.reason]]);
  const detail=$('lead-detail'); detail.replaceChildren(title,list);
  if(r.first_message) detail.append(elt('p',r.first_message,'lead-copy'));
  if (r.channel) $('telecom-channel').value=r.channel;
  $('launch-outreach').disabled=chatting || r.decision!=='contact_now';
  document.querySelectorAll('[data-lead]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.lead===selected)));
  if (telecom?.profile.leadId === selected) drawTelecom();
}
function drawTelecom() {
  if (!telecom) return;
  const provider=telecom.provider;
  if(provider.channels && !provider.channels.includes($('telecom-channel').value))$('telecom-channel').value=provider.channels[0];
  $('self-test-call').hidden=!telecom.ownDemoPhoneConfigured;
  $('self-test-note').hidden=!telecom.ownDemoPhoneConfigured;
  $('telecom-provider').textContent=provider.label+' · '+provider.detail;
  $('telecom-provider').dataset.real=String(provider.real);
  const configured=telecom.profile.phoneConfigured;
  $('phone-note').textContent=configured
    ? 'A number is stored privately for this lead. Saving again replaces it; the API never returns it.'
    : 'Stored only in the ignored local runtime file. The API never returns the number.';
  const row=rows.find(r=>r.lead_id===selected);
  const channel=$('telecom-channel').value;
  const eligibility=telecom.eligibility?.[channel];
  const supported=!provider.channels || provider.channels.includes(channel);
  $('dispatch-telecom').disabled=chatting || !configured || !provider.configured || !supported || (eligibility ? !eligibility.allowed : row?.decision!=='contact_now');
  $('dispatch-telecom').title=!supported?'Live SMS is not configured.':eligibility && !eligibility.allowed?eligibility.reason:'';
  $('phone-note').textContent+=(provider.real && eligibility && !eligibility.allowed ? ' Calling blocked now: '+eligibility.reason : '');
  $('dispatch-telecom').textContent=provider.real ? (channel==='sms'?'Send real SMS':'Place real call') : 'Run '+channel.toUpperCase()+' dry-run';
  const log=$('telecom-log'); log.replaceChildren();
  for(const item of telecom.dispatches) {
    const line=elt('p'); line.append(elt('strong',item.channel.toUpperCase()+' · '+item.status.replaceAll('_',' ')),document.createTextNode(' · '+new Date(item.updatedAt).toLocaleString('en-IN',{timeZone:'Asia/Kolkata'})));
    log.append(line);
  }
}
async function loadTelecom() {
  const leadId=selected;
  const result=await api('/api/telecom?leadId='+encodeURIComponent(leadId));
  if(leadId!==selected)return;
  telecom=result; drawTelecom();
}
async function loadRows() {
  const clock=$('clock').value;
  $('reset-rehearsal').disabled=clock!=='campaign' || chatting;
  const result=await api('/api/leads?clock='+clock);
  if(clock!==$('clock').value) return;
  rows=result.rows;
  $('clock-label').textContent=new Intl.DateTimeFormat('en-IN',{dateStyle:'medium',timeStyle:'short',timeZone:'Asia/Kolkata'}).format(new Date(result.now))+' IST · '+(clock==='live'?'Current clock':'Fixed campaign example');
  $('lead-select').replaceChildren(); $('roster').replaceChildren();
  for (const r of rows) {
    const opt=elt('option',r.lead_id+' · '+r.name); opt.value=r.lead_id; $('lead-select').append(opt);
    const b=elt('button'); b.dataset.lead=r.lead_id;
    const name=elt('span',r.name); name.append(elt('small',r.lead_id));
    b.append(name,decisionTag(r)); b.onclick=()=>{selected=r.lead_id;drawLead();loadTelecom().catch(error=>warn(error.message));}; $('roster').append(b);
  }
  drawLead(); await loadTelecom();
}
async function tab(page) {
  for(const p of ['chat','outreach','run']) {
    $(p+'-view').hidden=p!==page;
    if (p===page) $('nav-'+p).setAttribute('aria-current','page'); else $('nav-'+p).removeAttribute('aria-current');
  }
  document.body.dataset.view = page;
  const title = $('page-title');
  if (page === 'chat') {
    title.replaceChildren(document.createTextNode('Make it a'), document.createElement('br'), document.createTextNode('Chepauk night.'));
  } else {
    title.textContent = page === 'outreach' ? 'Good fans. Great conversations.' : 'Every second counts.';
  }
  $('hero-label').textContent = page === 'chat' ? 'A little closer to the game.' : '';
  $('hero-sub').textContent = {chat:'Your team. Your people. Find your seats for the next home match.',outreach:'A considered approach to bringing repeat fans back to Chepauk.',run:'A closer look at how quickly your ticket assistant responds.'}[page];
  if(page==='outreach') try { await loadRows(); } catch(e) { warn(e.message); }
  if(page==='run') drawTimes();
}
function microphoneUi(active, status = '') {
  recording=active;
  $('mic').textContent=active ? 'Finish speaking' : 'Start speaking';
  $('mic').setAttribute('aria-pressed',String(active));
  if (status) $('speech-status').textContent=status;
}
function releaseRecording() {
  clearTimeout(recordingTimer); recordingTimer=undefined;
  cancelAnimationFrame(recordingFrame); recordingFrame=undefined;
  recordingContext?.close().catch(()=>{}); recordingContext=undefined;
  recordingStream?.getTracks().forEach(track=>track.stop()); recordingStream=undefined;
}
function cancelMicrophone() {
  speechEpoch++; speechRequest?.abort(); speechRequest=undefined; speechPending=false;
  nativeActive=false;
  recognition?.abort();
  if (recorder && recorder.state!=='inactive') {
    recorder.onstop=null;
    try { recorder.stop(); } catch { /* Already stopping. */ }
  }
  recorder=undefined; recordingChunks=[]; releaseRecording();
  microphoneUi(false);
  $('speech-method').disabled=false;
}
function audioBase64(blob) {
  return blob.arrayBuffer().then(buffer => {
    const bytes=new Uint8Array(buffer); let binary='';
    for(let offset=0;offset<bytes.length;offset+=0x8000) binary+=String.fromCharCode(...bytes.subarray(offset,offset+0x8000));
    return btoa(binary);
  });
}
function mediaType() {
  return ['audio/webm;codecs=opus','audio/webm','audio/ogg;codecs=opus','audio/mp4'].find(type=>MediaRecorder.isTypeSupported(type)) || '';
}
async function finishRecording() {
  const epoch=speechEpoch;
  const chunks=recordingChunks; const mimeType=recorder?.mimeType || chunks[0]?.type || 'audio/webm'; const peak=recordingPeak;
  recorder=undefined; recordingChunks=[]; releaseRecording(); microphoneUi(false);
  const blob=new Blob(chunks,{type:mimeType});
  $('speech-method').disabled=false;
  if(blob.size<64 || peak<0.002){$('speech-status').textContent='No audio detected. Check the F4 microphone-mute key, then try again.';return;}
  $('speech-status').textContent='Turning speech into text…'; $('mic').disabled=true; speechPending=true;
  const started=performance.now(); speechRequest=new AbortController();
  const deadline=setTimeout(()=>speechRequest?.abort(),12_000);
  try {
    const res=await fetch('/api/transcribe',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({audioBase64:await audioBase64(blob),mimeType}),signal:speechRequest.signal});
    const result=await res.json(); if(!res.ok)throw Error(result.error || 'Transcription failed.');
    if(epoch!==speechEpoch)return;
    $('message').value=result.text;
    $('speech-status').textContent=`Ready · transcription ${((performance.now()-started)/1000).toFixed(1)}s. Check the words, then Send.`;
    $('message').focus();
  } catch(error) {
    if(epoch===speechEpoch)$('speech-status').textContent=error.name==='AbortError'?'Transcription took too long. Try Live captions or type your message.':error.message+' Try again or type your message.';
  } finally { clearTimeout(deadline); if(epoch===speechEpoch){speechPending=false;speechRequest=undefined;$('mic').disabled=chatting || !micReady;} }
}
async function startRecording() {
  const epoch=++speechEpoch; microphoneOpening=true; $('mic').disabled=true;
  window.speechSynthesis?.cancel();
  $('speech-status').textContent='Opening the microphone…';
  try {
    const stream=await navigator.mediaDevices.getUserMedia({audio:{channelCount:1,echoCancellation:true,noiseSuppression:true,autoGainControl:true}});
    if(epoch!==speechEpoch){stream.getTracks().forEach(track=>track.stop());return;}
    recordingStream=stream;
    recordingChunks=[]; recordingPeak=0;
    const type=mediaType(); recorder=new MediaRecorder(recordingStream,type?{mimeType:type}:undefined);
    recorder.ondataavailable=event=>{if(event.data.size)recordingChunks.push(event.data);};
    recorder.onerror=()=>{$('speech-status').textContent='The microphone recorder failed. Please retry.';cancelMicrophone();};
    recorder.onstop=finishRecording;
    const AudioEngine=window.AudioContext || window.webkitAudioContext;
    if(AudioEngine){
      recordingContext=new AudioEngine(); await recordingContext.resume();
      const analyser=recordingContext.createAnalyser(); analyser.fftSize=1024;
      recordingContext.createMediaStreamSource(recordingStream).connect(analyser);
      const samples=new Float32Array(analyser.fftSize); let lastPaint=0, lastVoice=performance.now(), heardVoice=false, started=performance.now();
      const meter=now=>{
        analyser.getFloatTimeDomainData(samples); let sum=0;
        for(const value of samples)sum+=value*value;
        const rms=Math.sqrt(sum/samples.length); recordingPeak=Math.max(recordingPeak,rms);
        if(rms>0.008){heardVoice=true;lastVoice=now;}
        if(heardVoice && now-lastVoice>900 && now-started>1200 && recorder?.state==='recording'){recorder.stop();return;}
        if(now-lastPaint>180){$('speech-status').textContent=`Listening · input ${Math.min(100,Math.round(rms*500))}% · pauses finish the recording.`;lastPaint=now;}
        recordingFrame=requestAnimationFrame(meter);
      };
      recordingFrame=requestAnimationFrame(meter);
    }
    recorder.start(100); microphoneUi(true,'Listening… speak normally. Pause to finish.'); $('speech-method').disabled=true;
    recordingTimer=setTimeout(()=>{if(recorder?.state==='recording')recorder.stop();},15_000);
  } catch(error) {
    if(epoch!==speechEpoch)return;
    releaseRecording(); microphoneUi(false);
    $('speech-status').textContent=error.name==='NotAllowedError'
      ? 'Microphone permission was denied. Allow it in the browser site controls.'
      : 'The microphone could not start. Check the selected input device and retry.';
  } finally { microphoneOpening=false; $('mic').disabled=chatting || !micReady || speechPending; }
}
function initNativeRecognition() {
  const Recognizer=window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!Recognizer) return false;
  recognition=new Recognizer(); recognition.lang='en-IN'; recognition.continuous=false; recognition.interimResults=true;
  recognition.onstart=()=>{if(!nativeActive)return;microphoneOpening=false;$('mic').disabled=false;microphoneUi(true,'Listening… words appear here as you speak.');$('speech-method').disabled=true;};
  recognition.onend=()=>{
    if(!nativeActive)return; nativeActive=false;
    microphoneOpening=false; microphoneUi(false); $('speech-method').disabled=false; $('mic').disabled=chatting || !micReady;
    if(!nativeError)$('speech-status').textContent=$('message').value.trim()?'Ready. Check the words, then Send.':'No speech heard. Check the F4 microphone-mute key and try again.';
  };
  recognition.onresult=e=>{
    if(!nativeActive)return;
    let final='',interim='';
    for(let i=0;i<e.results.length;i++){const words=e.results[i][0].transcript;if(e.results[i].isFinal)final+=words+' ';else interim+=words;}
    nativeFinal=final.trim(); $('message').value=[nativeBase,nativeFinal,interim.trim()].filter(Boolean).join(' ');
    $('speech-status').textContent=interim?'Hearing you…':'Ready. Finish speaking or press Send.';
  };
  recognition.onerror=e=>{
    if(!nativeActive)return;
    nativeError=true;
    if(e.error==='aborted')return;
    $('speech-status').textContent=e.error==='no-speech'?'No speech heard. Check the F4 microphone-mute key, then retry.':e.error==='network'?'Live captions could not connect. Choose Record & transcribe above.':`Microphone ${e.error}. Try again or choose Record & transcribe.`;
  };
  return true;
}
function speechMethodChanged() {
  cancelMicrophone();
  const backup=$('speech-method').value==='record';
  $('speech-note').textContent=backup?'Speak, then pause to finish automatically. Audio is sent to Groq for transcription; this app does not save it.':'Speak and watch your words appear. Pause or click Finish speaking, then Send. Audio is processed by your browser’s speech service.';
  $('speech-note').hidden=false; $('speech-status').textContent='';
}
function initVoice(speechInput = {}) {
  $('voice-mode').disabled=!window.speechSynthesis;
  const canRecord=Boolean(speechInput.configured && navigator.mediaDevices?.getUserMedia && window.MediaRecorder);
  const canLive=initNativeRecognition(); micReady=canLive || canRecord;
  $('speech-method').querySelector('[value="record"]').disabled=!canRecord;
  $('speech-method').querySelector('[value="live"]').disabled=!canLive;
  $('speech-method').value=canLive?'live':'record';
  $('speech-method').onchange=speechMethodChanged; speechMethodChanged();
  $('mic').onclick=()=>{
    if(speechPending || microphoneOpening)return;
    if($('speech-method').value==='record'){if(recording)recorder?.stop();else startRecording();return;}
    if(recording){recognition.stop();return;}
    window.speechSynthesis?.cancel(); nativeBase=$('message').value.trim();nativeFinal='';nativeError=false;nativeActive=true;
    microphoneOpening=true;$('mic').disabled=true;$('speech-status').textContent='Starting microphone…';
    try{recognition.start();}catch{nativeActive=false;microphoneOpening=false;$('mic').disabled=false;$('speech-status').textContent='Microphone is still stopping. Try again in a moment.';}
  };
  if(!micReady){$('mic').disabled=true;$('mic').title='Speech input is unavailable in this browser.';}
}
$('chat-form').onsubmit=e=>{e.preventDefault();send($('message').value);};
$('message').onkeydown=e=>{if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing){e.preventDefault();send($('message').value);}};
$('new-chat').onclick=()=>resetChat();
for(const p of ['chat','outreach','run']) $('nav-'+p).onclick=()=>tab(p);
$('lead-select').onchange=e=>{selected=e.target.value;drawLead();loadTelecom().catch(error=>warn(error.message));};
$('clock').onchange=()=>loadRows().catch(e=>warn(e.message));
$('reset-rehearsal').onclick=async()=>{
  const button=$('reset-rehearsal');button.disabled=true;
  try{
    const result=await api('/api/outreach/reset-rehearsal',{clock:$('clock').value});
    $('rehearsal-status').textContent=result.detail;
    await loadRows();
  }catch(error){$('rehearsal-status').textContent=error.message;}
  finally{button.disabled=$('clock').value!=='campaign' || chatting;}
};
$('launch-outreach').onclick=async()=>{
  if(chatting)return;
  $('launch-outreach').disabled=true; warn();
  try {const r=await api('/api/outreach',{leadId:selected,clock:$('clock').value}); await tab('chat'); resetChat(r.text,r.sessionId); say(r.text);}
  catch(e){warn(e.message);await loadRows();}
};
$('telecom-channel').onchange=()=>drawTelecom();
$('self-test-call').onclick=async()=>{
  if(!telecom?.ownDemoPhoneConfigured)return;
  if(!window.confirm('Place one real Exotel test call to your own saved verified demo phone? This uses trial credits and connects to the voice agent.'))return;
  $('self-test-call').disabled=true;
  try{
    const result=await api('/api/telecom/self-test',{confirmed:true,idempotencyKey:crypto.randomUUID()});
    $('telecom-status').textContent=result.dispatch.status==='provider_accepted'?'Test call requested. Answer your demo phone to speak to the agent. Connection is confirmed when you answer.':'Test call: '+result.dispatch.status.replaceAll('_',' ')+'.';
  }catch(error){$('telecom-status').textContent=error.message;}
  finally{$('self-test-call').disabled=false;}
};
$('exotel-setup-form').onsubmit=async event=>{
  event.preventDefault();
  const button=event.submitter;button.disabled=true;
  try{
    telecom=await api('/api/telecom/exotel-setup',{
      accountSid:$('exotel-account').value.trim(),apiKey:$('exotel-key').value.trim(),apiToken:$('exotel-token').value.trim(),
      callerId:$('exotel-caller').value.trim(),flowId:$('exotel-flow').value.trim(),region:$('exotel-region').value,
      demoPhone:$('exotel-demo-phone').value.trim(),leadId:selected,
    });
    event.target.reset();$('exotel-setup').open=false;$('telecom-channel').value='voice';
    $('telecom-status').textContent='Exotel connected. No call has been placed.';drawTelecom();
  }catch(error){$('telecom-status').textContent=error.message;}
  finally{button.disabled=false;}
};
$('save-phone').onclick=async()=>{
  if(chatting)return;
  const phone=$('demo-phone').value.trim();
  $('save-phone').disabled=true; $('telecom-status').textContent='';
  try {
    telecom=await api('/api/telecom/profile',{leadId:selected,phoneE164:phone});
    $('demo-phone').value=''; $('telecom-status').textContent='Demo number saved privately.'; drawTelecom();
  } catch(error) { $('telecom-status').textContent=error.message; }
  finally { $('save-phone').disabled=false; }
};
$('dispatch-telecom').onclick=async()=>{
  if(chatting||!telecom)return;
  const channel=$('telecom-channel').value;
  if(telecom.provider.real&&!window.confirm(`This will ${channel==='sms'?'send a real SMS':'place a real call'} to the privately stored verified number. Continue?`))return;
  $('dispatch-telecom').disabled=true; $('telecom-status').textContent=telecom.provider.real?'Submitting to the provider…':'Recording a dry-run…';
  try {
    const result=await api('/api/telecom/dispatch',{leadId:selected,channel,clock:$('clock').value,idempotencyKey:crypto.randomUUID()});
    $('telecom-status').textContent=result.dispatch.status.replaceAll('_',' ')+'.';
    await Promise.all([loadTelecom(),loadRows()]);
  } catch(error) { $('telecom-status').textContent=error.message; await loadTelecom().catch(()=>{}); }
  finally { drawTelecom(); }
};
$('voice-mode').onchange=()=>{if(!$('voice-mode').checked){audioEpoch++;window.speechSynthesis?.cancel();$('speech-status').textContent='';}};
const archive = [
  {
    file: 'dhoni-archive.webp', title: 'Dhoni in yellow',
    caption: 'MS Dhoni in his Chennai Super Kings jersey. The Times of India published this frame in its January 2020 sports roundup.',
    alt: 'MS Dhoni smiles and shakes hands in a yellow Chennai Super Kings jersey.',
    credit: 'B A Raju / Times of India',
    source: 'https://commons.wikimedia.org/wiki/File:MS_Dhoni_(late_2010s).jpg',
    license: 'CC BY 3.0', licenseUrl: 'https://creativecommons.org/licenses/by/3.0/',
  },
  {
    file: 'dhoni-keeping.webp', title: 'Behind the stumps',
    caption: 'Dhoni keeping wicket for India on day two of the second Test of the 2010–11 Border–Gavaskar Trophy.',
    alt: 'MS Dhoni in Test whites, crouched with his gloves open behind the stumps.',
    credit: 'Pulkitsinha', source: 'https://commons.wikimedia.org/wiki/File:Dhoni_behind_Stumps.jpg',
    license: 'CC BY-SA 2.0', licenseUrl: 'https://creativecommons.org/licenses/by-sa/2.0/',
  },
];
let archiveIndex = 0;
let archiveRequest = 0;
async function showArchivePhoto(index) {
  archiveIndex = index;
  const request = ++archiveRequest;
  const photo = archive[index];
  const frame = new Image();
  frame.id = 'archive-image';
  frame.alt = photo.alt;
  frame.src = '/assets/' + photo.file;
  try {
    await frame.decode();
  } catch {
    frame.alt = 'Photograph unavailable. ' + photo.alt;
  }
  // Switch frame and caption together, even if the fan clicks ahead rapidly.
  if (request !== archiveRequest) return;
  $('archive-image').replaceWith(frame);
  $('archive-title').textContent = photo.title;
  $('archive-caption').textContent = photo.caption;
  $('archive-index').textContent = 'PHOTOGRAPH ' + (index + 1) + ' / ' + archive.length;
  $('archive-source').textContent = photo.credit;
  $('archive-source').href = photo.source;
  $('archive-license').textContent = photo.license;
  $('archive-license').href = photo.licenseUrl;
}
$('open-archive').onclick = () => {
  showArchivePhoto(0);
  $('archive-dialog').showModal();
};
$('close-archive').onclick = () => $('archive-dialog').close();
$('next-archive').onclick = () => showArchivePhoto((archiveIndex + 1) % archive.length);
document.querySelectorAll('[data-prompt]').forEach(b=>b.onclick=()=>send(b.dataset.prompt));
try {
  const [catalogResult,status] = await Promise.all([api('/api/catalog'),api('/api/status')]);
  catalog=catalogResult; drawAgentStatus(status); drawFixtures(); initVoice(status.speechInput); resetChat();
}
catch(e) { warn('Could not open the ticket desk. '+e.message); }
