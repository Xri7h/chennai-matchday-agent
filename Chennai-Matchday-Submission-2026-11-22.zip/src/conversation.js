// The model proposes a query. Only catalog lookups and arithmetic supply ticket facts.
const intents = new Set(['fixtures', 'quote', 'compare', 'faq', 'unknown', 'clarify', 'decline', 'optout', 'handoff', 'greet']);
const counts = { one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10, eleven: 11, twelve: 12, dozen: 12, couple: 2, pair: 2 };
const countPattern = '(\\d{1,3}|' + Object.keys(counts).join('|') + ')';
const moneyFormat = new Intl.NumberFormat('en-IN', { maximumFractionDigits: 2 });
const dateFormat = new Intl.DateTimeFormat('en-GB', { timeZone: 'UTC', day: 'numeric', month: 'short', year: 'numeric' });
const handoff = 'I can offer a handoff to a human ticket representative.';
const rupees = number => '₹' + moneyFormat.format(number);
const dateOf = match => dateFormat.format(new Date(match.date + 'T00:00:00Z'));
const normalize = text => String(text).toLowerCase().normalize('NFKC').replace(/[’']/g, '').replace(/[-–—]/g, ' ').replace(/\s+/g, ' ').trim();
const escape = text => text.replace(/[.*+?^$(){}|[\]\\]/g, '\\$&');
const phrase = (text, term) => new RegExp('(?:^|\\W)' + escape(normalize(term)) + '(?=\\W|$)').test(text);
const matchById = (catalog, id) => catalog.matches.find(match => match.id === id);
const seatById = (catalog, id) => catalog.seat_areas.find(seat => seat.id === id);
const homeNames = catalog => [catalog.team, ...(catalog.team_aliases || [])];

function references(text, records, label) {
  const mentions = records.map(record => {
    const terms = [record.id, record[label], ...(record.aliases || [])];
    const offsets = terms.map(term => text.search(new RegExp('(?:^|\\W)' + escape(normalize(term)) + '(?=\\W|$)'))).filter(i => i >= 0);
    return { record, first: offsets.length ? Math.min(...offsets) : Infinity };
  });
  return mentions.filter(ref => Number.isFinite(ref.first)).sort((a, b) => a.first - b.first).map(ref => ref.record.id);
}

function numericCount(text, catalog) {
  const count = token => Number(counts[token] ?? token);
  if (/\b(?:on my own|just me|by myself|going solo)\b/.test(text)) return 1;
  const guests = text.match(new RegExp('\\b(?:me (?:and|plus)|myself and) ' + countPattern + ' (?:friends?|guests?|others?)\\b'));
  if (guests) return count(guests[1]) + 1;
  // A quantity can be followed by either an area or an opponent before the
  // ticket noun ("three East Stand tickets", "three RCB tickets"). Mask all
  // catalog entities so the same count grammar handles both forms.
  const names = [
    ...catalog.seat_areas.flatMap(s => [s.name, ...(s.aliases || [])]),
    ...catalog.matches.flatMap(m => [m.opponent, ...(m.aliases || [])]),
    ...homeNames(catalog)
  ].sort((a, b) => b.length - a.length).map(name => escape(normalize(name)));
  const withoutSeatNames = text.replace(new RegExp('\\b(?:' + names.join('|') + ')\\s+', 'g'), '');
  for (const pattern of [
    new RegExp('\\b' + countPattern + '\\s+(?:tickets?|seats?|people|persons?|adults?|fans?|of us)\\b', 'g'),
    new RegExp('\\b(?:group of|party of|family of|there are|we are|we were|were now|there will be|make (?:that|it)|change (?:that|it) to|we will be|we will need|tickets for|seats for)\\s+' + countPattern + '\\b(?!\\s*(?:k\\b|thousand|hundred|rupees|each))', 'g'),
    new RegExp('^(?:id (?:like|take) |i(?:ll| will) take |can (?:i|we) get )?' + countPattern + '\\s+for\\s+\\w', 'g'),
    new RegExp('\\bfor (?:the )?' + countPattern + '(?: (?:please|of us))?[!.?]*$', 'g')
  ]) {
    const matches = [...withoutSeatNames.matchAll(pattern)];
    if (matches.length) return count(matches.at(-1)[1]);
  }
  if (/^(?:for )?(?:a )?(?:couple|pair)(?: please)?[.!]?$/.test(text)) return 2;
  return undefined;
}

function money(text) {
  const value = '(\\d+(?:,\\d+)*(?:\\.\\d+)?)\\s*(k\\b|thousand\\b)?';
  const candidates = [];
  for (const pattern of [
    new RegExp('(?:₹|\\brs\\.?\\s*|\\binr\\s*)\\s*' + value, 'g'),
    new RegExp('\\b(?:budget(?:\\s+(?:is|of|to|at))?|under|within|up to|at most|no more than|below|spend|afford|cap(?:ped)? at|less than)\\s+(?:₹|rs\\.?\\s*|inr\\s*)?' + value, 'g'),
    new RegExp('\\b' + value + '\\s*(?:rupees|inr|bucks|each|per (?:head|seat|ticket|person)|total|altogether|all in)\\b', 'g'),
    new RegExp('\\b(\\d+(?:\\.\\d+)?)\\s*(k\\b|thousand\\b)', 'g')
  ]) {
    for (const m of text.matchAll(pattern)) candidates.push({ index: m.index + m[0].length, amount: Number(m[1].replaceAll(',', '')) * (m[2] ? 1000 : 1) });
  }
  return candidates.sort((a, b) => b.index - a.index)[0]?.amount;
}

function findFaq(text, catalog) {
  const normalizedQuestion = text.replace(/[?!.]+$/g, '');
  return catalog.faq.filter(f => normalize(f.question).replace(/[?!.]+$/g, '') === normalizedQuestion || f.keywords?.some(term => phrase(text, term)));
}

function dateReferences(text, catalog) {
  return catalog.matches.filter(match => {
    const day = Number(match.date.slice(-2));
    const month = dateOf(match).split(' ')[1].toLowerCase();
    return phrase(text, match.date) || new RegExp('\\b(?:' + month + '\\w* ' + day + '(?:st|nd|rd|th)?|' + day + '(?:st|nd|rd|th)? ' + month + '\\w*)(?: \\d{4})?\\b').test(text);
  }).map(match => match.id);
}

function fixtureMismatch(text, catalog) {
  const fixtureScoped = /\b(?:tickets?|prices?|pricing|cost|fixture|match|game|seats?|stands?|vs\.?|versus|against)\b/.test(text)
    || references(text, catalog.matches, 'opponent').length > 0;
  if (!fixtureScoped) return undefined;

  const catalogYears = new Set(catalog.matches.map(match => match.date.slice(0, 4)));
  const explicitDate = /\b\d{4}-\d{2}-\d{2}\b|\b(?:jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\s+\d{1,2}(?:st|nd|rd|th)?(?:\s+\d{4})?\b|\b\d{1,2}(?:st|nd|rd|th)?\s+(?:jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)(?:\s+\d{4})?\b/.test(text);
  const seasonYears = [...text.matchAll(/\b(?:season|year|in|for)\s+(20\d{2})\b|\b(20\d{2})\s+(?:season|year)\b/g)].map(match => match[1] || match[2]);
  const datedYears = explicitDate ? [...text.matchAll(/\b(20\d{2})\b/g)].map(match => match[1]) : [];
  if ([...seasonYears, ...datedYears].some(year => !catalogYears.has(year))) return 'that season or fixture or its ticket prices';

  const mentionedMatches = references(text, catalog.matches, 'opponent');
  const mentionedDates = dateReferences(text, catalog);
  if (explicitDate && !mentionedDates.length) return 'that date or fixture or its ticket prices';
  if (explicitDate && mentionedMatches.length && (mentionedMatches.some(id => !mentionedDates.includes(id)) || mentionedDates.some(id => !mentionedMatches.includes(id)))) {
    return 'that date and opponent combination or its ticket prices';
  }

  if (/\b(?:semi ?finals?|quarter ?finals?|playoffs?|eliminator|qualifiers?)\b|\b(?:ipl|tournament|season)\s+final\b|\bfinal\s+(?:match|game)\b/.test(text)) {
    return 'that competition stage or its ticket prices';
  }

  const venue = text.match(/\bat\s+(?:the\s+)?([a-z][a-z .]+?(?:stadium|ground|arena))\b/);
  if (venue) {
    const namedVenue = venue[1].trim();
    const genericVenue = /^(?:stadium|ground|arena)$/.test(namedVenue);
    if (!genericVenue && !/\b(?:chepauk|chidambaram)\b/.test(namedVenue)) return 'that venue or fixture or its ticket prices';
  }

  const matchup = /\b(?:vs\.?|versus|against)\b/g;
  for (const token of text.matchAll(matchup)) {
    const left = text.slice(Math.max(0, token.index - 90), token.index);
    const right = text.slice(token.index + token[0].length, Math.min(text.length, token.index + token[0].length + 90));
    const leftHome = homeNames(catalog).some(name => phrase(left, name));
    const rightHome = homeNames(catalog).some(name => phrase(right, name));
    const leftOpponents = references(left, catalog.matches, 'opponent');
    const rightOpponents = references(right, catalog.matches, 'opponent');

    if (leftHome) {
      if (!rightOpponents.length) return 'that fixture or its ticket prices';
      continue;
    }
    if (rightHome || leftOpponents.length) return 'that away or unlisted fixture or its ticket prices';
    if (!rightOpponents.length) return 'that fixture or its ticket prices';

    let leftCandidate = left.split(/[?;]|\b(?:and|or|but)\b/).at(-1) || '';
    for (const seat of catalog.seat_areas) {
      for (const name of [seat.name, ...(seat.aliases || [])].sort((a, b) => b.length - a.length)) {
        leftCandidate = leftCandidate.replace(new RegExp('\\b' + escape(normalize(name)) + '\\b', 'g'), ' ');
      }
    }
    leftCandidate = leftCandidate.replace(/\b(?:what|which|when|where|how|much|many|is|are|was|were|do|does|did|can|could|would|will|please|tell|show|give|compare|comparison|the|a|an|of|for|to|from|on|at|in|with|ticket|tickets|seat|seats|stand|stands|price|prices|pricing|cost|each|total|match|game|fixture|home|away|people|persons?|fans?|one|two|three|four|five|six|seven|eight|nine|ten|\d+)\b|[^a-z]+/g, ' ').trim();
    if (leftCandidate) return 'that fixture or its ticket prices';
  }
  return undefined;
}

function unlistedSelection(text, catalog) {
  // Mask recognized names before inspecting noun phrases for an unlisted
  // opponent or area. Never substitute yesterday's selection for an unknown one.
  let masked = text;
  const names = [...homeNames(catalog), ...catalog.matches.flatMap(m => [m.id, m.opponent, ...m.aliases]), ...catalog.seat_areas.flatMap(s => [s.id, s.name, ...s.aliases])];
  for (const name of names.sort((a, b) => b.length - a.length)) masked = masked.replace(new RegExp('\\b' + escape(normalize(name)) + '\\b', 'g'), ' entity ');
  if (/\b(?:deck|terrace|bleachers?|skybox|balcony|diamond|platinum|vip|hospitality box)\b/.test(masked)) return true;
  const teamAfter = masked.match(/\b(?:tickets?|seats?|game|match|fixture)\s+(?:for|against|versus)\s+(?:the\s+)?([a-z][a-z ]*)/);
  const beforeTicket = masked.match(/\b(?:how much (?:are|is)|what (?:do|does|is|are)|price (?:of|for)|cost (?:of|for)|quote|how much (?:would|will))\s+([a-z0-9 ]+?)\s+tickets?\b/);
  const area = masked.match(/\b(?:the|a|an|in|for|from|compare)\s+([a-z]+(?: [a-z]+)?)\s+(?:stand|seating area|section|enclosure|lounge)\b/);
  const filler = /^(?:a|an|the|all|of|my|us|me|our|them|this|that|your|some|any|these|those|same|please|people|family|everyone|match|game|home|seats?|stands?|tickets?|options?|available|cheap|adult|adults|entry|group|total|single|cheapest|best|each|another|next|entity|versus|vs|against|\d+)$|^(?:one|two|three|four|five|six|seven|eight|nine|ten|both|couple|pair)$/;
  for (const capture of [teamAfter?.[1], beforeTicket?.[1], area?.[1]]) {
    if (!capture) continue;
    const candidate = capture.trim().split(/\s+(?:and|or|but|with|in|that|at|under|within|below|up to|at most|if|instead|for|cost|budget|please)\b/)[0].trim();
    if (/^(?:my|our|the whole|a group|a party)\s/.test(candidate)) continue;
    if (candidate.split(/\s+/).some(word => !filler.test(word))) return true;
  }
  return false;
}

function isPriceCheck(text) {
  const asksForBudget = /\b(?:budget|under|afford|spend|at most|within|up to|cap)\b/.test(text);
  return !asksForBudget && /^(?:so |wait[, ]+)?(?:is|are|does|do|did|isnt|arent|costs?|confirm)\b/.test(text) && /(?:₹|rs\.?\s*\d|inr|\d\s*(?:rupees|each))/.test(text);
}

function asksForPrice(text) {
  return /\b(?:how much|tickets? cost|cost of|prices?|pricing|what does .+ cost|costs?|cheapest|lowest pric(?:e|ed)|least expensive|most affordable|budget|can .+ afford|what .+ get for|affordable|most expensive|pricey|quote|which (?:seats|areas)|what (?:seats|areas)|seat (?:areas|options)|seat types|seating options|what are my options|what are the options|fits? (?:my|our))\b/.test(text);
}

function requestedRankCount(text) {
  const match = text.match(new RegExp('\\b' + countPattern + '\\s+(?:cheapest|least expensive|most affordable|lowest pric(?:e|ed))\\s+(?:stands?|seats?|areas?|options?)\\b'));
  return match ? Number(counts[match[1]] ?? match[1]) : undefined;
}

function unpublishedTopic(text) {
  const topics = [
    [/\b(?:park(?:ing)?|car park|valet)\b/, 'parking arrangements'],
    [/\b(?:refund\w*|cancel(?:lation|led|ling)?|rain(?:ed)? out|money back|reimburse\w*)\b/, 'refund and cancellation terms'],
    [/\b(?:wheelchair|accessib\w*|disab\w*|step free|lift|mobility|ramp|hearing loop)\b/, 'accessibility arrangements'],
    [/\b(?:views?|sightlines?|obstruct\w*|visibil\w*|see the (?:pitch|boundary|players)|behind the bowler)\b/, 'seat views'],
    [/\b(?:adjacent|adjoining|consecutive|next to each other|sit together|seats together|side by side|sold out|tickets left|seats left|live availability|guarantee\w*|left in stock|how many (?:are )?left)\b/, 'live inventory or adjoining seats'],
    [/\b(?:discount\w*|coupons?|promos?|voucher|offers|freebies|cashback|loyalty perks?|member rates?)\b/, 'discounts or offers'],
    [/\b(?:pay(?:ment|tm)?|upi|purchase link|booking link|checkout link|check (?:me|us) out|proceed to checkout|book (?:it|them|these|this|the|my|me)|buy (?:it|them|these|the tickets)|reserve (?:it|them|these|the|my)|hold (?:them|these|the seats)|charge my|send (?:me )?(?:a |the )?link)\b/, 'booking links or payment processing'],
    [/\b(?:weather|forecast|rain|raining|temperature|winning|winner|prediction|toss|who will win|playing xi|scoreboard|pickpockets|betting|odds|pitch report|will .+ play|lineup|line up|captain)\b/, 'that match-day information'],
    [/\b(?:shade|shaded|roof|covered|buffet|catering|complimentary|wifi|wi fi|alcohol|water bottle|luggage|restrooms?|washrooms?|toilets?|metro|resell|transfer|taxes|convenience fee|service fees?|gst|fireworks|autograph|merchandise|vegetarian)\b/, 'that amenity or policy']
  ];
  const found = [...new Set(topics.filter(([pattern]) => pattern.test(text)).map(([, label]) => label))];
  if (!found.length) return undefined;
  if (found.length === 1) return found[0];
  return found.slice(0, -1).join(', ') + ' or ' + found.at(-1);
}

function collect(text, state, catalog) {
  // In corrections, preserve only the replacement. A comparison keeps both entities.
  const desired = text.split(/\b(?:instead of|rather than)\b/)[0].replace(/\b(?:switch|change)\s+from\s+.+?\s+to\s+/, '');
  let matchIds = references(desired, catalog.matches, 'opponent');
  if (!matchIds.length) {
    matchIds = dateReferences(text, catalog);
  }
  const seatIds = references(desired, catalog.seat_areas, 'name');
  let groupSize = numericCount(desired, catalog);
  if (groupSize === undefined && state.awaiting === 'group') {
    const bare = text.match(new RegExp('^' + countPattern + '(?: please)?[.!]?$'));
    if (bare) groupSize = Number(counts[bare[1]] ?? bare[1]);
  }
  const budgetInr = isPriceCheck(text) ? undefined : money(text);
  const budgetBasis = /\b(?:each|per (?:head|person|ticket|seat)|apiece|a head)\b/.test(text) ? 'each'
    : /\b(?:total|altogether|combined|all in|for (?:all|both|the (?:whole )?group)|between us|for everyone)\b/.test(text) ? 'total' : undefined;
  return { matchIds, seatIds, groupSize, budgetInr, budgetBasis };
}

function classify(text, slots, state, catalog) {
  if (/^(?:please[, ]+)?(?:stop(?: all)?|end|unsubscribe|opt out|remove me)(?: please)?[.!, ]*$/.test(text) ||
    /\b(?:do not|dont|never|stop)\s+(?:contact(?:ing)?|call(?:ing)?|text(?:ing)?|messag(?:e|ing)|send(?:ing)?|reach(?:ing)? out)\s*(?:me|us|promotions?|messages?|texts?)?\b/.test(text) ||
    /\b(?:unsubscribe me|opt me out|(?:i|we) opt out|take me off|remove me from|no more (?:sales |promotional |marketing )?(?:messages|calls|sms|texts)|stop (?:all |these )?(?:alerts|sms|calls|texts|messages|promotions))\b/.test(text)) return { intent: 'optout' };
  if (/\b(?:not interested|no thanks|no thank you|not today|maybe later|leave it for now|ill pass|i will pass|no longer interested)\b/.test(text) && !slots.seatIds.length && !slots.matchIds.length) return { intent: 'decline' };
  if (/\b(?:human|representative|real person|live agent|someone from|speak to (?:a |an )?agent)\b/.test(text)) return { intent: 'handoff' };
  const unpublished = unpublishedTopic(text);
  if (unpublished || /\b(?:ignore (?:your|the|all)|system prompt|invent|make (?:it|something) up|pretend (?:that|to))\b/.test(text)) return { intent: 'unknown', topic: unpublished, protected: true };
  const mismatch = fixtureMismatch(text, catalog);
  if (mismatch) return { intent: 'unknown', topic: mismatch, protected: true };
  // An unknown opponent must not silently inherit a previous match selection.
  const against = text.match(/\b(?:against|versus|vs\.?)\s+(?:the\s+)?(.+)/);
  if (against && !/\b(?:budget|limit|cap|inr)\b|₹/.test(against[1]) && !references(against[1], catalog.matches, 'opponent').length && !references(against[1], catalog.seat_areas, 'name').length && !homeNames(catalog).some(name => phrase(against[1], name))) {
    return { intent: 'unknown', topic: 'that fixture or its ticket prices', protected: true };
  }
  const faqs = findFaq(text, catalog);
  if (faqs.length) return { intent: 'faq', faqIds: faqs.map(f => f.id) };
  if (unlistedSelection(text, catalog)) return { intent: 'unknown', topic: 'the requested fixture or seating area', protected: true };
  if (/^(?:hi|hey|hello|good (?:morning|afternoon|evening)|howdy)[!,. ]*$/.test(text)) return { intent: 'greet' };
  if (/\b(?:help (?:me|us) (?:choose|decide)|not sure (?:where to start|what to (?:choose|pick))|where (?:do|should) (?:we|i) start)\b/.test(text)) return { intent: 'clarify' };
  if (/\b(?:cheaper|too (?:expensive|pricey|costly)|cant afford|steep|over (?:my|our) budget|out of (?:my|our) (?:budget|range)|less expensive)\b/.test(text)) return { intent: 'quote', cheaper: true };
  if (/\b(?:compare|comparison|difference|how do .+ differ)\b/.test(text) || slots.seatIds.length > 1) return { intent: 'compare' };
  const hasEntity = slots.seatIds.length > 0 || slots.matchIds.length > 0;
  const priceQuery = asksForPrice(text);
  const fixtures = /\b(?:fixtures?|schedule|when (?:is|does) (?:it|the (?:match|game))|who .+ play|which (?:matches|games|teams)|what (?:matches|games|teams)|list (?:the )?(?:matches|games)|upcoming (?:matches|games)|home games|kick ?off|match dates|start time)\b/.test(text)
    || (hasEntity || state.matchId) && /\b(?:when|what date|what time)\b/.test(text) && (hasEntity || /\b(?:it|this|that|start|match|game)\b/.test(text));
  if (fixtures && !priceQuery) return { intent: 'fixtures' };
  if (against && slots.matchIds.length && homeNames(catalog).some(name => phrase(text, name))) {
    return { intent: priceQuery || slots.seatIds.length || /\b(?:tickets?|seats?)\b/.test(text) ? 'quote' : 'fixtures' };
  }
  if (hasEntity && /\b(?:instead|(?:switch|change|swap) to|make (?:it|that)|(?:i|we) meant|same (?:seats|match|group|headcount)|what about|how about|can (?:i|we) get|do you (?:have|offer)|available|any tickets|tell me about)\b/.test(text)) return { intent: 'quote' };
  if (priceQuery || isPriceCheck(text) || slots.groupSize !== undefined || slots.budgetInr !== undefined || (slots.budgetBasis && state.budgetInr !== undefined)) return { intent: 'quote' };
  if (slots.matchIds.length || slots.seatIds.length) {
    // A standalone entity is usually a reply to a choice. A question about an
    // unknown property of that entity needs the semantic route or a handoff.
    let rest = text;
    for (const record of [...catalog.matches.filter(m => slots.matchIds.includes(m.id)), ...catalog.seat_areas.filter(s => slots.seatIds.includes(s.id))]) {
      const terms = [record.opponent || record.name, ...(record.aliases || []), record.id].sort((a, b) => b.length - a.length);
      for (const term of terms) rest = rest.replace(new RegExp('\\b' + escape(normalize(term)) + '\\b', 'g'), ' ');
    }
    if (!rest.replace(/\b(?:the|and|or|for|please|actually|instead|lets|go|with|i|want|choose|prefer|ill|take|make|it|we|would|like|match|game|tickets?|seats?)\b|[\s.,?!]+/g, '')) return { intent: 'quote' };
  }
  return { intent: 'unknown' };
}

function validateProposal(raw, catalog, text) {
  if (!raw || !intents.has(raw.intent)) return { intent: 'unknown' };
  if (raw.intent === 'faq' && !catalog.faq.some(f => f.id === raw.faqId)) return { intent: 'unknown' };
  const proposal = { intent: raw.intent };
  if (raw.faqId) proposal.faqIds = [raw.faqId];
  if (raw.matchId && matchById(catalog, raw.matchId)) proposal.matchIds = [raw.matchId];
  if (Array.isArray(raw.seatIds)) proposal.seatIds = [...new Set(raw.seatIds.filter(id => seatById(catalog, id)))];
  // A model may infer semantic intent but cannot invent a number in memory.
  const tokens = normalize(text).match(/\b[\d,]+(?:\.\d+)?\b/g) || [];
  const numbers = new Set(tokens.map(token => Number(token.replaceAll(',', ''))));
  for (const [word, value] of Object.entries(counts)) if (phrase(text, word)) numbers.add(value);
  if (Number.isInteger(raw.groupSize) && raw.groupSize > 0 && numbers.has(raw.groupSize)) proposal.groupSize = raw.groupSize;
  if (Number.isFinite(raw.budgetInr) && raw.budgetInr >= 0 && (numbers.has(raw.budgetInr) || raw.budgetInr === money(text))) proposal.budgetInr = raw.budgetInr;
  if (['total', 'each'].includes(raw.budgetBasis) && proposal.budgetInr !== undefined) proposal.budgetBasis = raw.budgetBasis;
  return proposal;
}

function applySlots(previous, slots, proposal, text) {
  const state = { ...previous };
  const matchId = slots.matchIds.at(-1) || proposal.matchIds?.[0];
  if (matchId) state.matchId = matchId;
  const seatIds = slots.seatIds.length ? slots.seatIds : proposal.seatIds;
  if (seatIds?.length) state.seatIds = seatIds;
  const groupSize = slots.groupSize ?? proposal.groupSize;
  if (groupSize > 0 && groupSize <= 999) state.groupSize = groupSize;
  const amount = slots.budgetInr ?? proposal.budgetInr;
  if (amount !== undefined && Number.isFinite(amount)) state.budgetInr = amount;
  const basis = slots.budgetBasis ?? proposal.budgetBasis;
  if (basis) state.budgetBasis = basis;
  if (/\b(?:no budget limit|no budget cap|ignore (?:my |our )?budget|any budget)\b/.test(text)) {
    delete state.budgetInr;
    delete state.budgetBasis;
  }
  return state;
}

function fixtureReply(catalog, ids) {
  const matches = ids.length ? ids.map(id => matchById(catalog, id)).filter(Boolean) : catalog.matches;
  return matches.map(m => catalog.team + ' vs ' + m.opponent + ' — ' + dateOf(m) + ' at ' + m.time + ' IST').join('; ') + '. Venue: ' + catalog.home_venue + '.';
}

function seatOptions(catalog, match) {
  return match.seat_areas_available.map(id => seatById(catalog, id)).filter(seat => Number.isFinite(seat?.price_inr_by_match[match.id])).sort((a, b) => a.price_inr_by_match[match.id] - b.price_inr_by_match[match.id]);
}

function quoteMatch(text, catalog, match, state, proposal, slots) {
  const all = seatOptions(catalog, match);
  const chosen = state.seatIds || [];
  const lowest = /\b(?:cheapest|least expensive|most affordable|lowest pric(?:e|ed))\b/.test(text);
  const broader = proposal.cheaper || lowest || /\b(?:other (?:seats|areas|options)|all (?:seats|areas|options)|any (?:seat|area)|most expensive)\b/.test(text);
  const useChosen = chosen.length && (!broader || slots.seatIds.length);
  let options = useChosen ? all.filter(s => chosen.includes(s.id)) : all;
  const unavailable = useChosen ? chosen.filter(id => !options.some(seat => seat.id === id)).map(id => seatById(catalog, id)?.name).filter(Boolean) : [];
  const count = state.groupSize;
  const basis = state.budgetBasis || 'total';
  const budget = isPriceCheck(text) ? undefined : state.budgetInr;
  const comparing = proposal.intent === 'compare';
  const rankedCount = lowest ? requestedRankCount(text) : undefined;
  const preserveRequestedOptions = comparing || rankedCount !== undefined;
  if (proposal.cheaper && chosen.length === 1 && !slots.seatIds.length) {
    const previousPrice = seatById(catalog, chosen[0])?.price_inr_by_match[match.id];
    if (previousPrice) options = options.filter(s => s.price_inr_by_match[match.id] < previousPrice);
  }
  // A comparison must show every explicitly requested area. Keep an existing
  // budget as context and annotate each option instead of hiding over-budget
  // choices, otherwise the fan cannot actually compare them.
  if (budget !== undefined && !preserveRequestedOptions) options = options.filter(s => s.price_inr_by_match[match.id] * (basis === 'total' ? count || 1 : 1) <= budget);
  if (lowest || proposal.cheaper) options = options.slice(0, rankedCount || 1);
  if (/\bmost expensive\b/.test(text)) options = options.slice(-1);
  const pieces = [];
  if (unavailable.length) pieces.push(unavailable.join(' and ') + ' is not listed for ' + match.opponent + '.');
  if (options.length) {
    const showDetails = proposal.intent === 'compare' || (useChosen && options.length === 1 && !count && budget === undefined);
    const lines = options.map(seat => {
      const price = seat.price_inr_by_match[match.id];
      const evaluated = basis === 'total' ? price * (count || 1) : price;
      const budgetNote = preserveRequestedOptions && budget !== undefined
        ? evaluated <= budget ? ' — within your budget' : ' — ' + rupees(evaluated - budget) + ' over your ' + (basis === 'each' ? 'per-ticket' : 'total') + ' budget'
        : '';
      return seat.name + ' ' + rupees(price) + ' each' + (count ? ' (' + rupees(price * count) + ' total for ' + count + ')' : '') + budgetNote + (showDetails ? '. ' + seat.description : '');
    });
    pieces.push(match.opponent + ': ' + lines.map(line => line.replace(/\.$/, '')).join(showDetails ? '. ' : '; ') + '.');
  } else if (budget !== undefined || proposal.cheaper) {
    const cheapest = all[0], price = cheapest.price_inr_by_match[match.id];
    const message = proposal.cheaper && budget === undefined ? 'There is no lower-priced option within that selection.' : 'No listed option in that selection fits ' + rupees(budget) + (basis === 'each' ? ' each.' : ' total.');
    pieces.push(message + ' The lowest listed price for ' + match.opponent + ' is ' + cheapest.name + ' at ' + rupees(price) + ' each' + (count ? ' (' + rupees(price * count) + ' total for ' + count + ')' : '') + '.');
  }
  return pieces.join(' ');
}

function answer(proposal, text, state, slots, catalog) {
  switch (proposal.intent) {
    case 'optout':
      state.optedOut = true;
      return 'Understood. Your promotional opt-out is recorded for this demo. Future promotional messages and calls should be suppressed.';
    case 'decline':
      state.declined = true;
      return 'Understood. I’ll end this ticket conversation here.';
    case 'handoff':
      state.handoffRequested = true;
      return 'I’ve recorded your request for a human ticket representative in this demo. I don’t have a live representative connected here.';
    case 'unknown':
      return (proposal.topic ? 'The team catalog does not publish ' + proposal.topic + '.' : 'I don’t have a catalog answer for that question.') + ' ' + handoff;
    case 'greet':
    case 'clarify':
      return state.matchId ? 'I can help with seats, prices, or published match details for ' + matchById(catalog, state.matchId).opponent + '. What would you like to know?' : 'I can help with ' + catalog.team + ' home matches, ticket prices, and published entry policies. Which would you like to explore?';
    case 'faq':
      return catalog.faq.filter(f => proposal.faqIds?.includes(f.id)).map(f => f.answer).join(' ');
    case 'fixtures': {
      const all = /\b(?:all|fixtures|schedule|upcoming|which matches|what matches|home games|which games)\b/.test(text);
      const ids = slots.matchIds.length ? slots.matchIds : state.matchId && !all ? [state.matchId] : [];
      return fixtureReply(catalog, ids);
    }
    case 'quote':
    case 'compare': {
      if (slots.groupSize === 0) return 'A ticket group needs at least one person. What group size should I use?';
      if (!state.matchId) {
        state.awaiting = 'match';
        return 'Which home match should I price' + (state.groupSize ? ' for your group of ' + state.groupSize : '') + '? ' + catalog.matches.map(m => m.opponent).join(', ') + '.';
      }
      if (!isPriceCheck(text) && state.budgetInr !== undefined && !state.budgetBasis && (state.groupSize || 1) > 1) {
        state.awaiting = 'basis';
        return 'Is ' + rupees(state.budgetInr) + ' your total budget for ' + state.groupSize + ' people, or the budget per ticket?';
      }
      if (!isPriceCheck(text) && state.budgetInr !== undefined && !state.groupSize && state.budgetBasis !== 'each') {
        state.awaiting = 'group';
        return 'How many tickets should I price against your ' + rupees(state.budgetInr) + ' budget?';
      }
      delete state.awaiting;
      const ids = slots.matchIds.length > 1 ? slots.matchIds : [state.matchId];
      const results = ids.map(id => quoteMatch(text, catalog, matchById(catalog, id), state, proposal, slots));
      const limit = catalog.faq.find(f => f.id === 'purchase-limit');
      if (state.groupSize > 6 && limit) results.push(limit.answer);
      return results.join(' ');
    }
  }
}

async function queryModel(model, args, timeoutMs) {
  const controller = new AbortController();
  const onAbort = () => controller.abort();
  if (args.signal?.aborted) controller.abort();
  else args.signal?.addEventListener('abort', onAbort, { once: true });
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const waitForAbort = new Promise((_, reject) => {
      if (controller.signal.aborted) reject(new Error('Model request interrupted'));
      else controller.signal.addEventListener('abort', () => reject(new Error('Model request interrupted')), { once: true });
    });
    return await Promise.race([waitForAbort, Promise.resolve().then(() => model({ ...args, signal: controller.signal }))]);
  } finally {
    clearTimeout(timer);
    args.signal?.removeEventListener('abort', onAbort);
  }
}

export async function replyTurn({ message, state: previous = {}, catalog, model, signal, mode = 'auto', timeoutMs = 3000 }) {
  const start = performance.now();
  const text = normalize(message || '');
  const slots = collect(text, previous, catalog);
  let proposal = text ? classify(text, slots, previous, catalog) : { intent: 'clarify' };
  let source = 'local', provider = 'rules', providerMeta = {}, modelMs = 0;
  // Exact catalog FAQ matches are already grounded and should not be
  // reclassified by a probabilistic planner (for example, "five-year-old"
  // must remain the children policy rather than becoming a five-ticket quote).
  const control = ['optout', 'decline', 'handoff', 'faq'].includes(proposal.intent) || proposal.protected;
  if (model && text && !control && (mode === 'model-first' || proposal.intent === 'unknown')) {
    const modelStart = performance.now();
    try {
      const raw = await queryModel(model, { message, state: previous, catalog, signal }, timeoutMs);
      provider = raw?._meta?.provider || 'model';
      providerMeta = raw?._meta || {};
      const semantic = validateProposal(raw, catalog, text);
      if (proposal.intent === 'unknown' || semantic.intent === proposal.intent || (mode === 'model-first' && semantic.intent !== 'unknown')) proposal = { ...proposal, ...semantic };
      source = 'model';
    } catch (error) {
      modelMs = performance.now() - modelStart;
      const safeState = applySlots(previous, slots, {}, text);
      const reason = signal?.aborted ? 'interrupted'
        : error?.status === 429 ? 'rate-limit'
        : error?.name === 'AbortError' || /interrupted/i.test(error?.message || '') ? 'turn-deadline'
        : 'provider-error';
      return { text: 'The ticket assistant is taking longer than expected or is temporarily unavailable. Please try again, or ask for a human ticket representative.', state: safeState, intent: 'unknown', source: 'fallback', provider: 'unavailable', providerMeta:{reason}, modelMs, logicMs: performance.now() - start - modelMs };
    }
    modelMs = performance.now() - modelStart;
  }
  let state = proposal.intent === 'unknown' && proposal.protected ? { ...previous } : applySlots(previous, slots, proposal, text);
  let response = answer(proposal, text, state, slots, catalog);
  // A single fan turn can combine a published policy with a grounded price
  // request. FAQ routing has priority for safety, but it must not discard the
  // price half when the requested fixture/area can be answered from catalog.
  if (proposal.intent === 'faq' && asksForPrice(text)) {
    response += ' ' + answer({ intent: 'quote' }, text, state, slots, catalog);
  }
  if (proposal.intent === 'unknown' && proposal.topic && !/\b(?:ignore|pretend|invent)\b/.test(text)) {
    // Keep separate requests separate. A price can be published even when
    // the same fan also asks about an unpublished policy in that turn.
    const clauses = text.split(/[;?]+|\s+(?:and|also|but)\s+(?=(?:what|which|when|where|how|is|are|do|does|can|could|will|tell|parking|refunds?|accessibility)\b)/).filter(s => s.trim());
    if (clauses.length > 1 && clauses.length <= 5) {
      const known = [];
      for (const clause of clauses) {
        const part = collect(clause, state, catalog);
        const query = classify(clause, part, state, catalog);
        if (!['fixtures', 'faq', 'quote', 'compare'].includes(query.intent)) continue;
        if (!part.matchIds.length && slots.matchIds.length === 1) part.matchIds = slots.matchIds;
        state = applySlots(state, part, query, clause);
        known.push(answer(query, clause, state, part, catalog));
      }
      if (known.length) response = [...known, response].join(' ');
    }
  }
  return { text: response, state, intent: proposal.intent, source, provider, providerMeta, modelMs, logicMs: Math.max(0, performance.now() - start - modelMs) };
}
