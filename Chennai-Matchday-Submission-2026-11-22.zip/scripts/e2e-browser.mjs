import { createRequire } from 'node:module';
import { once } from 'node:events';
import { readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { createApp } from '../server.mjs';
import { createDryRunTelecomProvider } from '../src/telecom.js';

const playwrightPath = process.argv[2];
if (!playwrightPath) throw new Error('Pass the absolute Playwright package path as the first argument.');
const {chromium} = createRequire(import.meta.url)(playwrightPath);
const report = await readFile(resolve('reports/e2e-100-browser-results.md'),'utf8');
const cases = report.split(/\r?\n/).filter(line => /^\| [NE]\d{3} \|/.test(line)).map(line => {
  const cells = line.split('|').slice(1,-1).map(cell => cell.trim());
  return {id:cells[0],type:cells[1],category:cells[2],messages:cells[3].split('→').map(value => value.trim())};
});
if (cases.length !== 100 || new Set(cases.map(item => item.id)).size !== 100) throw new Error(`Expected 100 unique cases, found ${cases.length}.`);

const contains = (text, values) => values.every(value => text.toLowerCase().includes(value.toLowerCase()));
const rupees = value => new Intl.NumberFormat('en-IN').format(value);
const singlePrices = [1200,1800,3000,5000,1400,2000,3200,5500,1000,1600,2800];
const groupTotals = [2400,5400,12000,10000,2800,6000,12800,11000,2000,4800,11200,6000,12000];
function evaluate(item, replies) {
  const final = replies.at(-1) || '';
  const all = replies.join('\n');
  const failures = [];
  if (replies.length !== item.messages.length) failures.push('missing agent turn');
  if (replies.some(reply => reply.trim().length < 12)) failures.push('empty or extremely short reply');
  if (/\bundefined\b|\bnull\b|internal server error|could not finish/i.test(all)) failures.push('runtime failure text');
  if (item.id === 'N001' || item.id === 'N006') if (!contains(final,['Mumbai Indians','Royal Challengers','Kolkata Knight Riders'])) failures.push('fixture list incomplete');
  const exact = {
    N002:['12 Apr'],N003:['18 Apr'],N004:['15:30'],N005:['Chidambaram'],N070:['Chidambaram'],
    N043:['North Stand','East Stand'],N044:['Pavilion','Club Lounge'],N045:['North Stand','Pavilion'],
    N048:['North Stand','East Stand'],N049:['North Stand'],N050:['Club Lounge'],N062:['two hours'],
    N063:['human'],N064:['QR'],N065:['photo'],N066:['six'],N067:['re-entry'],N068:['food'],N069:['email'],
  };
  if (exact[item.id] && !contains(final,exact[item.id])) failures.push('required grounded detail missing');
  if (/^N0(0[7-9]|1[0-7])$/.test(item.id)) {
    const expected = singlePrices[Number(item.id.slice(1)) - 7];
    if (!final.includes(rupees(expected))) failures.push(`missing expected price ${expected}`);
  }
  if (/^N0(1[8-9]|2[0-9]|30)$/.test(item.id)) {
    const expected = groupTotals[Number(item.id.slice(1)) - 18];
    if (!final.includes(rupees(expected))) failures.push(`missing expected total ${expected}`);
  }
  const memory = {
    N051:['North Stand','1,200'],N052:['North Stand','East Stand'],N053:['Mumbai Indians'],N054:['East Stand','3,600'],
    N055:['Kolkata Knight Riders','4,800'],N056:['Royal Challengers'],N057:['4'],N058:['Royal Challengers','2,800'],
    N059:['2,000'],N060:['North Stand','2,000'],N061:['Kolkata Knight Riders','11,200'],
  };
  if (memory[item.id] && !contains(final,memory[item.id])) failures.push('multi-turn state was not preserved');
  if (/^E0(0[1-9]|1[0-3])$/.test(item.id) && !/(does not publish|not publish|not listed|catalog|human)/i.test(final)) failures.push('unsupported fixture or seat was not refused');
  if (item.id === 'E014' && !/(live inventory|sold out|does not publish|human)/i.test(final)) failures.push('inventory uncertainty missing');
  if (item.id === 'E015' && (!contains(final,['accessibility','parking']) || !/(adjacent|adjoining)/i.test(final))) failures.push('compound unknowns incomplete');
  if (item.id === 'E016' && (!final.includes('1,200') || !/(refund|human|publish)/i.test(final))) failures.push('mixed known and unknown answer incomplete');
  if (item.id === 'E017' && (final.includes('₹99') || !/(catalog|publish|cannot|can’t)/i.test(final))) failures.push('prompt injection was not contained');
  if (item.id === 'E018' && !/(cannot|can’t|human|payment)/i.test(final)) failures.push('unsupported checkout boundary missing');
  if (item.id === 'E019' && !/(does not publish|not publish|human)/i.test(final)) failures.push('discount was invented or not refused');
  if (['E020','E027'].includes(item.id) && !/(does not publish|not publish|ticket|human)/i.test(final)) failures.push('off-topic boundary missing');
  if (item.id === 'E021' && !/(valid|between 1 and 6|how many|at least one)/i.test(final)) failures.push('zero group not rejected');
  if (item.id === 'E022' && !/(6|limit)/i.test(final)) failures.push('purchase limit not enforced');
  if (item.id === 'E023' && !/(valid|budget|positive|no listed option|₹0)/i.test(final)) failures.push('zero budget not rejected');
  if (item.id === 'E024' && !/(match|fixture)/i.test(final)) failures.push('missing match not clarified');
  if (item.id === 'E025' && !/(Platinum|does not publish|not publish)/i.test(final)) failures.push('unknown seat contaminated state');
  if (item.id === 'E026' && !/(Delhi|does not publish|not publish)/i.test(final)) failures.push('unknown match contaminated state');
  if (item.id === 'E028' && !/(won’t send|will not send|understand|not interested|end this)/i.test(final)) failures.push('decline not respected');
  if (item.id === 'E029' && !/(opted out|opt-out|won’t send|will not send)/i.test(final)) failures.push('STOP not respected');
  if (item.id === 'E030' && !/(human|handoff)/i.test(final)) failures.push('handoff not acknowledged');
  return failures;
}

const app = await createApp({
  storePath:null, telecomStorePath:null, telecomProvider:createDryRunTelecomProvider(),
  groqApiKey:'', apiKey:'', model: null,
});
app.listen(0,'127.0.0.1');
await once(app,'listening');
const browser = await chromium.launch({executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true});
const page = await browser.newPage({viewport:{width:1360,height:850}});
const browserErrors = [];
page.on('pageerror',error => browserErrors.push(String(error)));
page.on('response',response => { if (response.status() >= 500) browserErrors.push(`${response.status()} ${response.url()}`); });
const results = [];
try {
  await page.goto(`http://127.0.0.1:${app.address().port}/`,{waitUntil:'networkidle'});
  await page.locator('#featured-match').waitFor();
  for (const item of cases) {
    await page.locator('#new-chat').click();
    const replies = [];
    for (const message of item.messages) {
      const before = await page.locator('.turn.agent').count();
      await page.locator('#message').fill(message);
      await page.locator('#send').click();
      await page.waitForFunction(count => document.querySelectorAll('.turn.agent').length > count,before,{timeout:12_000});
      replies.push(await page.locator('.turn.agent .bubble').last().innerText());
    }
    const failures = evaluate(item,replies);
    results.push({...item,replies,pass:failures.length === 0,failures});
    process.stdout.write(`${item.id} ${failures.length ? 'FAIL ' + failures.join('; ') : 'PASS'}\n`);
  }
  await page.locator('#nav-outreach').click();
  await page.locator('#telecom-title').waitFor();
  const telecomLabel = await page.locator('#telecom-provider').innerText();
  const phoneReturned = await page.locator('#demo-phone').inputValue();
  if (!/Local dry-run/.test(telecomLabel) || phoneReturned) browserErrors.push('telecom privacy/mode UI check failed');
} finally {
  await browser.close();
  app.closeAllConnections();
  await new Promise(resolveClose => app.close(resolveClose));
}
const summary = {
  runAt:new Date().toISOString(), total:results.length, passed:results.filter(item => item.pass).length,
  failed:results.filter(item => !item.pass).length, browserErrors, results,
};
await writeFile(resolve('.qa/e2e-100-latest.json'),JSON.stringify(summary,null,2));
console.log(JSON.stringify({total:summary.total,passed:summary.passed,failed:summary.failed,browserErrors},null,2));
if (summary.failed || browserErrors.length) process.exitCode = 1;
