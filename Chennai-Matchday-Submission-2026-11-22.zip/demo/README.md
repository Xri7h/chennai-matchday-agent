# Chennai Matchday walkthrough

## Current submission recording

[Watch the supplied Loom demonstration](https://www.loom.com/share/3c6af046dd7d43e4b586fb49e6a28f17) · **5 minutes 31 seconds** · recorded by the author on 22 November 2026.

The current video presents repeat-fan scoring with Vihaan Patel, a web conversation, a personal Exotel demo call about RCB seats and budget, an unanswerable weather question, slow-model handling and benchmark evidence. The telephone agent is separate from the web intent-planning route. The recording is 31 seconds longer than the assignment's five-minute maximum and should be shortened for strict compliance. The reports are authoritative for exact benchmark counts and timing scopes: the local benchmark has **76 turns**, and its millisecond timings exclude STT, TTS and carrier delay.

## Archived walkthrough

[Play the earlier narrated walkthrough](ticket-desk.mp4) · 4 minutes 04 seconds · English audio and optional English captions. This is an earlier interface and typed-message rehearsal, retained as supplementary evidence rather than the current phone demonstration.

| Time | What to watch |
| --- | --- |
| 0:00 | Open the Dhoni photo archive, browse both historical photographs and return to the Chennai home fixtures. |
| 0:21 | Inspect the repeat-fan cohort, a skipped lead with missing purchase history and an eligible fan scoring 76. |
| 1:19 | Start a simulated promotional message for Meera at the displayed campaign time. |
| 1:40 | Quote three Bengaluru tickets under ₹4,500 total, then change the group to four and retain the budget. |
| 2:13 | Compare a published mobile-ticket policy with an unpublished accessibility question. |
| 2:45 | Force a slow provider turn, see the waiting behavior, then the actual timeout response. |
| 3:07 | Opt out, inspect Meera’s updated outreach decision and open the per-turn timing table. |

The footage was refreshed from the current Chennai Super Kings caselet build on 21 November 2026. It follows real interactions in an isolated local session and shows the configured Groq badge; the forced slow turn is an explicit fault injection. Its English narration is synthesized for this walkthrough. To hear the agent itself, enable **Read replies aloud** in the running app and send a question. **Use microphone** accepts speech input in browsers that provide speech recognition. The recording uses typed fan messages. Production ticket sales, live telephone delivery, and a staffed transfer are outside the rehearsal.

## Photographs in the recording

The interface uses local WebP copies and crops images for the cover. The historical photographs appear in an independent, assumed 2027 CSK season rehearsal.

- *MS Dhoni (late 2010s)*, B A Raju / Times of India. [Original portrait](https://commons.wikimedia.org/wiki/File:MS_Dhoni_%28late_2010s%29.jpg) · [CC BY 3.0](https://creativecommons.org/licenses/by/3.0/)
- *Dhoni behind Stumps*, Pulkitsinha. The gallery copy carries the same attribution and share-alike license. [Original photograph](https://commons.wikimedia.org/wiki/File:Dhoni_behind_Stumps.jpg) · [CC BY-SA 2.0](https://creativecommons.org/licenses/by-sa/2.0/)
- *IPL T20 Chennai vs Kolkata*, Chandrachoodan Gopalakrishnan. The home page shows a cropped, monochrome treatment of this stadium photograph. [Original photograph](https://commons.wikimedia.org/wiki/File:IPL_T20_Chennai_vs_Kolkata.JPG) · [CC BY 3.0](https://creativecommons.org/licenses/by/3.0/)
